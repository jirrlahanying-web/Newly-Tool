/* ====================== AUTH / GUEST LOGIN SYSTEM ====================== */
const AUTH_KEY = 'newly_auth';
const GUEST_UID_KEY = 'newly_guest_uid';
let _authUser = null;

function authSave(user) {
  _authUser = user;
  try { localStorage.setItem(AUTH_KEY, JSON.stringify(user)); } catch(_) {}
}
function authLoad() {
  try {
    const s = localStorage.getItem(AUTH_KEY);
    if (s) { _authUser = JSON.parse(s); return _authUser; }
  } catch(_) {}
  return null;
}
function authGet() { return _authUser; }
function authIsAdmin() { return _authUser?.type === 'admin'; }
function authLogout() {
  _authUser = null;
  try {
    localStorage.removeItem(AUTH_KEY);
    localStorage.removeItem(GUEST_UID_KEY); // hapus uid lama, akan dibuatkan guest baru
  } catch(_) {}
  document.getElementById('login-overlay').style.display = 'flex';
  document.getElementById('admin-fab').style.display = 'none';
}

// Ambil UID guest dari localStorage, generate baru kalau belum ada
function getOrCreateGuestUID() {
  try {
    let uid = localStorage.getItem(GUEST_UID_KEY);
    if (!uid) {
      uid = 'guest_' + (crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '') : Date.now().toString(36) + Math.random().toString(36).slice(2, 12));
      localStorage.setItem(GUEST_UID_KEY, uid);
    }
    return uid;
  } catch(_) {
    return 'guest_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 12);
  }
}

// Cek auth saat load — auto login sebagai guest, tanpa OTP/email
window.addEventListener('DOMContentLoaded', () => {
  const saved = authLoad();
  waitAPIThen(() => {
    if (saved?.uid) {
      // Verifikasi ke server pakai uid yang sudah ada
      fetch(API.replace(/\/api\/$/, '') + '/api/auth/me?uid=' + encodeURIComponent(saved.uid))
        .then(r => r.json())
        .then(d => {
          if (d.status && d.user) {
            authSave(d.user);
            onLoginSuccess(d.user);
          } else {
            loginAsGuest();
          }
        })
        .catch(() => {
          // Offline — pakai cached
          onLoginSuccess(saved);
        });
    } else {
      loginAsGuest();
    }
  });
});

function waitAPIThen(cb, tries = 0) {
  if (API) return cb();
  if (tries > 30) return;
  setTimeout(() => waitAPIThen(cb, tries + 1), 300);
}

function onLoginSuccess(user) {
  document.getElementById('login-overlay').style.display = 'none';
  if (user.type === 'admin') {
    document.getElementById('admin-fab').style.display = 'block';
  }
  console.log('[auth] Login guest:', user.uid, '/', user.type);
}

// Login otomatis sebagai guest — kirim uid (dari localStorage atau baru) ke server
async function loginAsGuest() {
  const errEl = document.getElementById('otp-email-err');
  const uid = getOrCreateGuestUID();

  await waitAPIReady();
  try {
    const r = await fetch(API.replace(/\/api\/$/, '') + '/api/auth/guest', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid }),
    });
    const d = await r.json();
    if (d.status && d.user) {
      authSave(d.user);
      onLoginSuccess(d.user);
    } else if (errEl) {
      errEl.textContent = d.error || 'Gagal login sebagai guest'; errEl.style.display = 'block';
    }
  } catch(e) {
    if (errEl) { errEl.textContent = 'Error: ' + e.message; errEl.style.display = 'block'; }
  }
}

function waitAPIReady() {
  return new Promise(resolve => waitAPIThen(resolve));
}

/* ====================== ADMIN PANEL ====================== */
function toggleAdminPanel() {
  const p = document.getElementById('admin-panel');
  p.style.display = p.style.display === 'flex' ? 'none' : 'flex';
  if (p.style.display === 'flex') adminLoadUsers();
}

async function adminLoadUsers() {
  const listEl = document.getElementById('adm-user-list');
  listEl.innerHTML = '<p style="color:#666;font-size:13px;text-align:center;">Loading...</p>';
  await waitAPIReady();
  try {
    const r = await fetch(API + 'admin/users', {
      headers: { 'x-admin-email': authGet()?.email || '' },
    });
    const d = await r.json();
    if (!d.status) { listEl.innerHTML = '<p style="color:#f87171;font-size:13px;">' + (d.error || 'Gagal') + '</p>'; return; }
    if (!d.users?.length) { listEl.innerHTML = '<p style="color:#666;font-size:13px;text-align:center;">Belum ada user</p>'; return; }
    listEl.innerHTML = d.users.map(u => {
      const badge = u.type === 'admin' ? '<span style="background:#f59e0b;color:#000;padding:2px 7px;border-radius:4px;font-size:11px;font-weight:700;">ADMIN</span>'
        : u.type === 'premium' ? '<span style="background:#a855f7;color:#fff;padding:2px 7px;border-radius:4px;font-size:11px;font-weight:700;">PREMIUM</span>'
        : '<span style="background:#333;color:#aaa;padding:2px 7px;border-radius:4px;font-size:11px;">basic</span>';
      const premUntil = u.premium_until ? `<span style="color:#888;font-size:11px;"> s/d ${u.premium_until.slice(0,10)}</span>` : '';
      const lastLogin = u.last_login ? u.last_login.slice(0,10) : '-';
      return `<div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid #222;gap:8px;">
        <div style="overflow:hidden;">
          <div style="color:#fff;font-size:13px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${u.email || '-'}</div>
          <div style="color:#666;font-size:11px;margin-top:2px;">Login terakhir: ${lastLogin}</div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">${badge}${premUntil}</div>
      </div>`;
    }).join('');
  } catch(e) {
    listEl.innerHTML = '<p style="color:#f87171;font-size:13px;">Error: ' + e.message + '</p>';
  }
}

async function adminSetPremium() {
  const email = document.getElementById('adm-prem-email').value.trim();
  const days = document.getElementById('adm-prem-days').value;
  const msgEl = document.getElementById('adm-prem-msg');
  if (!email) { msgEl.style.color = '#f87171'; msgEl.textContent = 'Email wajib diisi'; msgEl.style.display = 'block'; return; }
  await waitAPIReady();
  const r = await fetch(API + 'admin/set-premium', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-email': authGet()?.email || '' },
    body: JSON.stringify({ email, days }),
  });
  const d = await r.json();
  msgEl.style.color = d.status ? '#4ade80' : '#f87171';
  msgEl.textContent = d.message || d.error;
  msgEl.style.display = 'block';
  if (d.status) adminLoadUsers();
}

async function adminSetBasic() {
  const email = document.getElementById('adm-prem-email').value.trim();
  const msgEl = document.getElementById('adm-prem-msg');
  if (!email) { msgEl.style.color = '#f87171'; msgEl.textContent = 'Email wajib diisi'; msgEl.style.display = 'block'; return; }
  await waitAPIReady();
  const r = await fetch(API + 'admin/set-basic', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-admin-email': authGet()?.email || '' },
    body: JSON.stringify({ email }),
  });
  const d = await r.json();
  msgEl.style.color = d.status ? '#4ade80' : '#f87171';
  msgEl.textContent = d.message || d.error;
  msgEl.style.display = 'block';
  if (d.status) adminLoadUsers();
}

/* ====================== HELPERS ====================== */
let API = '';
(async () => {
  try {
    const res = await fetch('https://raw.githubusercontent.com/jirrlahanying-web/endpoint-beckend/main/backend-url.json?t=' + Date.now());
    const data = await res.json();
    API = data.url.replace(/\/$/, '') + '/api/';
    console.log('[config] Backend URL:', API);
  } catch (e) {
    console.error('[config] Gagal fetch backend URL:', e.message);
  }
})();
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

/* ============ DEVICE ID (untuk sistem limit basic/premium terpadu) ============
   ID acak disimpan di localStorage sebagai penanda perangkat saja.
   Hitungan limit sesungguhnya tetap dicek & disimpan di server (Supabase),
   jadi clear localStorage TIDAK mereset limit — cuma bikin device dianggap baru
   (== balik ke basic, karena identifier lama sudah tidak dikenali). */
function getDeviceId(){
  let id=localStorage.getItem('newly_device_id');
  if(!id){
    id='web_'+Date.now().toString(36)+Math.random().toString(36).slice(2,12);
    localStorage.setItem('newly_device_id',id);
  }
  return id;
}
const DEVICE_ID=getDeviceId();

/* ============ RATE LIMITER (1 req / 5 detik) ============
   Mencegah spam request ke API agar IP tidak kena ban Cloudflare.
   Limiter berlaku global untuk semua call fetchAPI / uploadToGithub / deleteFromGithub. */
const RATE_LIMIT_MS=5000;
let _lastReqAt=0;
let _limitNotifEl=null;
let _limitTimer=null;

function _fmtSisa(ms){
  const s=Math.ceil(ms/1000);
  return s+' detik';
}
function _showLimitNotif(sisaMs){
  // Update notifikasi yang sedang aktif kalau ada, biar countdown jalan real-time
  if(_limitNotifEl && _limitNotifEl.isConnected){
    const msgEl=_limitNotifEl.querySelector('.notif-msg');
    if(msgEl) msgEl.textContent='Maaf limit anda sudah habis, tunggu selama '+_fmtSisa(sisaMs)+' untuk reset limit';
    return;
  }
  const handle=showNotif('error','Limit Tercapai','Maaf limit anda sudah habis, tunggu selama '+_fmtSisa(sisaMs)+' untuk reset limit',6000);
  // showNotif mengembalikan elemen; fallback: ambil notif terakhir
  _limitNotifEl = handle || document.querySelector('#notif-container .notif:last-child');
  clearInterval(_limitTimer);
  _limitTimer=setInterval(()=>{
    const remain=RATE_LIMIT_MS-(Date.now()-_lastReqAt);
    if(remain<=0||!_limitNotifEl||!_limitNotifEl.isConnected){
      clearInterval(_limitTimer); _limitTimer=null; _limitNotifEl=null; return;
    }
    const msgEl=_limitNotifEl.querySelector('.notif-msg');
    if(msgEl) msgEl.textContent='Maaf limit anda sudah habis, tunggu selama '+_fmtSisa(remain)+' untuk reset limit';
  },500);
}
function checkRateLimit(){
  const now=Date.now();
  const elapsed=now-_lastReqAt;
  if(elapsed<RATE_LIMIT_MS){
    const sisa=RATE_LIMIT_MS-elapsed;
    _showLimitNotif(sisa);
    return {ok:false,sisa};
  }
  _lastReqAt=now;
  return {ok:true};
}

async function fetchAPI(url,opts){
  const gate=checkRateLimit();
  if(!gate.ok) return {status:false,error:'Limit tercapai. Tunggu '+_fmtSisa(gate.sisa)+'.',_rateLimited:true};
  try{
    const res=await fetch(url,opts||undefined);
    if(res.status===429){
      let sisaDetik=5;
      try{
        const d=await res.json();
        if(d.retryAfter) sisaDetik=d.retryAfter;
        _lastReqAt=Date.now()-RATE_LIMIT_MS+(sisaDetik*1000);
        _showLimitNotif(sisaDetik*1000);
        return {status:false,error:d.error||'Maaf limit anda sudah habis, mohon tunggu '+sisaDetik+' detik untuk reset limit',_rateLimited:true};
      }catch(_){}
      _lastReqAt=Date.now()-RATE_LIMIT_MS+(sisaDetik*1000);
      _showLimitNotif(sisaDetik*1000);
      return {status:false,error:'Maaf limit anda sudah habis, mohon tunggu '+sisaDetik+' detik untuk reset limit',_rateLimited:true};
    }
    const ct=res.headers.get('content-type')||'';
    if(ct.includes('application/json')){
      const data=await res.json();
      if(!res.ok) return {status:false,error:data.message||data.error||('HTTP '+res.status)};
      return data;
    }
    if(ct.startsWith('image/')||ct.startsWith('video/')||ct.startsWith('audio/')){
      return {status:true,result:url,_isMedia:true};
    }
    const txt=await res.text();
    try{return JSON.parse(txt)}catch{return {status:res.ok,result:txt}};
  }catch(err){return {status:false,error:err.message}}
}

/* ============ STICKER CONVERTER ============ */
async function convertToSticker(imageUrl, filename='sticker') {
  try {
    showNotif('info','Proses...','Mengkonversi ke WebP sticker...');
    
    // Fetch image
    const res = await fetch(imageUrl);
    const blob = await res.blob();
    
    // Buat canvas untuk draw image + watermark
    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    return new Promise((resolve, reject) => {
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        // Set canvas size
        canvas.width = img.width;
        canvas.height = img.height;
        
        // Draw original image
        ctx.drawImage(img, 0, 0);
        
        // Add watermark "Newly Tools"
        const fontSize = Math.max(canvas.width / 12, 20);
        ctx.font = `bold ${fontSize}px Arial`;
        ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
        ctx.textAlign = 'right';
        ctx.textBaseline = 'bottom';
        
        const padding = 10;
        const text = 'Newly Tools';
        ctx.fillText(text, canvas.width - padding, canvas.height - padding);
        
        // Convert to WebP blob
        canvas.toBlob(
          async (webpBlob) => {
            try {
              // Convert blob to base64
              const reader = new FileReader();
              reader.onload = async () => {
                const webpBase64 = reader.result.split(',')[1];
                
                // Upload ke Telegram via backend
                showNotif('info','Upload...','Mengirim ke Telegram sticker pack...');
                
                const uploadRes = await fetch(API + 'add-to-telegram', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    webpBase64: webpBase64,
                    filename: filename,
                  }),
                });
                
                const uploadData = await uploadRes.json();
                
                if (uploadData.status) {
                  showNotif('success','Berhasil!','Sticker ditambahkan ke pack Telegram');
                  
                  // Tampilkan link dengan tombol buka WhatsApp
                  const linkEl = document.createElement('a');
                  linkEl.href = uploadData.result;
                  linkEl.target = '_blank';
                  linkEl.textContent = 'Buka WhatsApp & Add Sticker';
                  linkEl.style.cssText = 'display:inline-block;padding:10px 15px;background:#25D366;color:white;border-radius:8px;text-decoration:none;font-weight:bold;margin-top:10px;cursor:pointer;';
                  
                  // Cari element result dan tambahkan link
                  const resultEl = document.querySelector('.result');
                  if (resultEl) {
                    const actionDiv = document.createElement('div');
                    actionDiv.style.marginTop = '15px';
                    actionDiv.appendChild(linkEl);
                    resultEl.appendChild(actionDiv);
                  }
                  
                  resolve(uploadData.result);
                } else {
                  showNotif('error','Gagal','Error: ' + uploadData.error);
                  reject(new Error(uploadData.error));
                }
              };
              reader.readAsDataURL(webpBlob);
            } catch(err) {
              showNotif('error','Gagal','Error: ' + err.message);
              reject(err);
            }
          },
          'image/webp',
          0.8
        );
      };
      img.onerror = () => reject(new Error('Gagal load image'));
      img.src = imageUrl;
    });
  } catch(err) {
    showNotif('error','Gagal','Error: ' + err.message);
  }
}

function downloadFile(url,filename){
  if(!url) return showNotif('error','Gagal','URL kosong');
  
  // Jika URL adalah data URL, langsung download
  if(url.startsWith('data:')){
    const a=document.createElement('a');
    a.href=url; a.download=filename||'newly-tool-download';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    showNotif('success','Unduhan dimulai',filename||'File siap diunduh');
    return;
  }
  
  // Coba fetch dengan blob (handle CORS), fallback ke window.open
  fetch(url,{mode:'cors'})
    .then(r=>{
      if(!r.ok) throw new Error('HTTP '+r.status);
      return r.blob();
    })
    .then(blob=>{
      const objUrl=URL.createObjectURL(blob);
      const a=document.createElement('a');
      a.href=objUrl; a.download=filename||'newly-tool-download';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(()=>URL.revokeObjectURL(objUrl),5000);
      showNotif('success','Unduhan dimulai',filename||'File siap diunduh');
    })
    .catch(()=>{
      // Fallback: buka di tab baru agar browser bisa download langsung
      const a=document.createElement('a');
      a.href=url; a.download=filename||'newly-tool-download';
      a.target='_blank'; a.rel='noopener';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      showNotif('info','Membuka file','File dibuka di tab baru — simpan manual jika perlu');
    });
}

async function handleImageUpload(callback, card){
  // Rate limit: 1 request per 5 detik
  if(window.__lastUpload && Date.now()-window.__lastUpload<5000){
    return showErr(card,'Tunggu 5 detik sebelum upload lagi');
  }
  window.__lastUpload=Date.now();
  
  const inp=document.createElement('input');
  inp.type='file';
  inp.accept='image/*';
  inp.onchange=async e=>{
    const f=e.target.files?.[0];
    if(!f) return showErr(card,'File wajib.');
    
    showNotif('info','Upload dimulai','Uploading ke GitHub...');
    
    const r=new FileReader();
    r.onload=async x=>{
      const base64=x.target.result.split(',')[1];
      const randomName=Math.random().toString(36).substring(2,15)+'.jpg';
      const url=await uploadToGithub(base64, randomName);
      if(!url){
        showErr(card,'Gagal upload ke GitHub.');
        return;
      }
      
      // Simpan ke hidden storage dengan URL asli
      const hiddenId=Math.random().toString(36).substring(2,15);
      window.__imageStorage=window.__imageStorage||{};
      window.__imageStorage[hiddenId]={url, filename:randomName};
      
      // Auto delete setelah 10 menit (600000 ms)
      setTimeout(()=>{
        delete window.__imageStorage[hiddenId];
        deleteFromGithub(randomName);
      },600000);
      
      callback(hiddenId, f.name);
      showNotif('success','Upload berhasil','Siap diproses (10 menit)');
    };
    r.onerror=()=>showErr(card,'Gagal baca file');
    r.readAsDataURL(f);
  };
  inp.click();
}

async function uploadToGithub(base64, filename){
  const gate=checkRateLimit();
  if(!gate.ok) return null;
  try{
    const res=await fetch('https://monitors-riders-fotos-additional.trycloudflare.com/api/gh-upload',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({filename, content:base64})
    });
    if(!res.ok){ console.error('Upload proxy error'); return null; }
    const data=await res.json();
    return data.url||null;
  }catch(err){ console.error('Upload error:',err); return null; }
}

async function deleteFromGithub(filename){
  const gate=checkRateLimit();
  if(!gate.ok) return;
  try{
    await fetch('https://monitors-riders-fotos-additional.trycloudflare.com/api/gh-delete',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({filename})
    });
  }catch(err){ console.error('Delete error:',err); }
}

function getImageUrl(hiddenId){
  if(!window.__imageStorage||!window.__imageStorage[hiddenId]) return null;
  return window.__imageStorage[hiddenId].url;
}

// Cache untuk hasil download supaya tidak spam request
window.__resultCache={};

function cacheResult(key, value){
  window.__resultCache[key]=value;
  setTimeout(()=>delete window.__resultCache[key],600000);
}

function getCachedResult(key){
  return window.__resultCache[key]||null;
}

function copyText(t){
  if(navigator.clipboard&&window.isSecureContext){
    navigator.clipboard.writeText(t).then(
      ()=>showNotif('success','Tersalin','Teks berhasil disalin'),
      ()=>copyFallback(t)
    );
  } else {
    copyFallback(t);
  }
}
function copyFallback(t){
  const ta=document.createElement('textarea');
  ta.value=t; ta.style.cssText='position:fixed;top:0;left:0;opacity:0';
  document.body.appendChild(ta); ta.focus(); ta.select();
  try{
    document.execCommand('copy');
    showNotif('success','Tersalin','Teks berhasil disalin');
  }catch{
    showNotif('error','Gagal menyalin','Coba salin manual');
  }
  document.body.removeChild(ta);
}

const notifSound=()=>{try{new Audio("https://aware-beige-uxizgi3s.edgeone.dev/meldix-success-340660.mp3").play().catch(()=>{})}catch{}};

function showNotif(type,title,msg,duration){
  const c=$('#notif-container');
  const el=document.createElement('div');
  el.className='notif notif-'+type;
  const iconSvg = type==='success'
    ? `<svg viewBox="0 0 24 24" width="22" height="22" fill="none"><circle cx="12" cy="12" r="10" stroke="#22c55e" stroke-width="2" stroke-dasharray="63" stroke-dashoffset="63" style="animation:drawCircle .4s ease forwards 50ms"/><polyline points="7,12 10.5,15.5 17,9" stroke="#22c55e" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" fill="none" stroke-dasharray="14" stroke-dashoffset="14" style="animation:drawCheck .3s ease forwards 420ms"/></svg>`
    : type==='error'
      ? `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12" y2="16"/></svg>`
      : `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#a855f7" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/></svg>`;
  el.innerHTML=`<div class="notif-icon">${iconSvg}</div>
    <div class="notif-content"><p class="notif-title">${esc(title)}</p><p class="notif-msg">${esc(msg)}</p></div>
    <button class="notif-close" aria-label="Tutup"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></svg></button>`;
  c.appendChild(el);
  requestAnimationFrame(()=>el.classList.add('show'));
  if(type==='success') notifSound();
  const close=()=>{el.classList.remove('show');setTimeout(()=>el.remove(),300)};
  el.querySelector('.notif-close').onclick=close;
  setTimeout(close, duration||3500);
  return el;
}

function fmtMs(ms){const s=Math.floor(ms/1000);const m=Math.floor(s/60);const ss=s%60;return m+':'+String(ss).padStart(2,'0')}
function fmtNum(n){if(n==null) return '-';return new Intl.NumberFormat('id-ID').format(n)}

function setLoading(btn,on,label){
  if(on){btn.dataset.orig=btn.innerHTML;btn.disabled=true;btn.classList.add('loading');btn.innerHTML='<span>Memproses...</span>'}
  else{btn.disabled=false;btn.classList.remove('loading');btn.innerHTML=btn.dataset.orig||label||'Jalankan'}
}

function showErr(card,msg){
  const r=card.querySelector('.result');
  r.classList.remove('hidden');r.classList.add('err');
  r.innerHTML=`<div>${esc(msg||'Terjadi kesalahan. Coba lagi.')}</div>`;
}
function clearResult(card){const r=card.querySelector('.result');r.classList.remove('err');r.innerHTML='';r.classList.add('hidden')}
function showResult(card,html){const r=card.querySelector('.result');r.classList.remove('hidden','err');r.innerHTML=html}

/* ====================== ICONS ====================== */
const I={
  video:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>`,
  music:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`,
  brain:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a3 3 0 0 0-3 3v.5a3 3 0 0 0-3 5.5 3 3 0 0 0 0 4 3 3 0 0 0 3 5.5V22h6v-.5a3 3 0 0 0 3-5.5 3 3 0 0 0 0-4 3 3 0 0 0-3-5.5V6a3 3 0 0 0-3-3z"/></svg>`,
  hd:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9v6M11 9v6M7 12h4M14 9h2a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-2z"/></svg>`,
  paint:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2 5 5 1-3.5 3.5L17 17l-5-3-5 3 1.5-5.5L5 8l5-1z"/></svg>`,
  name:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v13"/><path d="M4 19h16M8 9h8M8 13h5"/></svg>`,
  brat:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="16" rx="3"/><text x="12" y="16" font-size="11" font-weight="700" text-anchor="middle" fill="currentColor" stroke="none">Br</text></svg>`,
  mic:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="2" width="6" height="13" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/></svg>`,
  moon:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>`,
  smile:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>`,
  star:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><polygon points="12 2 15 9 22 10 17 15 18 22 12 19 6 22 7 15 2 10 9 9 12 2"/></svg>`,
  avatar:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>`,
  mosque:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21V11l9-7 9 7v10"/><path d="M9 21v-5a3 3 0 0 1 6 0v5"/><path d="M12 4V2"/></svg>`,
  lens:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/></svg>`,
  envelope:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><polyline points="2,7 12,13 22,7"/></svg>`,
  pen:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 1 1 3 3L7 19l-4 1 1-4z"/></svg>`,
  pin:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2C8 2 5 5 5 9c0 5 7 13 7 13s7-8 7-13c0-4-3-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>`,
  chatcard:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11a8 8 0 0 1-15 4l-3 1 1-3a8 8 0 1 1 17-2z"/></svg>`,
  qr:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM18 18h3v3h-3z"/></svg>`,
  scan:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="3" y1="12" x2="21" y2="12"/></svg>`,
  heart:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>`,
  meme:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 8h10M7 18h10"/><circle cx="9" cy="13" r="1"/><circle cx="15" cy="13" r="1"/></svg>`,
  anime:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 12a8 8 0 0 1 16 0v3a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5z"/><path d="M9 11l1 2M15 11l-1 2"/></svg>`,
  hearts:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M9 13a3 3 0 1 0-3-3 3 3 0 0 0 3 3z"/><path d="M16 16a3 3 0 1 0-3-3 3 3 0 0 0 3 3z"/></svg>`,
  waifu:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M12 2l2 4 4 1-3 3 1 4-4-2-4 2 1-4-3-3 4-1z"/></svg>`,
  scissor:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/></svg>`,
  smeme:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><line x1="7" y1="9" x2="17" y2="9"/><line x1="7" y1="15" x2="17" y2="15"/></svg>`,
  sticker:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="15 3 15 9 21 9"/></svg>`,
  eye:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
  tt:`<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 2v3a4 4 0 0 0 4 4v3a7 7 0 0 1-4-1v6a6 6 0 1 1-6-6v3a3 3 0 1 0 3 3V2z"/></svg>`,
  babi:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><circle cx="10" cy="12" r="1.4" fill="currentColor"/><circle cx="14" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="14.5" r="1.4" fill="currentColor"/></svg>`,
  two:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="12" r="5"/><circle cx="15" cy="12" r="5"/></svg>`,
  blonde:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12C4 6 8 4 12 4s8 2 8 8v4l-3-2-2 2-3-2-2 2-3-2-3 2z"/></svg>`,
  bald:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="10" rx="6" ry="7"/><path d="M6 21a6 6 0 0 1 12 0"/></svg>`,
  beard:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6a6 6 0 0 1 12 0v6a6 6 0 0 1-12 0z"/><path d="M8 14c0 4 2 7 4 7s4-3 4-7"/></svg>`,
  globe:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><line x1="3" y1="12" x2="21" y2="12"/><path d="M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>`,
  speaker:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7M19 5a9 9 0 0 1 0 14"/></svg>`,
  book:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z"/><path d="M4 19.5V22h16"/></svg>`,
  copy:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
  refresh:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>`,
  download:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
  send:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`,
  upload:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.4 6.6A9 9 0 0 0 5 12H3a2 2 0 0 0 0 4h18a2 2 0 0 0 0-4h-2"/></svg>`,
  bot:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="8" width="16" height="12" rx="2"/><path d="M12 2v4M8 14v2M16 14v2"/><circle cx="9" cy="11" r="1" fill="currentColor"/><circle cx="15" cy="11" r="1" fill="currentColor"/></svg>`
};

/* ====================== TOOLS DEFINITION ====================== */
const tools=[];
function T(o){tools.push(o)}

// 1 MP4 Downloader
T({id:'mp4',name:'MP4 Downloader',cat:['video','downloader'],catLabel:'Video',icon:'video',desc:'Unduh video TikTok atau Instagram Reels tanpa watermark.',
  tags:'tiktok instagram video download mp4 reels',
  body:`<div class="field"><input class="input" data-k="url" placeholder="Tempel link TikTok atau Instagram Reels..."></div>
        <button class="btn" data-act="go">${I.download}<span>Unduh</span></button>`,
  run:async(c,btn)=>{
    const url=$('[data-k=url]',c).value.trim();
    if(!url) return showErr(c,'Link wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'aio?url='+encodeURIComponent(url));
    setLoading(btn,false);
    if(!d.status||!d.result) return showErr(c,d.error||'Gagal mengambil video.');
    const r=d.result;const m=r.medias||[];
    const btns=m.map((x,i)=>{
      const label = x.type==='audio'?'Audio MP3':(x.quality||('Video '+(i+1))).replace(/_/g,' ');
      return `<button class="btn btn-download" data-dl="${esc(x.url)}" data-fn="newly-${i}.${x.extension||'mp4'}">${I.download}<span>${esc(label)}</span></button>`;
    }).join('');
    showResult(c,`<div class="info-row">
        <img src="${esc(r.thumbnail||'')}" loading="lazy" alt="">
        <div class="info-text"><b>${esc(r.title||'Tanpa judul')}</b><small>${esc(r.author||'')} • ${fmtMs(r.duration||0)}</small></div>
      </div>
      ${r.statistics?`<div class="stats-grid">
        <div class="stat"><b>${fmtNum(r.statistics.play_count)}</b>Play</div>
        <div class="stat"><b>${fmtNum(r.statistics.digg_count)}</b>Suka</div>
        <div class="stat"><b>${fmtNum(r.statistics.comment_count)}</b>Komentar</div>
        <div class="stat"><b>${fmtNum(r.statistics.share_count)}</b>Share</div></div>`:''}
      <div class="btn-row">${btns}</div>`);
    $$('[data-dl]',c).forEach(b=>b.onclick=()=>{
      const dlUrl=b.dataset.dl;
      const dlFn=b.dataset.fn||'newly-video.mp4';
      downloadFile(dlUrl,dlFn);
    });
    showNotif('success','Video ditemukan','Pilih kualitas untuk diunduh');
  }
});

// 2 Music Downloader
T({id:'music',name:'Music Downloader',cat:['music','downloader'],catLabel:'Music',icon:'music',desc:'Cari & unduh lagu dari SoundCloud.',
  tags:'soundcloud music mp3 lagu download',
  body:`<div class="field"><input class="input" data-k="q" placeholder="Cari lagu... (contoh: Feast Tarot)"></div>
        <button class="btn" data-act="go">${I.music}<span>Cari &amp; Unduh</span></button>`,
  run:async(c,btn)=>{
    const q=$('[data-k=q]',c).value.trim();if(!q) return showErr(c,'Kata kunci wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'soundcloud-play?query='+encodeURIComponent(q));
    setLoading(btn,false);
    if(!d.status||!d.result) return showErr(c,d.error||'Tidak ditemukan.');
    const r=d.result;
    showResult(c,`<div class="info-row">
        <img src="${esc(r.thumbnail||'')}" loading="lazy" alt="" style="border-radius:50%">
        <div class="info-text"><b>${esc(r.title)}</b><small>${esc(r.user||'')} • ${fmtMs(r.duration||0)}</small></div></div>
      ${r.source_url?`<a href="${esc(r.source_url)}" target="_blank" rel="noopener">Lihat di SoundCloud</a>`:''}
      <button class="btn btn-download" data-dl>${I.download}<span>Unduh MP3</span></button>`);
    $('[data-dl]',c).onclick=()=>downloadFile(r.download_url,(r.title||'audio')+'.mp3');
    showNotif('success','Lagu ditemukan',r.title);
  }
});

// 2.5 Foto/Video/Audio/Dokumen to URL
T({id:'media2url',name:'Media to URL',cat:['generator','image','video'],catLabel:'Generator',icon:'paint',desc:'Upload foto/video/audio/dokumen, dapat link permanen.',
  tags:'foto video audio dokumen pdf mp3 url upload link permanen hosting',
  body:`<div class="field"><button class="btn btn-ghost" data-act="upload-foto">${I.upload}<span>Upload Foto</span></button></div>
        <div class="field"><button class="btn btn-ghost" data-act="upload-video">${I.upload}<span>Upload Video</span></button></div>
        <div class="field"><button class="btn btn-ghost" data-act="upload-audio">${I.upload}<span>Upload Audio</span></button></div>
        <div class="field"><button class="btn btn-ghost" data-act="upload-dokumen">${I.upload}<span>Upload Dokumen</span></button></div>
        <div class="field" data-k="result-box" style="display:none">
          <input class="input" data-k="result-url" readonly>
          <button class="btn" data-act="copy-url" style="margin-top:8px">📋 Copy Link</button>
        </div>`,
  init:(c)=>{
    const ACCEPT_MAP={foto:'image/*',video:'video/*',audio:'audio/*',dokumen:'.pdf,.doc,.docx,.xls,.xlsx,.txt'};
    const LABEL_MAP={foto:'Foto',video:'Video',audio:'Audio',dokumen:'Dokumen'};
    const handleUpload=(type)=>{
      const inp=document.createElement('input');
      inp.type='file';
      inp.accept=ACCEPT_MAP[type];
      inp.onchange=async()=>{
        const f=inp.files[0];if(!f)return;
        const btn=$(`[data-act="upload-${type}"]`,c);
        setLoading(btn,true);
        const reader=new FileReader();
        reader.onload=async()=>{
          const base64=reader.result;
          try{
            await waitAPIReady();
            const r=await fetch(API+'media/upload',{
              method:'POST',
              headers:{'Content-Type':'application/json'},
              body:JSON.stringify({type, filename:f.name, base64, mimetype:f.type})
            });
            const d=await r.json();
            setLoading(btn,false);
            if(d.status){
              const fullUrl=window.location.origin+d.short_path;
              $('[data-k=result-url]',c).value=fullUrl;
              $('[data-k=result-box]',c).style.display='block';
              showNotif('success','Upload berhasil',LABEL_MAP[type]);
            }else{
              showNotif('error','Gagal upload',d.error||'Unknown error');
            }
          }catch(e){
            setLoading(btn,false);
            showNotif('error','Gagal upload',e.message);
          }
        };
        reader.readAsDataURL(f);
      };
      inp.click();
    };
    $('[data-act="upload-foto"]',c).onclick=()=>handleUpload('foto');
    $('[data-act="upload-video"]',c).onclick=()=>handleUpload('video');
    $('[data-act="upload-audio"]',c).onclick=()=>handleUpload('audio');
    $('[data-act="upload-dokumen"]',c).onclick=()=>handleUpload('dokumen');
    $('[data-act="copy-url"]',c).onclick=()=>{
      const url=$('[data-k=result-url]',c).value;
      navigator.clipboard.writeText(url);
      showNotif('success','Disalin','Link sudah disalin ke clipboard');
    };
  }
});


// 3 Newly AI chat
T({id:'newly-ai',name:'Newly AI',cat:['ai'],catLabel:'AI',icon:'brain',desc:'Tanya AI apa saja secara realtime.',
  tags:'ai chat newly chatbot tanya',
  body:`<div class="chat-box" data-k="chat"></div>
        <div class="row"><textarea class="textarea" data-k="msg" rows="2" placeholder="Tanya sesuatu..."></textarea></div>
        <button class="btn" data-act="go">${I.send}<span>Kirim</span></button>`,
  run:async(c,btn)=>{
    const ta=$('[data-k=msg]',c);const box=$('[data-k=chat]',c);
    const txt=ta.value.trim();if(!txt)return;
    box.insertAdjacentHTML('beforeend',`<div class="msg user">${esc(txt)}</div>`);
    ta.value='';box.scrollTop=box.scrollHeight;
    setLoading(btn,true);
    const d=await fetchAPI(API+'ai-realtime?text='+encodeURIComponent(txt));
    setLoading(btn,false);
    const a=(d.status?d.result:d.error)||'Tidak ada jawaban.';
    box.insertAdjacentHTML('beforeend',`<div class="msg ai">${esc(a)}</div>`);
    box.scrollTop=box.scrollHeight;
  }
});

// 4 AI HD
T({id:'aihd',name:'AI HD (Perjelas Foto)',cat:['image','ai'],catLabel:'Image',icon:'hd',desc:'Tingkatkan kualitas & ketajaman foto.',
  tags:'hd upscale enhance foto image super upload',
  body:`<div class="field"><input class="input" data-k="url" placeholder="URL gambar online..."></div>
        <div style="text-align:center;color:var(--text-secondary);font-size:12px;margin:4px 0">ATAU</div>
        <div class="field"><button class="btn btn-ghost" data-act="upload">${I.upload}<span>Upload Foto</span></button></div>
        <div class="radio-row">
          <label><input type="radio" name="v-{id}" value="superhd" checked><span>Super HD V1</span></label>
          <label><input type="radio" name="v-{id}" value="hdv2"><span>Super HD V2</span></label>
          <label><input type="radio" name="v-{id}" value="hdv3"><span>HD Wajah V3</span></label>
          <label><input type="radio" name="v-{id}" value="hdv4"><span>HD Wajah V4</span></label>
        </div>
        <button class="btn" data-act="go">${I.hd}<span>Proses</span></button>`,
  init:(el)=>{
    el.querySelector('[data-act=upload]').onclick=()=>{
      handleImageUpload((url)=>{
        $('[data-k=url]',el).value=url;
        showNotif('success','Siap diproses','URL publik berhasil');
      }, el);
    };
  },
  run:async(c,btn)=>{
    let url=$('[data-k=url]',c).value.trim();if(!url) return showErr(c,'URL atau gambar wajib diisi.');
    
    // Resolve hidden ID ke URL asli
    const actualUrl=getImageUrl(url);
    if(actualUrl) url=actualUrl;
    
    const v=$('input[type=radio]:checked',c).value;
    
    // Check cache dulu
    const cacheKey='aihd_'+url+'_'+v;
    let out=getCachedResult(cacheKey);
    
    if(!out){
      setLoading(btn,true);
      const param=(v==='superhd'||v==='hdv2')?'url':'image';
      const d=await fetchAPI(API+v+'?'+param+'='+encodeURIComponent(url));
      setLoading(btn,false);
      out=d?.result||(typeof d==='string'?d:null);
      if(!out) return showErr(c,d?.error||'Gagal memproses. Coba dengan URL gambar online.');
      // Cache hasil
      cacheResult(cacheKey, out);
    }
    
    showResult(c,`<img src="${esc(out)}" alt="hasil" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh Gambar</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'aihd.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'aihd');
    showNotif('success','Selesai','Gambar HD siap');
  }
});

// 5 Text to Image
T({id:'t2i',name:'Text to Image',cat:['ai','image','generator'],catLabel:'AI',icon:'paint',desc:'Buat gambar dari deskripsi teks.',
  tags:'text image ai generate prompt',
  body:`<div class="field"><textarea class="textarea" data-k="prompt" placeholder="Deskripsikan gambar... (contoh: kucing astronaut di bulan, gaya anime)"></textarea></div>
        <button class="btn" data-act="go">${I.paint}<span>Buat Gambar</span></button>`,
  run:async(c,btn)=>{
    const p=$('[data-k=prompt]',c).value.trim();if(!p) return showErr(c,'Prompt wajib diisi.');
    setLoading(btn,true);showResult(c,'<div class="skeleton" style="aspect-ratio:1;height:auto"></div>');
    const ep=API+'ai-text2img-pro?prompt='+encodeURIComponent(p);
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep);
    if(!out) return showErr(c,d.error||'Gagal membuat gambar.');
    showResult(c,`<img src="${esc(out)}" alt="" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh Gambar</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'t2i.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'t2i');
    showNotif('success','Gambar dibuat','Gambar AI siap');
  }
});

// 6 Arti Nama
T({id:'arti',name:'Arti Nama',cat:['fun','utility'],catLabel:'Fun',icon:'name',desc:'Cari makna dan arti nama.',
  tags:'arti nama meaning name',
  body:`<div class="field"><input class="input" data-k="n" placeholder="Masukkan namamu..."></div>
        <button class="btn" data-act="go">${I.name}<span>Cari Arti</span></button>`,
  run:async(c,btn)=>{
    const n=$('[data-k=n]',c).value.trim();if(!n) return showErr(c,'Nama wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'arti-nama?nama='+encodeURIComponent(n));
    setLoading(btn,false);
    const t=d.result||d.error;
    if(!d.status) return showErr(c,t||'Tidak ditemukan.');
    showResult(c,`<div class="result-head"><b>Arti: ${esc(n)}</b><button class="icon-btn" data-cp>${I.copy}</button></div><div>${esc(t)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(t);
    showNotif('success','Selesai','Arti nama ditemukan');
  }
});

// Cek Limit
T({id:'cek-limit',name:'📊 Cek Limit',cat:['utility'],catLabel:'Utilitas',icon:'info',desc:'Cek sisa limit harian kamu (basic/premium).',
  tags:'limit cek basic premium sisa quota',
  body:`<button class="btn" data-act="go">${I.info||I.star}<span>Cek Limit Sekarang</span></button>`,
  run:async(c,btn)=>{
    setLoading(btn,true);
    try{
      await waitAPIReady();
      const r=await fetch(API+'limit/status?identifier='+encodeURIComponent(DEVICE_ID));
      const d=await r.json();
      setLoading(btn,false);
      if(!d.status) return showErr(c,d.error||'Gagal cek limit.');
      const sisa=d.limit===null||d.limit===Infinity?'∞':Math.max(0,d.limit-d.used);
      const pct=d.limit&&d.limit!==Infinity?Math.min(100,Math.round((d.used/d.limit)*100)):0;
      showResult(c,`<div class="info-text">
        <div style="display:flex;justify-content:space-between;margin-bottom:6px"><b>Tipe Akun</b><span>${esc((d.type||'basic').toUpperCase())}</span></div>
        <div style="display:flex;justify-content:space-between;margin-bottom:6px"><b>Terpakai</b><span>${d.used}</span></div>
        <div style="display:flex;justify-content:space-between;margin-bottom:6px"><b>Total Limit</b><span>${d.limit===Infinity?'∞':d.limit}</span></div>
        ${d.bonus?`<div style="display:flex;justify-content:space-between;margin-bottom:6px"><b>Bonus Hari Ini</b><span>+${d.bonus}</span></div>`:''}
        <div style="display:flex;justify-content:space-between;margin-bottom:10px"><b>Sisa</b><span style="color:#4ade80">${sisa}</span></div>
        <div style="background:#27272a;border-radius:8px;height:8px;overflow:hidden"><div style="background:linear-gradient(90deg,#a855f7,#ec4899);height:100%;width:${pct}%"></div></div>
        ${d.type==='basic'?`<div style="margin-top:12px;font-size:12px;color:#94a3b8">Upgrade ke Premium untuk limit ${400} request/hari. Cek menu "Beli Premium".</div>`:''}
      </div>`);
    }catch(e){setLoading(btn,false);return showErr(c,e.message);}
  }
});

// Beli Premium (Saweria — nominal unik + auto aktivasi via webhook)
T({id:'premium',name:'💎 Beli Premium',cat:['utility'],catLabel:'Utilitas',icon:'star',desc:'Upgrade ke Premium (limit 400/hari) via Saweria.',
  tags:'premium upgrade beli bayar saweria subscription',
  body:`<div class="info-text" style="margin-bottom:10px">Premium: <b>Rp10.000/bulan</b> — limit harian naik jadi <b>400 request</b>.</div>
        <div class="field"><select class="input" data-k="days"><option value="30">1 Bulan (Rp10.000)</option><option value="90">3 Bulan (Rp30.000)</option><option value="365">1 Tahun (Rp120.000)</option></select></div>
        <button class="btn" data-act="go">${I.star}<span>Buat Pesanan</span></button>`,
  run:async(c,btn)=>{
    const days=$('[data-k=days]',c).value;
    setLoading(btn,true);
    try{
      await waitAPIReady();
      const r=await fetch(API+'saweria/create-order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({identifier:DEVICE_ID,days:parseInt(days)})});
      const d=await r.json();
      setLoading(btn,false);
      if(!d.status) return showErr(c,d.error||'Gagal membuat pesanan.');
      showResult(c,`<div class="info-text">
        <p>1. Buka QRIS Saweria kamu, transfer <b>tepat</b> nominal berikut (jangan dibulatkan):</p>
        <div style="font-size:24px;font-weight:700;text-align:center;margin:12px 0;color:#facc15">Rp${d.nominal.toLocaleString('id-ID')}</div>
        <p style="font-size:12px;color:#94a3b8">Pesanan kadaluarsa dalam ${d.expires_in_minutes} menit. Setelah transfer, status akan otomatis terupdate di bawah (cek otomatis tiap 5 detik).</p>
        <div data-k="order-status" style="margin-top:14px;padding:10px;border-radius:8px;background:#27272a;text-align:center">⏳ Menunggu pembayaran...</div>
      </div>`);
      const statusBox=c.querySelector('[data-k="order-status"]');
      const nominal=d.nominal;
      const poll=setInterval(async()=>{
        try{
          const sr=await fetch(API+'saweria/order-status?nominal='+nominal);
          const sd=await sr.json();
          if(sd.status&&sd.paid){
            clearInterval(poll);
            statusBox.style.background='#166534';
            statusBox.innerHTML='✅ Pembayaran diterima! Akun kamu sekarang Premium 🎉';
          }
        }catch(_){}
      },5000);
      // Stop polling otomatis setelah waktu kadaluarsa order
      setTimeout(()=>clearInterval(poll),(d.expires_in_minutes*60+30)*1000);
    }catch(e){setLoading(btn,false);return showErr(c,e.message);}
  }
});


T({id:'brat',name:'Brat Generator',cat:['generator','image','video'],catLabel:'Generator',icon:'brat',desc:'Buat gambar/video gaya brat dari teks.',
  tags:'brat text generator meme video',
  body:`<div class="field"><input class="input" data-k="t" placeholder="Ketik teks brat... (contoh: very demure)"></div>
        <div class="radio-row">
          <label><input type="radio" name="bv-{id}" value="brat" checked><span>Biasa</span></label>
          <label><input type="radio" name="bv-{id}" value="brathd"><span>HD</span></label>
          <label><input type="radio" name="bv-{id}" value="bratvid"><span>Video</span></label>
        </div>
        <button class="btn" data-act="go">${I.brat}<span>Buat</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    const v=$('input[type=radio]:checked',c).value;
    setLoading(btn,true);
    const ep=API+v+'?text='+encodeURIComponent(t);
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    if(!d.status&&!d.result) return showErr(c,d.error||'Gagal membuat brat. Coba lagi.');
    const out=d.result||(d._isMedia&&ep)||ep;
    if(!out) return showErr(c,'Hasil kosong. API error.');
    const isVid=v==='bratvid';
    showResult(c,(isVid?`<video src="${esc(out)}" controls loop muted playsinline style="max-height:300px"></video>`:`<img src="${esc(out)}" loading="lazy" style="max-height:300px">`)+
      `<div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        ${isVid?'':`<button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>`}
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'brat.'+(isVid?'mp4':'png'));
    if(!isVid) $('[data-sticker]',c).onclick=()=>convertToSticker(out,'brat');
    showNotif('success','Brat dibuat','File siap diunduh');
  }
});

// 8 Lyrics
T({id:'lyrics',name:'Cari Lirik Lagu',cat:['music'],catLabel:'Music',icon:'mic',desc:'Cari lirik lagu favoritmu.',
  tags:'lirik lyrics lagu music song',
  body:`<div class="field"><input class="input" data-k="q" placeholder="Judul atau artis... (contoh: Tulus Hati-Hati)"></div>
        <button class="btn" data-act="go">${I.mic}<span>Cari Lirik</span></button>`,
  run:async(c,btn)=>{
    const q=$('[data-k=q]',c).value.trim();if(!q) return showErr(c,'Judul wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'lyrics?q='+encodeURIComponent(q));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||'Tidak ditemukan.');
    const r=d.result||{};
    const lirik=r.lyrics||r.lirik||r.text||(typeof r==='string'?r:JSON.stringify(r,null,2));
    const title=r.title||q;
    showResult(c,`<div class="result-head"><b>${esc(title)}</b><button class="icon-btn" data-cp>${I.copy}</button></div><pre>${esc(lirik)}</pre>`);
    $('[data-cp]',c).onclick=()=>copyText(lirik);
    showNotif('success','Selesai','Lirik ditemukan');
  }
});

// 9 Doa Islam
T({id:'doa',name:'Doa Islam',cat:['islam'],catLabel:'Islam',icon:'moon',desc:'Cari doa harian dengan teks Arab & artinya.',
  tags:'doa islam arab muslim',
  body:`<div class="field"><input class="input" data-k="q" placeholder="Cari doa... (contoh: tidur, makan)"></div>
        <button class="btn" data-act="go">${I.moon}<span>Cari Doa</span></button>`,
  run:async(c,btn)=>{
    const q=$('[data-k=q]',c).value.trim();if(!q) return showErr(c,'Kata kunci wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'doa?q='+encodeURIComponent(q));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||'Tidak ditemukan.');
    const arr=Array.isArray(d.result)?d.result:[d.result];
    const items=arr.filter(Boolean).map(x=>{
      const arab=x.arab||x.arabic||x.ar||'';
      const latin=x.latin||x.translit||'';
      const arti=x.arti||x.translation||x.indo||x.terjemah||'';
      const judul=x.judul||x.title||x.doa||'Doa';
      return `<div style="display:flex;flex-direction:column;gap:6px;border-top:1px solid var(--border);padding-top:8px">
        <b>${esc(judul)}</b>
        ${arab?`<div class="arab">${esc(arab)}</div>`:''}
        ${latin?`<div class="latin">${esc(latin)}</div>`:''}
        ${arti?`<div class="arti">${esc(arti)}</div>`:''}
      </div>`;
    }).join('');
    showResult(c,items||`<pre>${esc(JSON.stringify(d.result,null,2))}</pre>`);
    showNotif('success','Doa ditemukan','Lihat hasil di bawah');
  }
});

// 10 Emoji to GIF
T({id:'e2g',name:'Emoji to GIF',cat:['fun','generator'],catLabel:'Fun',icon:'smile',desc:'Ubah satu emoji menjadi GIF animasi.',
  tags:'emoji gif fun animation',
  body:`<div class="field"><label style="font-size:12px;color:var(--text-secondary);font-weight:500">Ketik atau pilih emoji dari keyboard</label>
          <input class="input" data-k="emoji" placeholder="Ketik emoji disini... (contoh: 😀)" maxlength="8" style="font-size:28px;text-align:center;letter-spacing:4px">
        </div>
        <button class="btn" data-act="go">${I.smile}<span>Buat GIF</span></button>`,
  run:async(c,btn)=>{
    const raw=$('[data-k=emoji]',c).value.trim();
    // Ambil emoji pertama dari input (support multi-codepoint emoji)
    const segs=[...new Intl.Segmenter(undefined,{granularity:'grapheme'}).segment(raw)];
    const e=segs[0]?.segment||'';
    if(!e) return showErr(c,'Masukkan emoji terlebih dahulu.');
    setLoading(btn,true);
    const ep=API+'emoji-to-gif?q='+encodeURIComponent(e);
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    if(!d.status&&!d.result) return showErr(c,d.error||'Gagal buat GIF emoji.');
    const out=d.result||(d._isMedia&&ep)||ep;
    if(!out) return showErr(c,'GIF tidak tersedia.');
    const imgSrc=out+(out.includes('?')?'&':'?')+'t='+Date.now();
    showResult(c,`<img src="${esc(imgSrc)}" alt="emoji gif" loading="lazy" style="max-height:300px;width:auto;margin:0 auto;display:block">
      <div style="display:flex;gap:10px;margin-top:10px;justify-content:center">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh GIF</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'emoji.gif');
    $('[data-sticker]',c).onclick=()=>convertToSticker(imgSrc,'emoji');
    showNotif('success','GIF dibuat','Emoji animasi siap');
  }
});

// 11 Gemini AI
T({id:'gemini',name:'Gemini AI',cat:['ai'],catLabel:'AI',icon:'star',desc:'Tanya apapun ke Gemini AI.',
  tags:'gemini ai google chat',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Tanya Gemini AI apa saja..."></textarea></div>
        <button class="btn" data-act="go">${I.star}<span>Tanya</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Pertanyaan wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'gemini-ai?text='+encodeURIComponent(t));
    setLoading(btn,false);
    const r=d.result||d.error;
    if(!d.status) return showErr(c,r||'Gagal.');
    showResult(c,`<div class="result-head"><b>Jawaban Gemini</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="white-space:pre-wrap">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});

// 12 IQC
T({id:'iqc',name:'IQC Generator',cat:['ai','generator'],catLabel:'AI',icon:'avatar',desc:'Buat karakter IQC dari deskripsi.',
  tags:'iqc avatar character ai',
  body:`<div class="radio-row">
          <label><input type="radio" name="iv-{id}" value="iqc" checked><span>V1</span></label>
          <label><input type="radio" name="iv-{id}" value="iqcv2"><span>V2</span></label>
        </div>
        <div class="field"><input class="input" data-k="prompt" placeholder="Deskripsi karakter..."></div>
        <div class="row" data-v2 style="display:none">
          <input class="input" data-k="jam" placeholder="Jam (14:30)">
          <input class="input" data-k="batre" placeholder="Batre (85)">
        </div>
        <button class="btn" data-act="go">${I.avatar}<span>Buat IQC</span></button>`,
  init:c=>{
    $$('input[type=radio]',c).forEach(r=>r.onchange=()=>{
      $('[data-v2]',c).style.display=r.value==='iqcv2'&&r.checked?'flex':'none';
    });
  },
  run:async(c,btn)=>{
    const p=$('[data-k=prompt]',c).value.trim();if(!p) return showErr(c,'Prompt wajib diisi.');
    const v=$('input[type=radio]:checked',c).value;
    let ep=API+v+'?prompt='+encodeURIComponent(p);
    if(v==='iqcv2'){
      const jam=$('[data-k=jam]',c).value.trim()||'12:00';
      const batre=$('[data-k=batre]',c).value.trim()||'80';
      ep+='&jam='+encodeURIComponent(jam)+'&batre='+encodeURIComponent(batre);
    }
    setLoading(btn,true);
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    if(!d.status&&!d.result) return showErr(c,d.error||'Gagal buat IQC. API sedang error.');
    const out=d.result||(d._isMedia&&ep)||ep;
    if(!out) return showErr(c,'Hasil kosong. Coba prompt lain.');
    showResult(c,`<img src="${esc(out)}" loading="lazy" style="max-height:300px">
      <div style="display:flex;gap:10px;margin-top:10px;justify-content:center">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'iqc.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'iqc');
    showNotif('success','IQC dibuat','Karakter siap');
  }
});

// 13 Jadwal Sholat
T({id:'sholat',name:'Jadwal Sholat',cat:['islam'],catLabel:'Islam',icon:'mosque',desc:'Cek jadwal sholat berdasarkan kota.',
  tags:'sholat jadwal islam waktu kota',
  body:`<div class="field"><input class="input" data-k="kota" placeholder="Nama kota... (contoh: Jakarta)"></div>
        <button class="btn" data-act="go">${I.mosque}<span>Cek Jadwal</span></button>`,
  run:async(c,btn)=>{
    const k=$('[data-k=kota]',c).value.trim();if(!k) return showErr(c,'Kota wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'jadwal-sholat?kota='+encodeURIComponent(k));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||'Kota tidak ditemukan.');
    // API bisa return jadwal di d.result ATAU langsung di root d
    const src=d.result||d;
    const j=src.jadwal||src.times||src.waktu||src.prayers||src.data||src;
    const today=Array.isArray(j)?j[0]:j;
    const slots=[
      ['Imsak',today.imsak||today.Imsak],
      ['Subuh',today.subuh||today.Subuh||today.fajr||today.Fajr],
      ['Dzuhur',today.dzuhur||today.Dzuhur||today.dhuhur||today.dhuhr||today.Dhuhr||today.zuhur],
      ['Ashar',today.ashar||today.Ashar||today.asr||today.Asr],
      ['Maghrib',today.maghrib||today.Maghrib],
      ['Isya',today.isya||today.Isya||today.isha||today.Isha]
    ];
    const lokasi=src.lokasi||src.kota||src.city||src.location||d.lokasi||d.kota||k;
    const tanggal=src.tanggal||src.date||src.hari||d.tanggal||d.date||'';
    const hasData=slots.some(([,v])=>v);
    if(!hasData) return showErr(c,'Format jadwal tidak dikenali. Coba kota lain.');
    showResult(c,`<b>${esc(lokasi)}</b>${tanggal?`<div style="font-size:12px;color:var(--text-secondary)">${esc(tanggal)}</div>`:''}<div class="prayer-grid">${slots.map(([n,v])=>`<div class="prayer"><span>${n}</span><b>${esc(v||'-')}</b></div>`).join('')}</div>`);
    showNotif('success','Jadwal ditemukan',lokasi);
  }
});

// 14 Nano Banana
T({id:'nano',name:'Nano Banana',cat:['ai','image'],catLabel:'AI',icon:'lens',desc:'Analisis isi sebuah foto dengan AI.',
  tags:'nano banana ai analisis foto vision upload',
  body:`<div class="field"><input class="input" data-k="url" placeholder="URL gambar..."></div>
        <div style="text-align:center;color:var(--text-secondary);font-size:12px;margin:4px 0">ATAU</div>
        <div class="field"><button class="btn btn-ghost" data-act="upload">${I.upload}<span>Upload Foto</span></button></div>
        <div class="field"><textarea class="textarea" data-k="p" placeholder="Tanya sesuatu tentang gambar..."></textarea></div>
        <button class="btn" data-act="go">${I.lens}<span>Analisis</span></button>`,
  init:(el)=>{
    el.querySelector('[data-act=upload]').onclick=()=>{
      handleImageUpload((url)=>{
        $('[data-k=url]',el).value=url;
        showNotif('success','Siap dianalisis','URL publik berhasil');
      }, el);
    };
  },
  run:async(c,btn)=>{
    let u=$('[data-k=url]',c).value.trim();const p=$('[data-k=p]',c).value.trim();
    if(!u||!p) return showErr(c,'Gambar & pertanyaan wajib diisi.');
    
    // Resolve hidden ID
    const actualUrl=getImageUrl(u);
    if(actualUrl) u=actualUrl;
    
    // Check cache
    const cacheKey='nano_'+u+'_'+p;
    let r=getCachedResult(cacheKey);
    
    if(!r){
      setLoading(btn,true);
      const d=await fetchAPI(API+'nano-banana?url='+encodeURIComponent(u)+'&prompt='+encodeURIComponent(p));
      setLoading(btn,false);
      r=d.result||d.error;
      if(!d.status) return showErr(c,r||'Gagal menganalisis gambar.');
      cacheResult(cacheKey, r);
    }
    
    showResult(c,`<img src="${esc(u)}" loading="lazy" style="max-height:200px;object-fit:contain"><div style="white-space:pre-wrap">${esc(r)}</div>`);
  }
});

// 15 NGL Spam
T({id:'ngl',name:'NGL Spam',cat:['fun'],catLabel:'Fun',icon:'envelope',desc:'Kirim banyak pesan NGL anonim.',
  tags:'ngl spam pesan kirim',
  body:`<div class="field"><input class="input" data-k="link" placeholder="Link NGL (contoh: ngl.link/namauser)"></div>
        <div class="field"><input class="input" data-k="pesan" placeholder="Isi pesan..."></div>
        <div class="field"><input class="input" type="number" data-k="jum" placeholder="Jumlah (max 50)" min="1" max="50"></div>
        <button class="btn" data-act="go">${I.envelope}<span>Kirim Spam</span></button>`,
  run:async(c,btn)=>{
    const l=$('[data-k=link]',c).value.trim();const p=$('[data-k=pesan]',c).value.trim();const j=$('[data-k=jum]',c).value.trim();
    if(!l||!p||!j) return showErr(c,'Semua field wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'ngl-spam?link='+encodeURIComponent(l)+'&pesan='+encodeURIComponent(p)+'&jumlah='+encodeURIComponent(j));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||'Gagal mengirim.');
    showResult(c,`<b>Terkirim</b><div>${esc(typeof d.result==='string'?d.result:(j+' pesan terkirim ke '+l))}</div>`);
    showNotif('success','Spam terkirim',j+' pesan terkirim');
  }
});

// 16 Pantun
T({id:'pantun',name:'Pantun Random',cat:['fun','generator'],catLabel:'Fun',icon:'pen',desc:'Acak pantun lucu & nasihat.',
  tags:'pantun random fun puisi',
  body:`<button class="btn" data-act="go">${I.refresh}<span>Acak Pantun</span></button>`,
  run:async(c,btn)=>{
    setLoading(btn,true);
    // Coba beberapa endpoint pantun
    let d=await fetchAPI(API+'pantun');
    if(!d.status) d=await fetchAPI(API+'pantun-random');
    if(!d.status) d=await fetchAPI(API+'random-pantun');
    setLoading(btn,false);
    // API return pantun di root (d.pantun) ATAU di d.result
    const isHTML=v=>typeof v==='string'&&(v.includes('<!DOCTYPE')||v.includes('<html'));
    const clean=v=>(typeof v==='string'&&v.length>5&&!isHTML(v))?v:'';
    const r=d.result;
    let t=clean(d.pantun)||clean(d.text)||clean(d.content)||clean(d.data)||clean(d.hasil)||
          clean(d.pesan)||(typeof r==='string'?clean(r):'')||
          clean(r?.pantun)||clean(r?.text)||clean(r?.content)||clean(r?.data)||
          clean(r?.hasil)||clean(r?.pesan)||clean(r?.message)||
          (Array.isArray(r)?clean(r.join('\n')):'');
    if(!t&&r&&typeof r==='object'){
      const vals=Object.values(r).filter(v=>typeof v==='string'&&v.length>5&&!isHTML(v));
      if(vals.length) t=vals[0];
    }
    if(!t&&d&&typeof d==='object'){
      const vals=Object.values(d).filter(v=>typeof v==='string'&&v.length>5&&!isHTML(v));
      if(vals.length) t=vals[0];
    }
    if(!t) return showErr(c,'API pantun sedang tidak tersedia. Coba lagi.');
    showResult(c,`<div class="result-head"><b>Pantun</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="font-style:italic;white-space:pre-wrap">"${esc(t)}"</div>`);
    $('[data-cp]',c).onclick=()=>copyText(t);
  }
});

// 17 Pinterest
T({id:'pin',name:'Pinterest Downloader',cat:['downloader','image'],catLabel:'Downloader',icon:'pin',desc:'Unduh gambar/video dari Pinterest.',
  tags:'pinterest download pin image video',
  body:`<div class="field"><input class="input" data-k="url" placeholder="Tempel link Pinterest..."></div>
        <button class="btn" data-act="go">${I.download}<span>Unduh</span></button>`,
  run:async(c,btn)=>{
    const u=$('[data-k=url]',c).value.trim();if(!u) return showErr(c,'Link wajib.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'pin-down?url='+encodeURIComponent(u));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result;const url=typeof r==='string'?r:(r.url||r.video||r.image);
    const isVid=/\.mp4(\?|$)/i.test(url);
    showResult(c,(isVid?`<video src="${esc(url)}" controls playsinline></video>`:`<img src="${esc(url)}" loading="lazy">`)+
      `<button class="btn btn-download" data-dl>${I.download}<span>Unduh ${isVid?'Video':'Gambar'}</span></button>`);
    $('[data-dl]',c).onclick=()=>downloadFile(url,'pinterest.'+(isVid?'mp4':'jpg'));
    showNotif('success','Pinterest ditemukan','Siap diunduh');
  }
});

// 18 QC Black
T({id:'qcblack',name:'QC Black',cat:['generator','image'],catLabel:'Generator',icon:'chatcard',desc:'Buat kartu QC hitam dengan teks & avatar.',
  tags:'qc black quote card',
  body:`<div class="field"><textarea class="textarea" data-k="q" placeholder="Teks quote..."></textarea></div>
        <div class="field"><input class="input" data-k="user" placeholder="Username (contoh: @zenn)"></div>
        <div class="field"><input class="input" data-k="ava" placeholder="URL avatar (opsional)"></div>
        <button class="btn" data-act="go">${I.chatcard}<span>Buat QC Black</span></button>`,
  run:async(c,btn)=>{
    const q=$('[data-k=q]',c).value.trim();const u=$('[data-k=user]',c).value.trim();const a=$('[data-k=ava]',c).value.trim();
    if(!q||!u) return showErr(c,'Teks & username wajib.');
    setLoading(btn,true);
    let ep=API+'qc-black?q='+encodeURIComponent(q)+'&username='+encodeURIComponent(u);
    if(a) ep+='&avatar='+encodeURIComponent(a);
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'qcblack.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'qcblack');
    showNotif('success','QC dibuat','Kartu siap');
  }
});

// 19 QR Create
T({id:'qrc',name:'QR Create',cat:['generator','utility'],catLabel:'Utilitas',icon:'qr',desc:'Buat QR Code dari teks atau link.',
  tags:'qr code generator create barcode',
  body:`<div class="field"><input class="input" data-k="t" placeholder="Teks atau link..."></div>
        <button class="btn" data-act="go">${I.qr}<span>Buat QR</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib.');
    setLoading(btn,true);
    const ep=API+'qr-create?text='+encodeURIComponent(t);
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" alt="qr" style="max-width:220px;margin:0 auto;background:#fff;padding:8px;border-radius:8px"><button class="btn btn-download" data-dl>${I.download}<span>Unduh QR</span></button>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'qr.png');
    showNotif('success','QR dibuat','QR Code siap');
  }
});

// 20 QR Detect
T({id:'qrd',name:'QR Detect',cat:['utility'],catLabel:'Utilitas',icon:'scan',desc:'Scan isi QR Code dari gambar atau URL.',
  tags:'qr detect scan reader upload',
  body:`<div class="field"><input class="input" data-k="u" placeholder="URL gambar QR..."></div>
        <div style="text-align:center;color:var(--text-secondary);font-size:12px;margin:4px 0">ATAU</div>
        <div class="field"><button class="btn btn-ghost" data-act="upload">${I.upload}<span>Upload Gambar</span></button></div>
        <button class="btn" data-act="go">${I.scan}<span>Scan QR</span></button>`,
  init:(el)=>{
    el.querySelector('[data-act=upload]').onclick=()=>{
      handleImageUpload((url)=>{
        $('[data-k=u]',el).value=url;
        showNotif('success','Siap scan','URL publik berhasil');
      }, el);
    };
  },
  run:async(c,btn)=>{
    let u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'URL atau gambar wajib.');
    
    // Resolve hidden ID
    const actualUrl=getImageUrl(u);
    if(actualUrl) u=actualUrl;
    
    // Check cache
    const cacheKey='qrd_'+u;
    let cached=getCachedResult(cacheKey);
    let t,d;
    
    if(!cached){
      setLoading(btn,true);
      const ep=API+'qr-detect?url='+encodeURIComponent(u);
      d=await fetchAPI(ep);
      setLoading(btn,false);
      if(!d.status) return showErr(c,d.error||'QR tidak ditemukan.');
      t=typeof d.result==='string'?d.result:(d.result?.text||JSON.stringify(d.result,null,2));
      cacheResult(cacheKey, t);
    }else{
      t=cached;
    }
    
    showResult(c,`<div class="result-head"><b>Isi QR</b><button class="icon-btn" data-cp>${I.copy}</button></div><pre>${esc(t)}</pre>`);
    $('[data-cp]',c).onclick=()=>copyText(t);
  }
});

// 21 Quote Bucin
T({id:'qbucin',name:'Quote Bucin',cat:['fun','generator'],catLabel:'Fun',icon:'heart',desc:'Acak quote bucin romantis.',
  tags:'quote bucin cinta love romantis',
  body:`<button class="btn" data-act="go">${I.refresh}<span>Quote Bucin</span></button>`,
  run:async(c,btn)=>{
    setLoading(btn,true);
    const d=await fetchAPI(API+'quote-bucin');
    setLoading(btn,false);
    if(!d.status&&!d.result&&!d.quote&&!d.text&&!d.content) return showErr(c,d.error||'Gagal.');
    const isHTML=v=>typeof v==='string'&&(v.includes('<!DOCTYPE')||v.includes('<html'));
    const clean=v=>(typeof v==='string'&&v.length>3&&!isHTML(v)&&v!=='null')?v:'';
    const r=d.result;
    // Cek root level dulu (d.quote, d.text, dll), lalu d.result
    const t=clean(d.quote)||clean(d.text)||clean(d.content)||clean(d.data)||clean(d.hasil)||clean(d.pesan)||
      (typeof r==='string'?clean(r):'')||
      clean(r?.quote)||clean(r?.text)||clean(r?.content)||clean(r?.data)||clean(r?.hasil)||
      (Array.isArray(r)?clean(r[0]):'');
    if(!t) return showErr(c,'Quote kosong dari server.');
    showResult(c,`<div class="result-head"><b>Quote</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="font-style:italic">"${esc(t)}"</div>`);
    $('[data-cp]',c).onclick=()=>copyText(t);
  }
});

// 22 Meme
T({id:'meme',name:'Meme Random',cat:['fun','generator'],catLabel:'Fun',icon:'meme',desc:'Acak gambar meme lucu.',
  tags:'meme random fun lucu',
  body:`<button class="btn" data-act="go">${I.refresh}<span>Acak Meme</span></button>`,
  run:async(c,btn)=>{
    setLoading(btn,true);
    const ep=API+'meme';
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    if(typeof out!=='string') return showErr(c,'Gagal.');
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh Meme</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'meme.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'meme');
    showNotif('success','Meme dimuat','Selamat tertawa');
  }
});

// 23 Loli
T({id:'loli',name:'Loli Random',cat:['generator'],catLabel:'Generator',icon:'anime',desc:'Acak gambar loli anime.',
  tags:'loli anime random',
  body:`<button class="btn" data-act="go">${I.refresh}<span>Acak</span></button>`,
  run:async(c,btn)=>{
    setLoading(btn,true);
    const ep=API+'loli';const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'loli.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'loli');
  }
});

// 24 Papayang
T({id:'papayang',name:'Papayang Random',cat:['generator','fun'],catLabel:'Generator',icon:'hearts',desc:'Acak konten papayang.',
  tags:'papayang random generator',
  body:`<button class="btn" data-act="go">${I.refresh}<span>Acak</span></button>`,
  run:async(c,btn)=>{
    setLoading(btn,true);
    const ep=API+'papayang';const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'papayang.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'papayang');
  }
});

// 25 Waifu
T({id:'waifu',name:'Waifu Random',cat:['generator'],catLabel:'Generator',icon:'waifu',desc:'Acak gambar waifu anime.',
  tags:'waifu anime random',
  body:`<button class="btn" data-act="go">${I.refresh}<span>Acak</span></button>`,
  run:async(c,btn)=>{
    setLoading(btn,true);
    const ep=API+'waifu';const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'waifu.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'waifu');
  }
});

// 26 Remove BG
T({id:'rmbg',name:'Remove Background',cat:['image'],catLabel:'Image',icon:'scissor',desc:'Hapus background dari sebuah gambar.',
  tags:'remove background png transparent upload',
  body:`<div class="field"><input class="input" data-k="u" placeholder="URL gambar..."></div>
        <div style="text-align:center;color:var(--text-secondary);font-size:12px;margin:4px 0">ATAU</div>
        <div class="field"><button class="btn btn-ghost" data-act="upload">${I.upload}<span>Upload Foto</span></button></div>
        <button class="btn" data-act="go">${I.scissor}<span>Hapus Background</span></button>`,
  init:(el)=>{
    el.querySelector('[data-act=upload]').onclick=()=>{
      handleImageUpload((url)=>{
        $('[data-k=u]',el).value=url;
        showNotif('success','Siap diproses','URL publik berhasil');
      }, el);
    };
  },
  run:async(c,btn)=>{
    let u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'URL atau gambar wajib diisi.');
    
    // Resolve hidden ID
    const actualUrl=getImageUrl(u);
    if(actualUrl) u=actualUrl;
    
    // Check cache
    const cacheKey='rmbg_'+u;
    let out=getCachedResult(cacheKey);
    
    if(!out){
      setLoading(btn,true);
      const ep=API+'removebg?url='+encodeURIComponent(u);
      const d=await fetchAPI(ep);
      setLoading(btn,false);
      out=d.result||(d._isMedia&&ep)||ep;
      cacheResult(cacheKey, out);
    }
    
    showResult(c,`<div class="checker"><img src="${esc(out)}" loading="lazy"></div>
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh PNG</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'nobg.png');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'nobg');
    showNotif('success','Selesai','Background dihapus');
  }
});

// 27 SMeme
T({id:'smeme',name:'SMeme Generator',cat:['generator','image'],catLabel:'Generator',icon:'smeme',desc:'Buat meme bertulisan atas-bawah.',
  tags:'smeme meme generator custom',
  body:`<div class="field"><input class="input" data-k="ta" placeholder="Teks atas..."></div>
        <div class="field"><input class="input" data-k="tb" placeholder="Teks bawah..."></div>
        <div class="field"><input class="input" data-k="bg" placeholder="URL gambar latar..."></div>
        <button class="btn" data-act="go">${I.smeme}<span>Buat Meme</span></button>`,
  run:async(c,btn)=>{
    const ta=$('[data-k=ta]',c).value.trim();const tb=$('[data-k=tb]',c).value.trim();const bg=$('[data-k=bg]',c).value.trim();
    if(!ta||!tb||!bg) return showErr(c,'Semua field wajib.');
    setLoading(btn,true);
    const ep=API+'smeme?text_atas='+encodeURIComponent(ta)+'&text_bawah='+encodeURIComponent(tb)+'&background='+encodeURIComponent(bg);
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'smeme.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'smeme');
  }
});

// 28 Stickerly
T({id:'sticker',name:'Stickerly Search',cat:['generator'],catLabel:'Generator',icon:'sticker',desc:'Cari stiker dari Stickerly.',
  tags:'stiker sticker stickerly search',
  body:`<div class="field"><input class="input" data-k="q" placeholder="Cari stiker... (love, cute)"></div>
        <button class="btn" data-act="go">${I.sticker}<span>Cari Stiker</span></button>`,
  run:async(c,btn)=>{
    const q=$('[data-k=q]',c).value.trim();if(!q) return showErr(c,'Kata kunci wajib.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'stickerly?q='+encodeURIComponent(q));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||'Tidak ditemukan.');
    // Coba berbagai struktur array dari API
    // API return array di "results" (plural), tiap item punya .url
    const r=d.result;
    let arr=[];
    if(Array.isArray(d.results)) arr=d.results;      // ← struktur utama
    else if(Array.isArray(r)) arr=r;
    else if(r?.stickers) arr=r.stickers;
    else if(r?.images) arr=r.images;
    else if(r?.data) arr=Array.isArray(r.data)?r.data:[r.data];
    else if(r?.result) arr=Array.isArray(r.result)?r.result:[r.result];
    else if(r&&typeof r==='object') arr=Object.values(r).find(v=>Array.isArray(v))||[];
    // Extract URL dari setiap item
    const urls=arr.map(x=>{
      if(typeof x==='string') return x;
      return x?.url||x?.image||x?.src||x?.gif||x?.webp||x?.thumbnail||x?.preview||null;
    }).filter(u=>u&&typeof u==='string'&&(u.startsWith('http')||u.startsWith('//'))).slice(0,12);
    if(!urls.length) return showErr(c,'Stiker tidak ditemukan. Coba kata kunci lain (Inggris lebih baik, contoh: love, happy, cat).');
    showResult(c,`<div class="sticker-grid">${urls.map(u=>`<img src="${esc(u)}" data-dl="${esc(u)}" loading="lazy" onerror="this.style.display='none'">`).join('')}</div><small style="color:var(--text-secondary)">Klik stiker untuk mengunduh</small>`);
    $$('.sticker-grid img',c).forEach(img=>img.onclick=()=>downloadFile(img.dataset.dl,'sticker.webp'));
    showNotif('success','Stiker ditemukan',urls.length+' stiker');
  }
});

// 29 Tafsir Mimpi
T({id:'tafsir',name:'Tafsir Mimpi',cat:['fun','islam'],catLabel:'Islam',icon:'moon',desc:'Cari tafsir dari mimpi yang dialami.',
  tags:'tafsir mimpi dream',
  body:`<div class="field"><input class="input" data-k="m" placeholder="Ceritakan mimpimu... (terbang, gigi copot)"></div>
        <button class="btn" data-act="go">${I.eye}<span>Tafsir</span></button>`,
  run:async(c,btn)=>{
    const m=$('[data-k=m]',c).value.trim();if(!m) return showErr(c,'Kata kunci wajib.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'tafsir-mimpi?mimpi='+encodeURIComponent(m));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const t=typeof d.result==='string'?d.result:JSON.stringify(d.result,null,2);
    showResult(c,`<div class="result-head"><b>Tafsir: ${esc(m)}</b><button class="icon-btn" data-cp>${I.copy}</button></div><pre>${esc(t)}</pre>`);
    $('[data-cp]',c).onclick=()=>copyText(t);
  }
});

// 30 TikTok Stalk
T({id:'tts',name:'TikTok Stalk',cat:['utility'],catLabel:'Utilitas',icon:'tt',desc:'Cek info profil pengguna TikTok.',
  tags:'tiktok stalk profile user',
  body:`<div class="field"><input class="input" data-k="u" placeholder="Username TikTok (tanpa @)..."></div>
        <button class="btn" data-act="go">${I.tt}<span>Stalk</span></button>`,
  run:async(c,btn)=>{
    const u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'Username wajib.');
    setLoading(btn,true);
    // Coba beberapa endpoint
    let d=await fetchAPI(API+'tiktokstalk?username='+encodeURIComponent(u));
    if(!d.status) d=await fetchAPI(API+'tiktok-stalk?username='+encodeURIComponent(u));
    if(!d.status) d=await fetchAPI(API+'tiktok-profile?username='+encodeURIComponent(u));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||'Profil tidak ditemukan atau API sedang error (500). Coba lagi nanti.');
    const r=d.result||d.data||{};
    // Support berbagai struktur user object
    const user=r.user||r.userInfo?.user||r;
    const stats=r.stats||r.userInfo?.stats||r;
    showResult(c,`<div class="tt-profile">
        <img src="${esc(user.avatarThumb||user.avatar||user.avatarLarger||user.avatarMedium||'')}" alt="" onerror="this.style.visibility='hidden'">
        <div><b>${esc(user.nickname||user.name||u)}</b><br><small style="color:var(--text-secondary)">@${esc(user.uniqueId||user.username||u)}</small></div>
      </div>
      <div class="tt-stats">
        <div class="stat"><b>${fmtNum(stats.followerCount||stats.followers||r.followers)}</b>Followers</div>
        <div class="stat"><b>${fmtNum(stats.followingCount||stats.following||r.following)}</b>Following</div>
        <div class="stat"><b>${fmtNum(stats.heartCount||stats.heart||stats.likeCount||stats.likes||r.heart)}</b>Likes</div>
      </div>
      ${user.signature||user.bio?`<div style="color:var(--text-secondary)">${esc(user.signature||user.bio)}</div>`:''}`);
    showNotif('success','Profil ditemukan',user.nickname||u);
  }
});

// 31 To Anime
T({id:'toanime',name:'To Anime',cat:['image'],catLabel:'Image',icon:'anime',desc:'Ubah foto menjadi gaya anime.',
  tags:'anime image convert foto upload',
  body:`<div class="field"><input class="input" data-k="u" placeholder="URL foto..."></div>
        <div style="text-align:center;color:var(--text-secondary);font-size:12px;margin:4px 0">ATAU</div>
        <div class="field"><button class="btn btn-ghost" data-act="upload">${I.upload}<span>Upload Foto</span></button></div>
        <button class="btn" data-act="go">${I.anime}<span>Konversi ke Anime</span></button>`,
  init:(el)=>{
    el.querySelector('[data-act=upload]').onclick=()=>{
      handleImageUpload((url)=>{
        $('[data-k=u]',el).value=url;
        showNotif('success','Siap dikonversi','URL publik berhasil');
      }, el);
    };
  },
  run:async(c,btn)=>{
    let u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'URL atau foto wajib diisi.');
    
    // Resolve hidden ID
    const actualUrl=getImageUrl(u);
    if(actualUrl) u=actualUrl;
    
    // Check cache
    const cacheKey='anime_'+u;
    let out=getCachedResult(cacheKey);
    
    if(!out){
      setLoading(btn,true);
      const ep=API+'toanime?url='+encodeURIComponent(u);
      const d=await fetchAPI(ep);
      setLoading(btn,false);
      out=d.result||(d._isMedia&&ep)||ep;
      cacheResult(cacheKey, out);
    }
    
    showResult(c,`<div class="row"><img src="${esc(u)}" style="width:50%" loading="lazy"><img src="${esc(out)}" style="width:50%" loading="lazy"></div>
      <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'anime.jpg');
    showNotif('success','Selesai','Foto anime siap');
  }
});

// 32 To Babi
T({id:'tobabi',name:'To Babi',cat:['image','fun'],catLabel:'Image',icon:'babi',desc:'Foto wajah jadi gaya babi (efek lucu).',
  tags:'tobabi image fun face',
  body:`<div class="field"><input class="input" data-k="u" placeholder="URL foto wajah..."></div>
        <button class="btn" data-act="go">${I.babi}<span>Proses</span></button>`,
  run:async(c,btn)=>{
    const u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'URL wajib.');
    setLoading(btn,true);
    const ep=API+'tobabi?url='+encodeURIComponent(u);const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'tobabi.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'tobabi');
  }
});

// 33 To Bersama
T({id:'tobersama',name:'To Bersama',cat:['image','fun'],catLabel:'Image',icon:'two',desc:'Gabungkan dua foto / foto dengan artis.',
  tags:'tobersama bersama foto gabung artis',
  body:`<div class="radio-row">
          <label><input type="radio" name="tb-{id}" value="v1" checked><span>V1 (Artis)</span></label>
          <label><input type="radio" name="tb-{id}" value="v2"><span>V2 (2 Foto)</span></label>
        </div>
        <div data-v1><div class="field"><input class="input" data-k="u" placeholder="URL foto kamu..."></div>
          <div class="field"><input class="input" data-k="a" placeholder="Nama artis..."></div></div>
        <div data-v2 style="display:none"><div class="field"><input class="input" data-k="u1" placeholder="URL foto 1..."></div>
          <div class="field"><input class="input" data-k="u2" placeholder="URL foto 2..."></div></div>
        <button class="btn" data-act="go">${I.two}<span>Gabungkan</span></button>`,
  init:c=>{
    $$('input[type=radio]',c).forEach(r=>r.onchange=()=>{
      const v=$('input[type=radio]:checked',c).value;
      $('[data-v1]',c).style.display=v==='v1'?'':'none';
      $('[data-v2]',c).style.display=v==='v2'?'':'none';
    });
  },
  run:async(c,btn)=>{
    const v=$('input[type=radio]:checked',c).value;
    let ep;
    if(v==='v1'){
      const u=$('[data-k=u]',c).value.trim();const a=$('[data-k=a]',c).value.trim();
      if(!u||!a) return showErr(c,'URL & nama artis wajib.');
      ep=API+'tobersama?url='+encodeURIComponent(u)+'&nama-artis='+encodeURIComponent(a);
    }else{
      const u1=$('[data-k=u1]',c).value.trim();const u2=$('[data-k=u2]',c).value.trim();
      if(!u1||!u2) return showErr(c,'Dua URL wajib.');
      ep=API+'tobersamav2?url1='+encodeURIComponent(u1)+'&url2='+encodeURIComponent(u2);
    }
    setLoading(btn,true);
    const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'bersama.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'bersama');
  }
});

// 34 To Blonde
T({id:'toblonde',name:'To Blonde',cat:['image'],catLabel:'Image',icon:'blonde',desc:'Ubah warna rambut foto jadi blonde.',
  tags:'blonde rambut hair foto',
  body:`<div class="field"><input class="input" data-k="u" placeholder="URL foto..."></div>
        <button class="btn" data-act="go">${I.blonde}<span>Proses</span></button>`,
  run:async(c,btn)=>{
    const u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'URL wajib.');
    setLoading(btn,true);
    const ep=API+'toblonde?url='+encodeURIComponent(u);const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'blonde.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'blonde');
  }
});

// 35 To Botak
T({id:'tobotak',name:'To Botak',cat:['image','fun'],catLabel:'Image',icon:'bald',desc:'Bikin foto kepala terlihat botak.',
  tags:'botak bald foto',
  body:`<div class="field"><input class="input" data-k="u" placeholder="URL foto..."></div>
        <button class="btn" data-act="go">${I.bald}<span>Proses</span></button>`,
  run:async(c,btn)=>{
    const u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'URL wajib.');
    setLoading(btn,true);
    const ep=API+'tobotak?url='+encodeURIComponent(u);const d=await fetchAPI(ep);
    setLoading(btn,false);
    const out=d.result||(d._isMedia&&ep)||ep;
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'botak.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'botak');
  }
});

// 36 To Brewok
T({id:'tobrewok',name:'To Brewok',cat:['image','fun'],catLabel:'Image',icon:'beard',desc:'Tambah kumis & jenggot pada foto.',
  tags:'brewok beard jenggot foto upload',
  body:`<div class="field"><input class="input" data-k="u" placeholder="URL foto..."></div>
        <div style="text-align:center;color:var(--text-secondary);font-size:12px;margin:4px 0">ATAU</div>
        <div class="field"><button class="btn btn-ghost" data-act="upload">${I.upload}<span>Upload Foto</span></button></div>
        <button class="btn" data-act="go">${I.beard}<span>Proses</span></button>`,
  init:(el)=>{
    el.querySelector('[data-act=upload]').onclick=()=>{
      handleImageUpload((url)=>{
        $('[data-k=u]',el).value=url;
        showNotif('success','Siap diproses','URL publik berhasil');
      }, el);
    };
  },
  run:async(c,btn)=>{
    let u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'URL atau foto wajib diisi.');
    
    // Resolve hidden ID
    const actualUrl=getImageUrl(u);
    if(actualUrl) u=actualUrl;
    
    // Check cache
    const cacheKey='brewok_'+u;
    let out=getCachedResult(cacheKey);
    
    if(!out){
      setLoading(btn,true);
      const ep=API+'tobrewok?url='+encodeURIComponent(u);const d=await fetchAPI(ep);
      setLoading(btn,false);
      out=d.result||(d._isMedia&&ep)||ep;
      cacheResult(cacheKey, out);
    }
    
    showResult(c,`<img src="${esc(out)}" loading="lazy">
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh</span></button>
        <button class="btn btn-sticker" data-sticker>${I.sticker}<span>Add to Sticker</span></button>
      </div>`);
    $('[data-dl]',c).onclick=()=>downloadFile(out,'brewok.jpg');
    $('[data-sticker]',c).onclick=()=>convertToSticker(out,'brewok');
  }
});

// 37 Track IP
T({id:'ip',name:'Track IP',cat:['utility'],catLabel:'Utilitas',icon:'globe',desc:'Cek lokasi & info dari alamat IP.',
  tags:'ip track lokasi geolocation',
  body:`<div class="field"><input class="input" data-k="ip" placeholder="Alamat IP (contoh: 8.8.8.8)"></div>
        <button class="btn" data-act="go">${I.globe}<span>Lacak IP</span></button>`,
  run:async(c,btn)=>{
    const ip=$('[data-k=ip]',c).value.trim();if(!ip) return showErr(c,'IP wajib.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'track-ip?ip='+encodeURIComponent(ip));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result||{};
    const items=[
      ['Negara',r.country||r.negara],
      ['Kota',r.city||r.kota],
      ['ISP/Provider',r.isp||r.org||r.provider],
      ['Region',r.region||r.regionName],
      ['Koordinat',(r.lat&&r.lon)?(r.lat+', '+r.lon):''],
      ['Timezone',r.timezone||r.tz],
      ['Zip',r.zip]
    ].filter(x=>x[1]);
    showResult(c,`<b>${esc(ip)}</b><div class="stats-grid">${items.map(([k,v])=>`<div class="stat"><b>${esc(v)}</b>${esc(k)}</div>`).join('')}</div>`);
    showNotif('success','IP dilacak',r.country||ip);
  }
});

// 38 TTS
T({id:'tts2',name:'Text to Speech',cat:['utility','fun'],catLabel:'Utilitas',icon:'speaker',desc:'Ubah teks menjadi suara audio.',
  tags:'tts text to speech audio suara',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Ketik teks yang ingin diucapkan..."></textarea></div>
        <button class="btn" data-act="go">${I.speaker}<span>Buat Suara</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib.');
    setLoading(btn,true);
    // Coba beberapa endpoint TTS
    let audioUrl=null;
    const endpoints=[API+'tts-legkap?text='+encodeURIComponent(t), API+'tts?text='+encodeURIComponent(t), API+'text-to-speech?text='+encodeURIComponent(t)];
    for(const ep of endpoints){
      try{
        const resp=await fetch(ep);
        const ct=resp.headers.get('content-type')||'';
        if(ct.startsWith('audio/')||ct.includes('octet-stream')){
          // Respons langsung audio binary
          const blob=await resp.blob();
          audioUrl=URL.createObjectURL(blob);
          break;
        }
        const data=await resp.json().catch(()=>null);
        if(data?.result&&typeof data.result==='string'){
          // Respons JSON dengan URL audio
          const r2=await fetch(data.result);
          if(r2.ok){const b=await r2.blob();audioUrl=URL.createObjectURL(b);break;}
        }
      }catch(e){continue;}
    }
    setLoading(btn,false);
    if(audioUrl){
      showResult(c,`<audio src="${esc(audioUrl)}" controls style="width:100%"></audio>
        <button class="btn btn-download" data-dl>${I.download}<span>Unduh Audio MP3</span></button>`);
      $('[data-dl]',c).onclick=()=>{
        const a=document.createElement('a');a.href=audioUrl;a.download='tts.mp3';
        document.body.appendChild(a);a.click();document.body.removeChild(a);
        showNotif('success','Unduhan dimulai','tts.mp3');
      };
      showNotif('success','Audio siap','Putar atau unduh');
      return;
    }
    // Fallback: Web Speech API browser native
    if('speechSynthesis' in window){
      window.speechSynthesis.cancel();
      const utt=new SpeechSynthesisUtterance(t);
      const loadVoices=()=>{
        const voices=window.speechSynthesis.getVoices();
        const idVoice=voices.find(v=>v.lang.startsWith('id'))||voices.find(v=>v.lang.startsWith('en'))||voices[0];
        if(idVoice) utt.voice=idVoice;
        utt.lang=idVoice?.lang||'id-ID';
        utt.rate=0.95;utt.pitch=1;utt.volume=1;
        utt.onerror=(e)=>showErr(c,'Gagal memutar: '+e.error);
        window.speechSynthesis.speak(utt);
        showResult(c,`<div style="color:var(--text-secondary);font-size:13px;margin-bottom:8px">🔊 Memutar via browser TTS (${idVoice?.name||'default'})</div>
          <div style="display:flex;gap:8px">
            <button class="btn" id="tts-stop" style="background:var(--bg-tertiary);border:1px solid var(--border);color:var(--text-primary)">⏹ Stop</button>
            <button class="btn" id="tts-replay">${I.refresh}<span>Ulangi</span></button>
          </div>`);
        c.querySelector('#tts-stop').onclick=()=>{window.speechSynthesis.cancel();showNotif('info','Stop','TTS dihentikan');};
        c.querySelector('#tts-replay').onclick=()=>{window.speechSynthesis.cancel();const u2=new SpeechSynthesisUtterance(t);if(idVoice)u2.voice=idVoice;u2.lang=utt.lang;u2.rate=utt.rate;window.speechSynthesis.speak(u2);};
      };
      if(window.speechSynthesis.getVoices().length) loadVoices();
      else window.speechSynthesis.onvoiceschanged=loadVoices;
      showNotif('success','Browser TTS','Menggunakan suara browser');
    } else {
      showErr(c,'Gagal membuat audio. API TTS tidak tersedia dan browser tidak mendukung Web Speech.');
    }
  }
});

// 39 Wikipedia
T({id:'wiki',name:'Wikipedia Search',cat:['utility'],catLabel:'Utilitas',icon:'book',desc:'Cari artikel Wikipedia singkat.',
  tags:'wikipedia search ensiklopedia',
  body:`<div class="field"><input class="input" data-k="q" placeholder="Cari di Wikipedia... (Albert Einstein)"></div>
        <button class="btn" data-act="go">${I.book}<span>Cari</span></button>`,
  run:async(c,btn)=>{
    const q=$('[data-k=q]',c).value.trim();if(!q) return showErr(c,'Kata kunci wajib.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'Wikipedia-search?q='+encodeURIComponent(q));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||'Tidak ditemukan.');
    const r=d.result||{};
    const arr=Array.isArray(r)?r:[r];
    showResult(c,arr.map(x=>{
      const title=x.title||x.judul||q;
      const excerpt=x.excerpt||x.description||x.summary||x.snippet||x.text||'';
      const link=x.url||x.link||('https://id.wikipedia.org/wiki/'+encodeURIComponent(title));
      return `<div style="display:flex;flex-direction:column;gap:6px;border-top:1px solid var(--border);padding-top:8px">
        <b>${esc(title)}</b>
        <div style="color:var(--text-secondary)">${esc(excerpt)}</div>
        <a href="${esc(link)}" target="_blank" rel="noopener" class="btn btn-ghost" style="text-decoration:none">Buka Wikipedia</a>
      </div>`;
    }).join(''));
  }
});

/* ====================== TOOLS TAMBAHAN ====================== */

// newly_ai (sama seperti gemini tapi endpoint newly-ai)
T({id:'newly-ai',name:'🧠 Newly AI',cat:['ai'],catLabel:'AI',icon:'star',desc:'Tanya AI Newly realtime.',
  tags:'newly ai chat tanya',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Tanya Newly AI apa saja..."></textarea></div>
        <button class="btn" data-act="go">${I.star}<span>Tanya</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Pertanyaan wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'newly-ai?text='+encodeURIComponent(t));
    setLoading(btn,false);
    const r=d.result||d.answer||d.error;
    if(!d.status) return showErr(c,r||'Gagal.');
    showResult(c,`<div class="result-head"><b>Jawaban Newly AI</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="white-space:pre-wrap">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});

// brat HD
T({id:'brathd',name:'🎨 Brat HD',cat:['generator'],catLabel:'Generator',icon:'image',desc:'Buat gambar brat kualitas HD.',
  tags:'brat hd generator gambar teks',
  body:`<div class="field"><input class="input" data-k="t" placeholder="Teks untuk Brat HD..."></div>
        <button class="btn" data-act="go">${I.image}<span>Buat Brat HD</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'brathd?text='+encodeURIComponent(t));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||d.result||'Gagal.');
    const url=d.result||d.url;
    showResult(c,`<img src="${esc(url)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(url)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
  }
});

// brat video
T({id:'bratvid',name:'🎬 Brat Video',cat:['generator'],catLabel:'Generator',icon:'video',desc:'Buat video gaya brat animasi.',
  tags:'brat video animasi generator',
  body:`<div class="field"><input class="input" data-k="t" placeholder="Teks untuk Brat Video..."></div>
        <button class="btn" data-act="go">${I.video||I.star}<span>Buat Video</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'bratvid?text='+encodeURIComponent(t));
    setLoading(btn,false);
    if(!d.status) return showErr(c,d.error||d.result||'Gagal.');
    const url=d.result||d.url;
    showResult(c,`<video src="${esc(url)}" controls style="max-width:100%;border-radius:8px"></video><br><a href="${esc(url)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
  }
});

// HD v2 v3 v4
T({id:'hdv2',name:'✨ AI HD v2',cat:['image'],catLabel:'Image',icon:'image',desc:'Perjelas foto HD versi 2.',
  tags:'hd perjelas foto ai enhance v2',
  body:`<div class="field"><input class="input" data-k="url" placeholder="URL gambar atau upload foto..."></div>
        <input type="file" accept="image/*" style="margin-bottom:8px" data-upload>
        <button class="btn" data-act="go">${I.image}<span>Perjelas</span></button>`,
  init:c=>{initUpload(c);},
  run:async(c,btn)=>{
    let url=$('[data-k=url]',c).value.trim();url=await resolveUpload(c,url);if(!url) return showErr(c,'URL wajib diisi.');
    setLoading(btn,true);const d=await fetchAPI(API+'hdv2?url='+encodeURIComponent(url));setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');const r=d.result||d.url;
    showResult(c,`<img src="${esc(r)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(r)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
  }
});
T({id:'hdv3',name:'✨ AI HD v3',cat:['image'],catLabel:'Image',icon:'image',desc:'Perjelas foto HD versi 3.',
  tags:'hd perjelas foto ai enhance v3',
  body:`<div class="field"><input class="input" data-k="url" placeholder="URL gambar atau upload foto..."></div>
        <input type="file" accept="image/*" style="margin-bottom:8px" data-upload>
        <button class="btn" data-act="go">${I.image}<span>Perjelas</span></button>`,
  init:c=>{initUpload(c);},
  run:async(c,btn)=>{
    let url=$('[data-k=url]',c).value.trim();url=await resolveUpload(c,url);if(!url) return showErr(c,'URL wajib diisi.');
    setLoading(btn,true);const d=await fetchAPI(API+'hdv3?url='+encodeURIComponent(url));setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');const r=d.result||d.url;
    showResult(c,`<img src="${esc(r)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(r)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
  }
});
T({id:'hdv4',name:'✨ AI HD v4',cat:['image'],catLabel:'Image',icon:'image',desc:'Perjelas foto HD versi 4.',
  tags:'hd perjelas foto ai enhance v4',
  body:`<div class="field"><input class="input" data-k="url" placeholder="URL gambar atau upload foto..."></div>
        <input type="file" accept="image/*" style="margin-bottom:8px" data-upload>
        <button class="btn" data-act="go">${I.image}<span>Perjelas</span></button>`,
  init:c=>{initUpload(c);},
  run:async(c,btn)=>{
    let url=$('[data-k=url]',c).value.trim();url=await resolveUpload(c,url);if(!url) return showErr(c,'URL wajib diisi.');
    setLoading(btn,true);const d=await fetchAPI(API+'hdv4?url='+encodeURIComponent(url));setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');const r=d.result||d.url;
    showResult(c,`<img src="${esc(r)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(r)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
  }
});

// IQC v2 (standalone)
T({id:'iqcv2',name:'👤 IQC v2',cat:['ai','generator'],catLabel:'AI',icon:'avatar',desc:'Buat karakter IQC versi 2.',
  tags:'iqc v2 avatar karakter ai',
  body:`<div class="field"><input class="input" data-k="prompt" placeholder="Deskripsi karakter..."></div>
        <div class="row"><input class="input" data-k="jam" placeholder="Jam (14:30 / skip)"><input class="input" data-k="batre" placeholder="Batre % (85 / skip)"></div>
        <button class="btn" data-act="go">${I.avatar||I.star}<span>Buat IQC v2</span></button>`,
  run:async(c,btn)=>{
    const p=$('[data-k=prompt]',c).value.trim();if(!p) return showErr(c,'Prompt wajib diisi.');
    const jam=$('[data-k=jam]',c).value.trim()||'skip';
    const batre=$('[data-k=batre]',c).value.trim()||'skip';
    setLoading(btn,true);
    const d=await fetchAPI(API+'iqcv2?prompt='+encodeURIComponent(p)+'&jam='+encodeURIComponent(jam)+'&batre='+encodeURIComponent(batre));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const url=d.result||d.url||d.image||d.data;
    showResult(c,`<img src="${esc(url)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(url)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
  }
});

// TTS Lengkap
T({id:'tts_lengkap',name:'🔊 TTS Lengkap',cat:['utility','fun'],catLabel:'Utilitas',icon:'speaker',desc:'Text to Speech versi lengkap dengan pilihan suara.',
  tags:'tts text speech suara audio lengkap',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks yang mau diubah jadi suara..."></textarea></div>
        <button class="btn" data-act="go">${I.speaker||I.star}<span>Buat Suara</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'tts-lengkap?text='+encodeURIComponent(t));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const url=d.result||d.url||d.audio;
    showResult(c,`<audio controls src="${esc(url)}" style="width:100%"></audio><br><a href="${esc(url)}" download class="btn btn-ghost" target="_blank">⬇️ Download Audio</a>`);
  }
});

// TikTok Stalk
T({id:'ttstalk',name:'📊 TikTok Stalk',cat:['utility'],catLabel:'Utilitas',icon:'globe',desc:'Cek profil & statistik akun TikTok.',
  tags:'tiktok stalk profil statistik akun',
  body:`<div class="field"><input class="input" data-k="u" placeholder="Username TikTok (tanpa @)..."></div>
        <button class="btn" data-act="go">${I.globe||I.star}<span>Cek Profil</span></button>`,
  run:async(c,btn)=>{
    const u=$('[data-k=u]',c).value.trim().replace('@','');if(!u) return showErr(c,'Username wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'ttstalk?username='+encodeURIComponent(u));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result||d;
    showResult(c,`<div style="display:flex;flex-direction:column;gap:6px">
      ${r.avatar?`<img src="${esc(r.avatar)}" style="width:80px;height:80px;border-radius:50%;object-fit:cover">`:''}
      <b>${esc(r.nickname||r.username||u)}</b>
      <span style="color:var(--text-secondary)">@${esc(r.username||u)}</span>
      <div style="display:flex;gap:12px;flex-wrap:wrap">
        <span>❤️ ${esc(String(r.likes||r.heart||0))}</span>
        <span>👥 ${esc(String(r.followers||0))}</span>
        <span>▶️ ${esc(String(r.following||0))}</span>
      </div>
      ${r.bio?`<p>${esc(r.bio)}</p>`:''}
    </div>`);
  }
});

// Short URL
T({id:'shorturl',name:'🔗 Short URL',cat:['utility'],catLabel:'Utilitas',icon:'link',desc:'Persingkat link panjang jadi pendek.',
  tags:'short url link persingkat pendek',
  body:`<div class="field"><input class="input" data-k="url" placeholder="https://link-panjang.com/..."></div>
        <button class="btn" data-act="go">${I.link||I.star}<span>Persingkat</span></button>`,
  run:async(c,btn)=>{
    const url=$('[data-k=url]',c).value.trim();if(!url) return showErr(c,'URL wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'shorturl?url='+encodeURIComponent(url));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result||d.url||d.short;
    showResult(c,`<div class="result-head"><b>Link Pendek</b><button class="icon-btn" data-cp>${I.copy}</button></div>
      <a href="${esc(r)}" target="_blank" style="word-break:break-all">${esc(r)}</a>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});

// Screenshot Web
T({id:'screenshot',name:'📸 Screenshot Web',cat:['utility'],catLabel:'Utilitas',icon:'image',desc:'Screenshot halaman website.',
  tags:'screenshot web foto website halaman',
  body:`<div class="field"><input class="input" data-k="url" placeholder="https://google.com"></div>
        <button class="btn" data-act="go">${I.image}<span>Screenshot</span></button>`,
  run:async(c,btn)=>{
    let url=$('[data-k=url]',c).value.trim();
    if(!url) return showErr(c,'URL wajib diisi.');
    if(!/^https?:\/\//.test(url)) url='https://'+url;
    setLoading(btn,true);
    const d=await fetchAPI(API+'screenshot?url='+encodeURIComponent(url));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result||d.url||d.image;
    showResult(c,`<img src="${esc(r)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(r)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
  }
});

// Encode / Decode URL
T({id:'encode',name:'🔒 URL Encode',cat:['utility'],catLabel:'Utilitas',icon:'lock',desc:'Encode teks ke format URL.',
  tags:'encode url format teks',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks yang mau di-encode..."></textarea></div>
        <button class="btn" data-act="go">${I.lock||I.star}<span>Encode</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    const r=encodeURIComponent(t);
    showResult(c,`<div class="result-head"><b>Hasil Encode</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="word-break:break-all">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});
T({id:'decode',name:'🔓 URL Decode',cat:['utility'],catLabel:'Utilitas',icon:'unlock',desc:'Decode URL encode ke teks asli.',
  tags:'decode url format teks',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks URL-encoded..."></textarea></div>
        <button class="btn" data-act="go">${I.unlock||I.star}<span>Decode</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    try{const r=decodeURIComponent(t);
    showResult(c,`<div class="result-head"><b>Hasil Decode</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="word-break:break-all">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);}catch(e){showErr(c,'Teks tidak valid untuk di-decode.');}
  }
});

// Base64 Encode / Decode
T({id:'b64enc',name:'📦 Base64 Encode',cat:['utility'],catLabel:'Utilitas',icon:'lock',desc:'Encode teks ke Base64.',
  tags:'base64 encode teks',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks yang mau di-encode..."></textarea></div>
        <button class="btn" data-act="go">${I.lock||I.star}<span>Encode</span></button>`,
  run:(c)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    const r=btoa(unescape(encodeURIComponent(t)));
    showResult(c,`<div class="result-head"><b>Base64</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="word-break:break-all">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});
T({id:'b64dec',name:'📤 Base64 Decode',cat:['utility'],catLabel:'Utilitas',icon:'unlock',desc:'Decode Base64 ke teks asli.',
  tags:'base64 decode teks',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks Base64..."></textarea></div>
        <button class="btn" data-act="go">${I.unlock||I.star}<span>Decode</span></button>`,
  run:(c)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    try{const r=decodeURIComponent(escape(atob(t)));
    showResult(c,`<div class="result-head"><b>Hasil Decode</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="word-break:break-all">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);}catch(e){showErr(c,'Teks bukan Base64 valid.');}
  }
});

// Hash MD5 / SHA256
T({id:'md5',name:'#️⃣ Hash MD5',cat:['utility'],catLabel:'Utilitas',icon:'hash',desc:'Hash teks dengan MD5.',
  tags:'hash md5 enkripsi teks',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks yang mau di-hash..."></textarea></div>
        <button class="btn" data-act="go">${I.hash||I.star}<span>Hash MD5</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'md5?text='+encodeURIComponent(t));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result||d.hash;
    showResult(c,`<div class="result-head"><b>MD5 Hash</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="word-break:break-all;font-family:monospace">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});
T({id:'sha256',name:'🔏 Hash SHA256',cat:['utility'],catLabel:'Utilitas',icon:'hash',desc:'Hash teks dengan SHA256.',
  tags:'hash sha256 enkripsi teks',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks yang mau di-hash..."></textarea></div>
        <button class="btn" data-act="go">${I.hash||I.star}<span>Hash SHA256</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'sha256?text='+encodeURIComponent(t));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result||d.hash;
    showResult(c,`<div class="result-head"><b>SHA256 Hash</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="word-break:break-all;font-family:monospace">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});

// Encrypt / Decrypt
T({id:'encrypt',name:'🔐 Encrypt Text',cat:['utility'],catLabel:'Utilitas',icon:'lock',desc:'Enkripsi teks (AES-256).',
  tags:'encrypt enkripsi aes teks',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks yang mau dienkripsi..."></textarea></div>
        <button class="btn" data-act="go">${I.lock||I.star}<span>Enkripsi</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'encrypt?text='+encodeURIComponent(t));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result||d.encrypted;
    showResult(c,`<div class="result-head"><b>Hasil Enkripsi</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="word-break:break-all;font-family:monospace">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});
T({id:'decrypt',name:'🔓 Decrypt Text',cat:['utility'],catLabel:'Utilitas',icon:'unlock',desc:'Dekripsi teks terenkripsi (AES-256).',
  tags:'decrypt dekripsi aes teks',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="Teks terenkripsi..."></textarea></div>
        <button class="btn" data-act="go">${I.unlock||I.star}<span>Dekripsi</span></button>`,
  run:async(c,btn)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Teks wajib diisi.');
    setLoading(btn,true);
    const d=await fetchAPI(API+'decrypt?text='+encodeURIComponent(t));
    setLoading(btn,false);
    if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
    const r=d.result||d.decrypted;
    showResult(c,`<div class="result-head"><b>Hasil Dekripsi</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="word-break:break-all">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});

// JWT Decoder
T({id:'jwtdec',name:'🪙 JWT Decoder',cat:['utility'],catLabel:'Utilitas',icon:'key',desc:'Decode dan inspect JWT token.',
  tags:'jwt token decode inspect',
  body:`<div class="field"><textarea class="textarea" data-k="t" placeholder="JWT token..."></textarea></div>
        <button class="btn" data-act="go">${I.key||I.star}<span>Decode JWT</span></button>`,
  run:(c)=>{
    const t=$('[data-k=t]',c).value.trim();if(!t) return showErr(c,'Token wajib diisi.');
    try{
      const parts=t.split('.');
      if(parts.length!==3) throw new Error('Bukan JWT valid (harus 3 bagian)');
      const header=JSON.parse(atob(parts[0].replace(/-/g,'+').replace(/_/g,'/')));
      const payload=JSON.parse(atob(parts[1].replace(/-/g,'+').replace(/_/g,'/')));
      const expStr=payload.exp?new Date(payload.exp*1000).toLocaleString('id-ID'):'–';
      showResult(c,`<div style="display:flex;flex-direction:column;gap:8px">
        <div><b>Header</b><pre style="background:var(--surface);padding:8px;border-radius:6px;overflow:auto;font-size:12px">${esc(JSON.stringify(header,null,2))}</pre></div>
        <div><b>Payload</b><pre style="background:var(--surface);padding:8px;border-radius:6px;overflow:auto;font-size:12px">${esc(JSON.stringify(payload,null,2))}</pre></div>
        ${payload.exp?`<div style="color:var(--text-secondary)">Expires: ${expStr}</div>`:''}
      </div>`);
    }catch(e){showErr(c,'Gagal decode JWT: '+e.message);}
  }
});

// Password Generator
T({id:'passgen',name:'🔐 Password Generator',cat:['utility'],catLabel:'Utilitas',icon:'lock',desc:'Generate password acak yang kuat.',
  tags:'password generator acak kuat',
  body:`<div class="field"><input class="input" data-k="len" type="number" min="8" max="64" placeholder="Panjang password (default 16)..."></div>
        <button class="btn" data-act="go">${I.lock||I.star}<span>Generate</span></button>`,
  run:(c)=>{
    const len=Math.min(64,Math.max(8,parseInt($('[data-k=len]',c).value)||16));
    const chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+';
    let pass='';for(let i=0;i<len;i++) pass+=chars[Math.floor(Math.random()*chars.length)];
    showResult(c,`<div class="result-head"><b>Password</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="font-family:monospace;word-break:break-all;font-size:18px">${esc(pass)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(pass);
  }
});

// Password Checker
T({id:'passcheck',name:'🛡️ Password Checker',cat:['utility'],catLabel:'Utilitas',icon:'shield',desc:'Cek kekuatan password kamu.',
  tags:'password cek kekuatan keamanan',
  body:`<div class="field"><input class="input" data-k="p" type="password" placeholder="Masukkan password..."></div>
        <button class="btn" data-act="go">${I.shield||I.star}<span>Cek</span></button>`,
  run:(c)=>{
    const p=$('[data-k=p]',c).value;if(!p) return showErr(c,'Password wajib diisi.');
    let score=0,tips=[];
    if(p.length>=8)score++;else tips.push('Minimal 8 karakter');
    if(p.length>=12)score++;
    if(/[A-Z]/.test(p))score++;else tips.push('Tambah huruf kapital');
    if(/[a-z]/.test(p))score++;else tips.push('Tambah huruf kecil');
    if(/[0-9]/.test(p))score++;else tips.push('Tambah angka');
    if(/[^A-Za-z0-9]/.test(p))score++;else tips.push('Tambah karakter spesial (!@#$...)');
    const levels=['Sangat Lemah','Lemah','Cukup','Sedang','Kuat','Sangat Kuat'];
    const colors=['#ef4444','#f97316','#eab308','#3b82f6','#22c55e','#16a34a'];
    const lvl=Math.min(score,5);
    showResult(c,`<div style="display:flex;flex-direction:column;gap:8px">
      <div style="font-size:18px;font-weight:700;color:${colors[lvl]}">${levels[lvl]}</div>
      <div style="background:var(--border);border-radius:4px;height:8px"><div style="background:${colors[lvl]};width:${(lvl/5)*100}%;height:100%;border-radius:4px;transition:.3s"></div></div>
      <div>Score: ${score}/6</div>
      ${tips.length?`<ul style="margin:4px 0;padding-left:16px;color:var(--text-secondary)">${tips.map(t=>`<li>${t}</li>`).join('')}</ul>`:'<div style="color:#22c55e">✅ Password sudah sangat kuat!</div>'}
    </div>`);
  }
});

// UUID Generator & Decoder
T({id:'uuidgen',name:'🆔 UUID Generator',cat:['utility'],catLabel:'Utilitas',icon:'hash',desc:'Generate UUID v4 secara acak.',
  tags:'uuid generator v4 acak id',
  body:`<button class="btn" data-act="go">${I.hash||I.star}<span>Generate UUID</span></button>`,
  run:(c)=>{
    const r='xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>{const r=Math.random()*16|0;return(c==='x'?r:r&0x3|0x8).toString(16);});
    showResult(c,`<div class="result-head"><b>UUID v4</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="font-family:monospace;word-break:break-all">${esc(r)}</div>`);
    $('[data-cp]',c).onclick=()=>copyText(r);
  }
});
T({id:'uuiddec',name:'🔍 UUID Decoder',cat:['utility'],catLabel:'Utilitas',icon:'hash',desc:'Decode & validasi UUID.',
  tags:'uuid decode validasi inspect',
  body:`<div class="field"><input class="input" data-k="u" placeholder="UUID yang mau di-decode..."></div>
        <button class="btn" data-act="go">${I.hash||I.star}<span>Decode UUID</span></button>`,
  run:(c)=>{
    const u=$('[data-k=u]',c).value.trim();if(!u) return showErr(c,'UUID wajib diisi.');
    const re=/^[0-9a-f]{8}-[0-9a-f]{4}-([0-9a-f])[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if(!re.test(u)) return showErr(c,'Format UUID tidak valid.');
    const ver=u[14];
    const variant=parseInt(u[19],16)>=8?'RFC 4122':'Other';
    showResult(c,`<div style="display:flex;flex-direction:column;gap:6px">
      <div><b>UUID:</b> <span style="font-family:monospace">${esc(u)}</span></div>
      <div><b>Versi:</b> ${ver}</div>
      <div><b>Variant:</b> ${variant}</div>
      <div><b>Valid:</b> ✅ Ya</div>
    </div>`);
  }
});

/* ====================== ANONYMOUS CHAT ====================== */
const ANON_UID_KEY = 'anonUserId';
let anonUserId = localStorage.getItem(ANON_UID_KEY) || null;
let anonProfile = null; // { uid, platform, gender, is_premium, gender_preference, ... }

let anonState = { searching: false, chatting: false, partnerId: null, partnerIsPremium: false, pollInterval: null, statusPollInterval: null };

function anonApiBase(){ return API.replace(/\/api\/$/, ''); }

// Pastikan UID ada — kalau belum pernah register, daftar baru ke Supabase via /api/anon/register
async function ensureAnonUID(){
  if (anonUserId) return anonUserId;
  await waitAPIReady();
  try{
    const r = await fetch(anonApiBase() + '/api/anon/register', { method:'POST' });
    const d = await r.json();
    if (d.status && d.uid){
      anonUserId = d.uid;
      localStorage.setItem(ANON_UID_KEY, anonUserId);
    }
  }catch(e){}
  return anonUserId;
}

// Ganti ke UID lain (login manual pakai UID yang sudah pernah didaftarkan)
async function anonLoginWithUID(uid){
  await waitAPIReady();
  const r = await fetch(anonApiBase() + '/api/anon/login', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ uid })
  });
  const d = await r.json();
  if (d.status && d.user){
    anonUserId = uid;
    anonProfile = d.user;
    localStorage.setItem(ANON_UID_KEY, anonUserId);
    return true;
  }
  return false;
}

T({id:'anonchat',name:'💬 Anonymous Chat',cat:['fun'],catLabel:'Fun',icon:'message-circle',desc:'Chat anonim dengan stranger random (web, Telegram, WhatsApp).',
  tags:'anonymous chat random stranger messaging anon',
  body:`<div style="display:flex;flex-direction:column;gap:12px">
    <div id="anon-stats" style="background:#1a1a1a;border:1px solid #333;border-radius:10px;padding:12px;font-size:13px;color:#888">
      <div>🔍 Searching: <span id="anon-stat-search">0</span></div>
      <div>💬 Chatting: <span id="anon-stat-chat">0</span></div>
      <div>👥 Total: <span id="anon-stat-total">0</span></div>
    </div>
    <a href="/anon.html" style="display:block;text-align:center;background:linear-gradient(135deg,var(--accent-1),var(--accent-2));color:#fff;font-weight:700;font-size:14px;padding:12px;border-radius:10px;text-decoration:none">Buka Anon//Line →</a>
  </div>`,
  run:(c)=>{
    updateAnonStats();
  }
});

async function updateAnonStats(){
  try{

    const r=await fetch(anonApiBase()+'/api/anon/status?userId='+encodeURIComponent(anonUserId||''));
    const d=await r.json();
    if(d.status){
      const elSearch = document.getElementById('anon-stat-search');
      const elChat = document.getElementById('anon-stat-chat');
      const elTotal = document.getElementById('anon-stat-total');
      if(elSearch) elSearch.textContent=d.searching;
      if(elChat) elChat.textContent=d.chatting;
      if(elTotal) elTotal.textContent=d.total;
    }
  }catch(e){}
}


T({id:'jadibot',name:'🤖 Jadi Bot',cat:['fun','utility'],catLabel:'Bot',icon:'bot',
  desc:'Masukkan nomor HP kamu, jadikan nomor itu bot WhatsApp otomatis lewat kode pairing.',
  tags:'jadi bot whatsapp wa pairing code nomor jadibot',
  body:`<div style="display:flex;flex-direction:column;gap:10px">
    <div class="field"><input class="input" data-k="jb-number" inputmode="numeric" placeholder="Nomor HP tanpa +, spasi, atau - (contoh: 6281234567890)"></div>
    <button class="btn" data-act="go">${I.bot}<span>Jadi Bot</span></button>
    <div id="jb-status" style="display:none;background:#1a1a1a;border:1px solid #333;border-radius:10px;padding:14px;text-align:center">
      <div id="jb-status-text" style="font-size:13px;color:#888;margin-bottom:8px"></div>
      <div id="jb-code" style="display:none;font-size:26px;font-weight:800;letter-spacing:2px;color:#fff;font-family:monospace"></div>
    </div>
  </div>`,
  run:(c,btn)=>{
    return jadiBotStart(c,btn);
  }
});

let _jbPollTimer=null;
function jadiBotStop(){
  if(_jbPollTimer){clearInterval(_jbPollTimer);_jbPollTimer=null}
}
async function jadiBotStart(c,btn){
  jadiBotStop();
  const raw=$('[data-k=jb-number]',c).value.trim();
  const number=raw.replace(/[^0-9]/g,'');
  if(!number||number.length<8) return showErr(c,'Masukkan nomor HP yang valid tanpa "+", spasi, atau "-".');

  clearResult(c);
  const statusBox=$('#jb-status',c);
  const statusText=$('#jb-status-text',c);
  const codeEl=$('#jb-code',c);
  statusBox.style.display='block';
  codeEl.style.display='none';
  statusText.textContent='⏳ Mengirim permintaan...';
  setLoading(btn,true);

  await waitAPIReady();
  const base=API.replace(/\/api\/$/,'');
  try{
    const r=await fetch(base+'/api/jadi-bot',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({number})
    });
    const d=await r.json();
    if(!d.status){
      setLoading(btn,false);
      statusText.textContent='';
      statusBox.style.display='none';
      return showErr(c,d.error||'Gagal memulai proses.');
    }
  }catch(e){
    setLoading(btn,false);
    statusBox.style.display='none';
    return showErr(c,'Gagal terhubung ke server: '+e.message);
  }

  statusText.textContent='⏳ Meminta kode pairing dari WhatsApp...';

  _jbPollTimer=setInterval(async()=>{
    try{
      const r=await fetch(base+'/api/jadi-bot/status');
      const d=await r.json();
      if(!d.status) return;
      const s=d.state;
      if(s.status==='processing'){
        statusText.textContent='⏳ Meminta kode pairing dari WhatsApp...';
      }else if(s.status==='code_ready'){
        jadiBotStop();
        setLoading(btn,false);
        statusText.textContent=`📟 Kode untuk ${s.number} — buka WhatsApp → Perangkat Tertaut → Tautkan dengan nomor telepon:`;
        codeEl.textContent=s.code;
        codeEl.style.display='block';
      }else if(s.status==='connected'){
        jadiBotStop();
        setLoading(btn,false);
        statusText.textContent=`✅ Nomor ${s.number} berhasil terhubung sebagai bot!`;
        codeEl.style.display='none';
      }else if(s.status==='error'){
        jadiBotStop();
        setLoading(btn,false);
        statusBox.style.display='none';
        showErr(c,s.error||'Gagal mendapatkan kode pairing.');
      }
    }catch(e){/* diamkan, polling lanjut nyoba lagi */}
  },1000);
}

/* ====================== RENDER ====================== */
function renderTools(){
  const grid=$('#tools-grid');
  grid.innerHTML='';
  tools.forEach((t,i)=>{
    const cats=t.cat.join(' ');
    const el=document.createElement('article');
    el.className='tool-card';
    el.dataset.name=t.name.toLowerCase();
    el.dataset.tags=(t.tags||'')+' '+t.name.toLowerCase()+' '+cats;
    el.dataset.cat=cats;
    el.style.animationDelay=Math.min(i*30,400)+'ms';
    const body=(t.body||'').replace(/\{id\}/g,t.id);
    el.innerHTML=`
      <div class="card-head">
        <div class="card-icon">${I[t.icon]||I.star}</div>
        <div class="card-title-wrap">
          <div class="card-title">${esc(t.name)}</div>
          <span class="card-cat">${esc(t.catLabel)}</span>
        </div>
      </div>
      <div class="card-desc">${esc(t.desc)}</div>
      <div class="card-body" style="display:flex;flex-direction:column;gap:8px">${body}</div>
      <div class="result hidden"></div>`;
    grid.appendChild(el);
    if(t.init) try{t.init(el)}catch(e){console.warn(e)}
    const btn=el.querySelector('[data-act=go]');
    if(btn) btn.onclick=async()=>{
      try{
        clearResult(el);
        const exemptFromLimit=t.id==='cek-limit'||t.id==='premium'||t.id==='jadibot';
        if(exemptFromLimit){
          setLoading(btn,true);
          const p=t.run(el,btn);
          if(p&&p.catch) p.catch(e=>{setLoading(btn,false);showErr(el,e.message);});
          return;
        }
        // Cek limit basic/premium terpadu sebelum eksekusi tool
        await waitAPIReady();
        setLoading(btn,true);
        let limitInfo;
        try{
          const r=await fetch(API+'limit/status?identifier='+encodeURIComponent(DEVICE_ID));
          limitInfo=await r.json();
        }catch(e){ limitInfo=null; } // kalau cek limit gagal, tetap izinkan (fail-open) biar tool tidak macet total
        if(limitInfo&&limitInfo.status&&limitInfo.allowed===false){
          setLoading(btn,false);
          return showErr(el,`Limit harian kamu habis (${limitInfo.used}/${limitInfo.limit}). Upgrade ke Premium untuk limit lebih besar (${limitInfo.limit} → lebih tinggi), atau tunggu reset besok.`);
        }
        setLoading(btn,false);
        const p=t.run(el,btn);
        if(p&&p.then) p.then(()=>{ fetch(API+'limit/increment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({identifier:DEVICE_ID})}).catch(()=>{}); });
        if(p&&p.catch) p.catch(e=>{setLoading(btn,false);showErr(el,e.message);});
      }catch(e){setLoading(btn,false);showErr(el,e.message)}
    };
  });
}

/* Search filter */
$('#search-input').addEventListener('input',e=>{
  const q=e.target.value.toLowerCase().trim();
  let any=false;
  $$('.tool-card').forEach(c=>{
    const hit=!q||c.dataset.name.includes(q)||c.dataset.tags.includes(q);
    c.style.display=hit?'':'none';
    if(hit) any=true;
  });
  let em=$('.empty-msg');
  if(!any){
    if(!em){em=document.createElement('div');em.className='empty-msg';em.textContent='Tidak ada tool yang cocok';$('#tools-grid').appendChild(em)}
  }else if(em) em.remove();
});

/* Filter tabs */
$$('.filter-tab').forEach(t=>t.onclick=()=>{
  $$('.filter-tab').forEach(x=>x.classList.remove('active'));
  t.classList.add('active');
  const cat=t.dataset.cat;
  $$('.tool-card').forEach(c=>{
    c.style.display=(cat==='all'||c.dataset.cat.split(' ').includes(cat))?'':'none';
  });
});


/* ====================== NONTON DRACIN ====================== */
/* NOTE: Rate-limit 30 req/menit + ban 10 menit di-enforce di sisi klien.
   Untuk anti-bypass total (clone tab/incognito beda fingerprint sama IP),
   logika yang sama HARUS dipasang juga di server.js anda
   (mirror DRACIN_RATE & DRACIN_BAN ke middleware berbasis IP). */
const DRACIN_API_BASE = 'https://prod-api.dracinapi.com';
const DRACIN_AUTH = 'Bearer dbk_live_cc43400a7787f2027aa5685a36d38743f34821014bf6f904';
const DRACIN_RATE_MAX = 30;          // 30 request
const DRACIN_RATE_WIN_MS = 60 * 1000; // per 60 detik
const DRACIN_BAN_MS = 10 * 60 * 1000; // ban 10 menit

const DRACIN_PROVIDERS = [
  'starshort','dramabite','freereels','fundrama','microdrama','vigloo','bilitv','dramabox',
  'dramawave','netshort','idrama','shortmax','goodshort','melolo','velolo','reelshort',
  'flickreels','stardusttv','serialplus','dotdrama','rapidtv','shortswave','dramanova','cubetv',
  'reelbuzz','flareflow','moboreels','happyshort','reelife','pinedrama','flextv','reelala',
  'anyreel','raptdrama','bonustv','minitv','golddrama','iqiyi','bstation','joyreels','kalostv','vibeshort'
];
const DRACIN_PROVIDER_LABEL = {
  serialplus:'Serial+', bilitv:'BiliTV', flextv:'FlexTV', rapidtv:'RapidTV', cubetv:'CubeTV',
  kalostv:'KalosTV', bonustv:'BonusTV', minitv:'MiniTV', iqiyi:'IQIYI', golddrama:'Gold Drama'
};
const DRACIN_GENRES = ['romance','suspense','comedy','drama','fantasy','action','modern','historical','family','ceo','revenge','billionaire'];
// urutan fallback endpoint "populer"
const DRACIN_HOME_TRY = ['home','popular','trending','recommend','latest','newrelease','ranking'];

function dracinLabel(p){ return DRACIN_PROVIDER_LABEL[p] || (p[0].toUpperCase()+p.slice(1)); }
function dracinKey(k){ return 'dracin_'+k; }

/* ---- Rate limit & ban (client-side, sebisa mungkin lintas-tab) ---- */
function dracinGetTimestamps(){
  try{ return JSON.parse(localStorage.getItem(dracinKey('ts'))||'[]'); }catch(_){ return []; }
}
function dracinSetTimestamps(arr){ localStorage.setItem(dracinKey('ts'), JSON.stringify(arr)); }
function dracinGetBan(){
  const v = parseInt(localStorage.getItem(dracinKey('ban'))||'0',10);
  return v > Date.now() ? v : 0;
}
function dracinSetBan(until){ localStorage.setItem(dracinKey('ban'), String(until)); }
function dracinCheckRate(){
  const banUntil = dracinGetBan();
  if(banUntil) return { ok:false, banUntil };
  const now = Date.now();
  let ts = dracinGetTimestamps().filter(t => now - t < DRACIN_RATE_WIN_MS);
  if(ts.length >= DRACIN_RATE_MAX){
    const until = now + DRACIN_BAN_MS;
    dracinSetBan(until);
    return { ok:false, banUntil:until };
  }
  ts.push(now);
  dracinSetTimestamps(ts);
  return { ok:true };
}

async function dracinFetch(path){
  const gate = dracinCheckRate();
  if(!gate.ok) return { _banned:true, banUntil: gate.banUntil };
  try{
    // Proxy via backend -> IP ban dihandle server (anti clone)
    const base = (typeof API_BASE !== 'undefined' && API_BASE) ? API_BASE.replace(/\/$/,'') : '';
    const url = base + '/api/dracin?path=' + encodeURIComponent(path);
    console.log('[DRACIN-FETCH]', 'Path:', path, 'URL:', url);
    const res = await fetch(url);
    console.log('[DRACIN-FETCH]', 'Status:', res.status);
    if(res.status === 429){
      let j={}; try{ j = await res.json(); }catch(_){}
      const until = Date.now() + ((j.retryAfter||600) * 1000);
      dracinSetBan(until);
      console.warn('[DRACIN-FETCH]', 'Rate limited:', j.error);
      return { _banned:true, banUntil: until, _serverBan:true, _msg: j.error };
    }
    const text = await res.text();
    console.log('[DRACIN-FETCH]', 'Response size:', text.length, 'bytes');
    try{ return JSON.parse(text); }catch(_){ 
      console.error('[DRACIN-FETCH]', 'JSON parse error, returning raw:', text.slice(0,200));
      return { _raw:text, _status:res.status }; 
    }
  }catch(e){ 
    console.error('[DRACIN-FETCH]', 'Error:', e.message);
    return { _error: e.message }; 
  }
}


/* ---- State ---- */
const dracinState = { provider:null, drama:null, episode:1, quality:null, hls:null, episodesList:[], lastList:[], lastQuery:'', activeGenre:null, hlsInstance:null };

/* ---- UI mounting ---- */
function dracinScreen(){ return document.getElementById('dracin-screen'); }
function dracinOpen(){
  const s = dracinScreen();
  s.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  dracinShowLoading('Memuat Nonton Dracin...');
  setTimeout(()=> dracinViewProviders(), 600);
}
function dracinClose(){
  if(dracinState.hlsInstance){ try{ dracinState.hlsInstance.destroy(); }catch(_){} dracinState.hlsInstance=null; }
  dracinScreen().classList.add('hidden');
  dracinScreen().innerHTML = '';
  document.body.style.overflow = '';
}
function dracinTop(title, sub, onBack){
  return `<div class="dr-top">
    <button class="dr-back" data-dr-back>${I.back||'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>'}</button>
    <div style="flex:1;min-width:0"><div class="dr-title">${esc(title)}</div>${sub?`<div class="dr-sub">${esc(sub)}</div>`:''}</div>
  </div>`;
}
function dracinBindBack(handler){
  const b = dracinScreen().querySelector('[data-dr-back]');
  if(b) b.onclick = handler;
}
function dracinShowLoading(msg){
  dracinScreen().innerHTML = `${dracinTop('Nonton Dracin','', dracinClose)}
    <div class="dr-loading"><div class="dr-spinner"></div><div>${esc(msg||'Memuat...')}</div></div>`;
  dracinBindBack(dracinClose);
}
function dracinShowError(msg){
  const el = document.createElement('div');
  el.className = 'dr-error';
  el.textContent = msg;
  const old = dracinScreen().querySelector('.dr-error');
  if(old) old.remove();
  dracinScreen().appendChild(el);
  setTimeout(()=> el.remove(), 5000);
}
function dracinShowBan(banUntil){
  dracinScreen().innerHTML = `${dracinTop('Akses Dibatasi','', dracinClose)}
    <div class="dr-ban">
      <h2>Akses Diblokir Sementara</h2>
      <p>Anda melebihi batas <b>30 request per menit</b>.<br/>Silakan tunggu hingga blokir berakhir.</p>
      <div class="dr-ban-time" data-dr-ban-time>--:--</div>
      <p style="font-size:11px;color:#7b8597;margin-top:18px">Mencoba pakai tab clone/incognito tetap akan diblokir bila IP anda sama.</p>
    </div>`;
  dracinBindBack(dracinClose);
  const tEl = dracinScreen().querySelector('[data-dr-ban-time]');
  const tick = () => {
    const remain = banUntil - Date.now();
    if(remain <= 0){ localStorage.removeItem(dracinKey('ban')); dracinViewProviders(); return; }
    const m = Math.floor(remain/60000), s = Math.floor((remain%60000)/1000);
    tEl.textContent = String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
    setTimeout(tick, 500);
  };
  tick();
}

/* ---- View: Providers ---- */
function dracinViewProviders(){
  const ban = dracinGetBan();
  if(ban) return dracinShowBan(ban);
  const items = DRACIN_PROVIDERS.map(p =>
    `<button class="dr-provider" data-dr-prov="${p}">${esc(dracinLabel(p))}</button>`
  ).join('');
  dracinScreen().innerHTML = `${dracinTop('Pilih Provider','Tonton dracin dari 40+ platform', dracinClose)}
    <div class="dr-section">
      <h3>Provider Tersedia</h3>
      <div class="dr-providers">${items}</div>
    </div>`;
  dracinBindBack(dracinClose);
  dracinScreen().querySelectorAll('[data-dr-prov]').forEach(b => {
    b.onclick = () => { dracinState.provider = b.dataset.drProv; dracinState.activeGenre = null; dracinViewHome(); };
  });
}

/* ---- View: Home (popular + search + genres) ---- */
async function dracinViewHome(){
  const ban = dracinGetBan(); if(ban) return dracinShowBan(ban);
  const p = dracinState.provider;
  const genreChips = DRACIN_GENRES.map(g =>
    `<button class="dr-genre${dracinState.activeGenre===g?' active':''}" data-dr-genre="${g}">${g}</button>`
  ).join('');
  dracinScreen().innerHTML = `${dracinTop(dracinLabel(p), 'Pilih drama untuk ditonton', dracinViewProviders)}
    <div class="dr-section">
      <div class="dr-search-row">
        <input id="dr-q" placeholder="Cari judul drama..." value="${esc(dracinState.lastQuery||'')}">
        <button data-dr-search>Cari</button>
      </div>
      <div class="dr-genres">
        <button class="dr-genre${!dracinState.activeGenre?' active':''}" data-dr-genre="">Semua</button>
        ${genreChips}
      </div>
      <h3 data-dr-listhead>Dracin Populer</h3>
      <div class="dr-grid" data-dr-list>
        <div class="dr-loading" style="grid-column:1/-1"><div class="dr-spinner"></div><div>Memuat daftar...</div></div>
      </div>
    </div>`;
  dracinBindBack(dracinViewProviders);
  const q = dracinScreen().querySelector('#dr-q');
  const doSearch = () => {
    const val = q.value.trim();
    dracinState.lastQuery = val;
    dracinState.activeGenre = null;
    if(val) dracinLoadSearch(val); else dracinLoadHome();
  };
  dracinScreen().querySelector('[data-dr-search]').onclick = doSearch;
  q.addEventListener('keydown', e => { if(e.key==='Enter') doSearch(); });
  dracinScreen().querySelectorAll('[data-dr-genre]').forEach(g => {
    g.onclick = () => {
      const v = g.dataset.drGenre;
      dracinState.activeGenre = v || null;
      dracinState.lastQuery = '';
      q.value = '';
      if(!v) dracinLoadHome(); else dracinLoadGenre(v);
      dracinScreen().querySelectorAll('[data-dr-genre]').forEach(x => x.classList.toggle('active', x===g));
    };
  });
  if(dracinState.lastQuery) dracinLoadSearch(dracinState.lastQuery);
  else if(dracinState.activeGenre) dracinLoadGenre(dracinState.activeGenre);
  else dracinLoadHome();
}

function dracinRenderList(items, headLabel){
  const head = dracinScreen().querySelector('[data-dr-listhead]');
  const wrap = dracinScreen().querySelector('[data-dr-list]');
  if(!wrap) return;
  if(head) head.textContent = headLabel;
  if(!items || !items.length){
    wrap.innerHTML = `<div class="dr-empty" style="grid-column:1/-1">Tidak ada hasil</div>`;
    return;
  }
  dracinState.lastList = items;
  wrap.innerHTML = items.map(it => {
    const cover = it.cover || it.image || it.poster || '';
    const title = it.title || it.name || 'Untitled';
    const ep = it.episodes || it.totalEpisodes || it.episode || '';
    const genre = it.genre || it.category || '';
    return `<div class="dr-card" data-dr-id="${esc(it.id||it._id||'')}">
      <div class="dr-cover" style="background-image:url('${esc(cover)}')"></div>
      <div class="dr-meta">
        <div class="dr-name">${esc(title)}</div>
        <div class="dr-info"><span>${ep?'Ep '+esc(ep):''}</span><span>${esc(genre)}</span></div>
      </div>
    </div>`;
  }).join('');
  wrap.querySelectorAll('[data-dr-id]').forEach(c => {
    c.onclick = () => { const id = c.dataset.drId; if(id) dracinViewDetail(id); };
  });
}

async function dracinLoadHome(){
  const p = dracinState.provider;
  for(const ep of DRACIN_HOME_TRY){
    const d = await dracinFetch(`/${p}/api/v1/${ep}`);
    if(d._banned) return dracinShowBan(d.banUntil);
    const arr = Array.isArray(d) ? d : (d.result || d.data || d.items || d.list || []);
    if(Array.isArray(arr) && arr.length){ dracinRenderList(arr,'Dracin Populer'); return; }
  }
  dracinRenderList([],'Dracin Populer');
}
async function dracinLoadSearch(q){
  const p = dracinState.provider;
  const d = await dracinFetch(`/${p}/api/v1/search?q=`+encodeURIComponent(q));
  if(d._banned) return dracinShowBan(d.banUntil);
  const arr = Array.isArray(d) ? d : (d.result || d.data || []);
  dracinRenderList(arr, 'Hasil pencarian: '+q);
}
async function dracinLoadGenre(g){
  const p = dracinState.provider;
  let d = await dracinFetch(`/${p}/api/v1/channel?type=`+encodeURIComponent(g));
  if(d._banned) return dracinShowBan(d.banUntil);
  let arr = Array.isArray(d) ? d : (d.result || d.data || []);
  if(!arr.length){
    d = await dracinFetch(`/${p}/api/v1/genre?type=`+encodeURIComponent(g));
    if(d._banned) return dracinShowBan(d.banUntil);
    arr = Array.isArray(d) ? d : (d.result || d.data || []);
  }
  dracinRenderList(arr, 'Genre: '+g);
}

/* ---- View: Detail ---- */
async function dracinViewDetail(id){
  dracinShowLoading('Memuat detail drama...');
  const p = dracinState.provider;
  const d = await dracinFetch(`/${p}/api/v1/detail/${encodeURIComponent(id)}`);
  if(d._banned) return dracinShowBan(d.banUntil);
  const r = d.result || d.data || d;
  if(!r || !(r.id || r._id || r.title)) return dracinShowError('Detail tidak ditemukan');
  dracinState.drama = r;
  dracinState.episode = 1;
  dracinState.quality = null;
  dracinViewPlayer();
}

/* ---- View: Player ---- */
async function dracinViewPlayer(){
  const ban = dracinGetBan(); if(ban) return dracinShowBan(ban);
  const r = dracinState.drama;
  const totalEp = r.episodes || r.totalEpisodes || 1;
  dracinScreen().innerHTML = `${dracinTop(r.title||'Drama', dracinLabel(dracinState.provider)+' • Episode '+dracinState.episode, dracinViewHome)}
    <div class="dr-player-wrap" data-dr-player>
      <video data-dr-video playsinline controls></video>
      <div class="dr-player-overlay" data-dr-overlay>2x</div>
    </div>
    <div class="dr-detail-bar">
      <h2>${esc(r.title||'')}</h2>
      <div class="dr-detail-tags">
        ${r.genre?`<span>${esc(r.genre)}</span>`:''}
        ${r.language?`<span>${esc(r.language)}</span>`:''}
        ${totalEp?`<span>${esc(totalEp)} episode</span>`:''}
      </div>
      ${r.desc||r.description?`<p class="dr-detail-desc">${esc(r.desc||r.description)}</p>`:''}
    </div>
    <div class="dr-controls">
      <button class="dr-ctrl-btn" data-dr-toggle="res">Resolusi <span data-dr-cur-res>—</span></button>
      <button class="dr-ctrl-btn" data-dr-toggle="ep">Episode ${dracinState.episode} / ${totalEp}</button>
    </div>
    <div class="dr-ep-panel" data-dr-panel-res style="display:none">
      <h3 style="font-family:'Space Grotesk',sans-serif;font-size:13px;margin:0 0 10px;color:#c6cdda">Pilih Resolusi</h3>
      <div class="dr-res-list" data-dr-res-list><div style="color:#7b8597;font-size:12px">Memuat...</div></div>
    </div>
    <div class="dr-ep-panel" data-dr-panel-ep style="display:none">
      <h3 style="font-family:'Space Grotesk',sans-serif;font-size:13px;margin:0 0 10px;color:#c6cdda">Daftar Episode</h3>
      <div class="dr-ep-grid" data-dr-ep-grid></div>
    </div>`;
  dracinBindBack(dracinViewHome);

  // Toggle panels
  dracinScreen().querySelectorAll('[data-dr-toggle]').forEach(b => {
    b.onclick = () => {
      const k = b.dataset.drToggle;
      const panel = dracinScreen().querySelector(k==='ep'?'[data-dr-panel-ep]':'[data-dr-panel-res]');
      const open = panel.style.display !== 'none';
      panel.style.display = open ? 'none' : '';
      b.classList.toggle('active', !open);
    };
  });

  // Render episode grid
  const grid = dracinScreen().querySelector('[data-dr-ep-grid]');
  grid.innerHTML = '';
  for(let i=1; i<=totalEp; i++){
    const b = document.createElement('button');
    b.className = 'dr-ep-btn'+(i===dracinState.episode?' active':'');
    b.textContent = i;
    b.onclick = () => { dracinState.episode = i; dracinState.quality = null; dracinViewPlayer(); };
    grid.appendChild(b);
  }

  await dracinLoadStream();
  dracinBindLongPress();
}

async function dracinLoadStream(){
  const p = dracinState.provider;
  const id = dracinState.drama.id || dracinState.drama._id;
  const d = await dracinFetch(`/${p}/api/v1/play/${encodeURIComponent(id)}/${dracinState.episode}`);
  if(d._banned) return dracinShowBan(d.banUntil);
  const r = d.result || d.data || d;
  if(!r || (!r.hlsUrl && !r.quality && !r.url)) return dracinShowError('Stream tidak tersedia');
  dracinState.hls = r.hlsUrl || r.url;
  const qualities = Array.isArray(r.quality) ? r.quality : [];
  // resolusi list
  const resWrap = dracinScreen().querySelector('[data-dr-res-list]');
  if(qualities.length){
    resWrap.innerHTML = qualities.map(q =>
      `<button data-dr-q="${esc(q.url)}" data-dr-d="${esc(q.definition)}">${esc(q.definition)}</button>`
    ).join('');
    resWrap.querySelectorAll('[data-dr-q]').forEach(b => {
      b.onclick = () => {
        dracinState.quality = b.dataset.drQ;
        dracinScreen().querySelector('[data-dr-cur-res]').textContent = b.dataset.drD;
        resWrap.querySelectorAll('button').forEach(x => x.classList.toggle('active', x===b));
        dracinPlayUrl(b.dataset.drQ);
      };
    });
    // pilih default (paling tinggi)
    const def = qualities[0];
    dracinState.quality = def.url;
    dracinScreen().querySelector('[data-dr-cur-res]').textContent = def.definition;
    const first = resWrap.querySelector('[data-dr-q]'); if(first) first.classList.add('active');
  }else{
    resWrap.innerHTML = '<div style="color:#7b8597;font-size:12px">Auto (HLS adaptive)</div>';
    dracinScreen().querySelector('[data-dr-cur-res]').textContent = 'Auto';
  }
  dracinPlayUrl(dracinState.quality || dracinState.hls);
}

function dracinPlayUrl(url){
  if(!url) return;
  const v = dracinScreen().querySelector('[data-dr-video]');
  if(!v) return;
  if(dracinState.hlsInstance){ try{ dracinState.hlsInstance.destroy(); }catch(_){} dracinState.hlsInstance=null; }
  // Pakai hls.js untuk HLS bila bukan Safari
  const isHls = /\.m3u8(\?|$)/i.test(url);
  if(isHls && !v.canPlayType('application/vnd.apple.mpegurl')){
    if(typeof Hls === 'undefined'){
      const s = document.createElement('script');
      s.src = 'https://cdn.jsdelivr.net/npm/hls.js@1.5.7/dist/hls.min.js';
      s.onload = () => dracinPlayUrl(url);
      document.head.appendChild(s);
      return;
    }
    const hls = new Hls();
    hls.loadSource(url);
    hls.attachMedia(v);
    dracinState.hlsInstance = hls;
  }else{
    v.src = url;
  }
  v.play().catch(()=>{});
  // Auto-scroll ke episode berikut saat selesai
  v.onended = () => {
    const total = dracinState.drama.episodes || dracinState.drama.totalEpisodes || 1;
    if(dracinState.episode < total){
      dracinState.episode++; dracinState.quality = null; dracinViewPlayer();
    }
  };
}

/* ---- Long-press (tahan) untuk 2x speed ---- */
function dracinBindLongPress(){
  const wrap = dracinScreen().querySelector('[data-dr-player]');
  const v = wrap && wrap.querySelector('video');
  const ov = wrap && wrap.querySelector('[data-dr-overlay]');
  if(!wrap || !v || !ov) return;
  let timer = null, holding = false;
  const start = (e) => {
    timer = setTimeout(() => {
      holding = true; v.playbackRate = 2.0; ov.classList.add('show');
    }, 400);
  };
  const end = () => {
    clearTimeout(timer);
    if(holding){ holding = false; v.playbackRate = 1.0; ov.classList.remove('show'); }
  };
  wrap.addEventListener('touchstart', start, {passive:true});
  wrap.addEventListener('touchend', end);
  wrap.addEventListener('touchcancel', end);
  wrap.addEventListener('mousedown', start);
  wrap.addEventListener('mouseup', end);
  wrap.addEventListener('mouseleave', end);
}

/* ---- Tool card (entry point di home grid) ---- */
T({
  id:'nonton-dracin', name:'Nonton Dracin', cat:['video','fun'], catLabel:'Video',
  icon:'video', desc:'Tonton drama dari 40+ platform: BiliTV, ShortMax, DramaBox, dll.',
  tags:'dracin drama nonton streaming bilitv shortmax dramabox china korea',
  body:`<button class="btn" data-act="go">${I.video||I.send}<span>Buka Nonton Dracin</span></button>`,
  run: () => { dracinOpen(); }
});

/* ====================== DEPLOY TO VERCEL ====================== */
(function(){

  function deployScreen(){ return document.getElementById('dracin-screen'); }
  function deployOpen(html){
    const s = deployScreen();
    s.innerHTML = html;
    s.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
  function deployClose(){
    deployScreen().classList.add('hidden');
    deployScreen().innerHTML = '';
    document.body.style.overflow = '';
  }

  // Deteksi framework dari nama file
  function detectFramework(files){
    const names = files.map(f=>f.name).join(',');
    if(/next\.config/.test(names)) return 'nextjs';
    if(/nuxt\.config/.test(names)) return 'nuxtjs';
    if(/svelte\.config|\.svelte/.test(names)) return 'svelte';
    if(/vite\.config/.test(names)) return 'vite';
    if(/vue\.config|\.vue/.test(names)) return 'vue';
    if(/angular\.json/.test(names)) return 'angular';
    if(/gatsby-config/.test(names)) return 'gatsby';
    if(/package\.json/.test(names)) return 'vite';
    return null;
  }

  function fwLabel(fw){
    const map = { nextjs:'Next.js', nuxtjs:'Nuxt.js', svelte:'Svelte', vite:'Vite', vue:'Vue', angular:'Angular', gatsby:'Gatsby', auto:'Deteksi Otomatis', '':'Static HTML' };
    return map[fw] || fw || 'Static HTML';
  }

  function renderDeployHome(){
    deployOpen(`
      <div class="dr-top">
        <button class="dr-back" onclick="this.closest('#dracin-screen').classList.add('hidden');this.closest('#dracin-screen').innerHTML='';document.body.style.overflow=''">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div style="flex:1;min-width:0"><div class="dr-title">🚀 Deploy ke Vercel</div><div class="dr-sub">Upload file & deploy langsung</div></div>
      </div>
      <div style="padding:20px;max-width:640px;margin:0 auto;display:flex;flex-direction:column;gap:18px">
        <div style="background:rgba(168,85,247,.08);border:1px solid rgba(168,85,247,.2);border-radius:12px;padding:14px 16px;font-size:13px;color:#c4b5fd">
          ⚡ Limit: <b>1 deploy per menit</b>. File akan langsung live di Vercel.
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          <label style="font-size:13px;font-weight:600;color:#e2e8f0">Nama Project</label>
          <input id="dp-name" class="input" placeholder="my-awesome-project" style="text-transform:lowercase" oninput="this.value=this.value.toLowerCase().replace(/[^a-z0-9-]/g,'-').replace(/-+/g,'-')">
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          <label style="font-size:13px;font-weight:600;color:#e2e8f0">Framework</label>
          <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px" id="dp-fw-grid">
            ${['auto','nextjs','vite','vue','nuxtjs','svelte','gatsby',''].map(fw=>`
              <button class="dp-fw-btn" data-fw="${fw}" onclick="window.__dpSelectFw(this)" style="padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:#cbd5e1;font-size:13px;cursor:pointer;transition:all .18s;text-align:left">
                ${fw==='auto'?'🔍 Deteksi Otomatis':fw===''?'📄 Static HTML':fw==='nextjs'?'▲ Next.js':fw==='vite'?'⚡ Vite':fw==='vue'?'💚 Vue':fw==='nuxtjs'?'🌿 Nuxt.js':fw==='svelte'?'🧡 Svelte':'🌸 Gatsby'}
              </button>`).join('')}
          </div>
          <input id="dp-fw-val" type="hidden" value="auto">
        </div>
        <div style="display:flex;flex-direction:column;gap:10px">
          <label style="font-size:13px;font-weight:600;color:#e2e8f0">Upload File</label>
          <label style="display:flex;align-items:center;gap:10px;padding:14px 16px;border:1.5px dashed rgba(168,85,247,.4);border-radius:12px;cursor:pointer;color:#a78bfa;font-size:13px;transition:border-color .18s" onmouseover="this.style.borderColor='rgba(168,85,247,.8)'" onmouseout="this.style.borderColor='rgba(168,85,247,.4)'">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            Pilih File (multiple)
            <input type="file" multiple id="dp-files" style="display:none" onchange="window.__dpPreviewFiles(this)">
          </label>
          <div id="dp-file-list" style="display:flex;flex-direction:column;gap:6px;max-height:180px;overflow-y:auto"></div>
        </div>
        <button id="dp-submit-btn" class="btn" onclick="window.__dpSubmit()" style="width:100%;justify-content:center">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2L11 13"/><path d="M22 2L15 22l-4-9-9-4 20-7z"/></svg>
          <span>Deploy Sekarang</span>
        </button>
        <div id="dp-status" style="display:none"></div>
        <div id="dp-result" style="display:none"></div>
      </div>
    `);

    // select framework
    window.__dpSelectFw = function(btn){
      document.querySelectorAll('.dp-fw-btn').forEach(b=>{ b.style.background='rgba(255,255,255,.04)'; b.style.borderColor='rgba(255,255,255,.1)'; b.style.color='#cbd5e1'; });
      btn.style.background='rgba(168,85,247,.18)'; btn.style.borderColor='rgba(168,85,247,.6)'; btn.style.color='#a855f7';
      document.getElementById('dp-fw-val').value = btn.dataset.fw;
    };
    // auto-select first
    const firstFwBtn = document.querySelector('.dp-fw-btn[data-fw="auto"]');
    if(firstFwBtn) window.__dpSelectFw(firstFwBtn);

    // preview files
    window.__dpPreviewFiles = function(input){
      const list = document.getElementById('dp-file-list');
      list.innerHTML = '';
      Array.from(input.files).forEach(f=>{
        const row = document.createElement('div');
        row.style.cssText='display:flex;align-items:center;gap:8px;padding:8px 10px;background:rgba(255,255,255,.04);border-radius:8px;font-size:12px;color:#94a3b8';
        row.innerHTML=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(f.name)}</span><span style="white-space:nowrap;color:#64748b">${(f.size/1024).toFixed(1)}KB</span>`;
        list.appendChild(row);
      });
      // Auto-detect framework
      const fw = document.getElementById('dp-fw-val').value;
      if(fw === 'auto'){
        const detected = detectFramework(Array.from(input.files));
        if(detected){
          const btn = document.querySelector(`.dp-fw-btn[data-fw="${detected}"]`);
          if(btn) window.__dpSelectFw(btn);
        }
      }
    };

    // submit
    window.__dpSubmit = async function(){
      const name = (document.getElementById('dp-name').value||'').trim().toLowerCase().replace(/[^a-z0-9-]/g,'-').replace(/-+/g,'-');
      if(!name){ showNotif('error','Error','Nama project wajib diisi.'); return; }
      const fwVal = document.getElementById('dp-fw-val').value;
      const fileInput = document.getElementById('dp-files');
      if(!fileInput.files.length){ showNotif('error','Error','Pilih minimal 1 file.'); return; }

      // Read files — extract ZIP kalau ada
      const files = [];
      for(const f of fileInput.files){
        if(f.name.toLowerCase().endsWith('.zip') && typeof JSZip !== 'undefined'){
          try {
            const zip = await JSZip.loadAsync(f);
            const entries = Object.keys(zip.files);
            for(const name of entries){
              const entry = zip.files[name];
              if(entry.dir) continue;
              const entryName = name.replace(/^[^/]+\//, ''); // strip root folder
              if(!entryName) continue;
              const b64 = await entry.async('base64');
              files.push({ file: entryName, data: b64, encoding: 'base64' });
            }
          } catch(e) {
            // fallback kirim as-is
            const b64 = await new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result.split(',')[1]); r.onerror=rej; r.readAsDataURL(f); });
            files.push({ file: f.name, data: b64, encoding: 'base64' });
          }
        } else {
          const b64 = await new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result.split(',')[1]); r.onerror=rej; r.readAsDataURL(f); });
          files.push({ file: f.name, data: b64, encoding: 'base64' });
        }
      }

      // Framework
      let fw = fwVal;
      if(fw === 'auto'){ const det=detectFramework(Array.from(fileInput.files)); fw = det||''; }

      const statusEl = document.getElementById('dp-status');
      const resultEl = document.getElementById('dp-result');
      const btn = document.getElementById('dp-submit-btn');
      btn.disabled = true; btn.style.opacity = '0.5';
      statusEl.style.display='block';
      statusEl.innerHTML=`<div style="display:flex;align-items:center;gap:10px;padding:14px 16px;background:rgba(168,85,247,.08);border:1px solid rgba(168,85,247,.2);border-radius:12px;font-size:13px;color:#c4b5fd"><div class="spinner" style="width:16px;height:16px;border:2px solid rgba(168,85,247,.3);border-top-color:#a855f7;border-radius:50%;animation:spin 0.8s linear infinite;flex-shrink:0"></div>Mengirim file ke Vercel...</div>`;
      resultEl.style.display='none';

      try {
        const resp = await fetch(API+'deploy', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ name, framework: fw||null, files }) });
        const data = await resp.json();
        if(!data.status){ statusEl.innerHTML=`<div style="padding:14px 16px;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:12px;font-size:13px;color:#f87171">❌ ${esc(data.error)}</div>`; btn.disabled=false; btn.style.opacity='1'; return; }

        const depId = data.deploymentId;
        let url = data.url;
        let ready = data.readyState;

        // Konsol log
        const logLines = [];
        function appendLog(line){ logLines.push(line); document.getElementById('dp-console').innerText = logLines.join('\n'); }

        statusEl.innerHTML=`<div style="display:flex;flex-direction:column;gap:10px">
          <div style="display:flex;align-items:center;gap:10px;padding:14px 16px;background:rgba(168,85,247,.08);border:1px solid rgba(168,85,247,.2);border-radius:12px;font-size:13px;color:#c4b5fd">
            <div class="spinner" style="width:16px;height:16px;border:2px solid rgba(168,85,247,.3);border-top-color:#a855f7;border-radius:50%;animation:spin 0.8s linear infinite;flex-shrink:0"></div>
            <span id="dp-status-txt">Building... (${fwLabel(fw)})</span>
          </div>
          <div style="background:#0d0d0d;border-radius:10px;padding:12px;font-family:'JetBrains Mono',monospace;font-size:11px;color:#a3e635;max-height:200px;overflow-y:auto;border:1px solid rgba(255,255,255,.06)" id="dp-console">Deployment ID: ${esc(depId)}\nFramework: ${fwLabel(fw)}\nStatus: ${ready||'QUEUED'}...</div>
        </div>`;

        appendLog(`[init] Deployment ID: ${depId}`);
        appendLog(`[init] Framework: ${fwLabel(fw)}`);
        appendLog(`[init] Files: ${files.map(f=>f.file).join(', ')}`);

        // Poll status + logs
        let attempt = 0;
        while(!['READY','ERROR','CANCELED'].includes(ready) && attempt < 40){
          await new Promise(r=>setTimeout(r,3000));
          attempt++;
          try{
            const st = await fetch(API+`deploy/status/${encodeURIComponent(depId)}`).then(r=>r.json());
            ready = st.readyState||ready;
            if(st.url) url = st.url;
            const stTxt = document.getElementById('dp-status-txt');
            if(stTxt) stTxt.textContent = `${ready} — ${fwLabel(fw)} (${attempt*3}s)`;
            appendLog(`[${attempt*3}s] State: ${ready}`);
          }catch{}
          // ambil logs tiap 3 iterasi
          if(attempt%3===0){
            try{
              const lg = await fetch(API+`deploy/logs/${encodeURIComponent(depId)}`).then(r=>r.json());
              if(lg.logs){
                const newLines = lg.logs.split('\n').filter(l=>l.trim()&&!logLines.includes(l));
                newLines.forEach(l=>appendLog(l));
              }
            }catch{}
          }
        }

        statusEl.style.display='none';
        resultEl.style.display='block';

        if(ready==='READY'){
          resultEl.innerHTML=`<div style="display:flex;flex-direction:column;gap:12px;padding:18px;background:rgba(34,197,94,.06);border:1px solid rgba(34,197,94,.25);border-radius:14px">
            <div style="display:flex;align-items:center;gap:8px;font-size:15px;font-weight:700;color:#4ade80">✅ Deploy Berhasil!</div>
            <div style="font-size:13px;color:#86efac">Framework: <b>${fwLabel(fw)}</b> · Files: <b>${files.length}</b></div>
            <a href="${esc(url)}" target="_blank" style="display:flex;align-items:center;gap:8px;padding:12px 16px;background:rgba(34,197,94,.12);border-radius:10px;color:#4ade80;font-size:13px;font-weight:600;text-decoration:none;word-break:break-all">
              🌐 ${esc(url)}
            </a>
            <iframe src="${esc(url)}" style="width:100%;height:320px;border:none;border-radius:10px;margin-top:4px" loading="lazy" sandbox="allow-scripts allow-same-origin allow-forms"></iframe>
            <button class="btn" onclick="window.__dpSubmit=undefined;renderDeployHome&&renderDeployHome()" style="width:100%;justify-content:center;background:rgba(168,85,247,.15);color:#a855f7">🚀 Deploy Lagi</button>
          </div>`;
        } else {
          resultEl.innerHTML=`<div style="padding:16px;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:12px;font-size:13px;color:#f87171">❌ Deploy gagal (${ready}). Cek konsol di atas.</div>`;
          btn.disabled=false; btn.style.opacity='1';
        }
      } catch(e){
        statusEl.innerHTML=`<div style="padding:14px 16px;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:12px;font-size:13px;color:#f87171">❌ ${esc(e.message)}</div>`;
        btn.disabled=false; btn.style.opacity='1';
      }
    };
  }

  // Inject CSS spin jika belum ada
  if(!document.getElementById('dp-style')){
    const s=document.createElement('style');
    s.id='dp-style';
    s.textContent=`@keyframes spin{to{transform:rotate(360deg)}}`;
    document.head.appendChild(s);
  }

  // Expose untuk dipakai tool card
  window.renderDeployHome = renderDeployHome;

  T({
    id:'deploy',
    name:'Deploy ke Vercel',
    cat:['utility'],
    catLabel:'Utilitas',
    icon:'send',
    desc:'Upload file HTML/JS/CSS atau project framework dan langsung deploy ke Vercel. Live dalam hitungan menit.',
    tags:'deploy vercel hosting website upload html nextjs vite vue svelte',
    body:`<button class="btn" data-act="go"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2L11 13"/><path d="M22 2L15 22l-4-9-9-4 20-7z"/></svg><span>Buka Deploy</span></button>`,
    run: () => { renderDeployHome(); }
  });
})();

/* ====================== KTP BOT ====================== */
(function(){
  function ktpScreen(){ return document.getElementById('dracin-screen'); }
  function ktpOpen(html){
    const s = ktpScreen();
    s.innerHTML = html;
    s.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
  function ktpClose(){
    ktpScreen().classList.add('hidden');
    ktpScreen().innerHTML = '';
    document.body.style.overflow = '';
  }

  function esc(s){ const d=document.createElement('div'); d.textContent=s; return d.innerHTML; }

  async function renderKtpHome(){
    // Cek apakah sudah punya KTP
    const ip = await fetch(API+'ip').then(r=>r.json()).catch(()=>({ip:'unknown'}));
    ktpOpen(`
      <div class="dr-top">
        <button class="dr-back" onclick="this.closest('#dracin-screen').classList.add('hidden');this.closest('#dracin-screen').innerHTML='';document.body.style.overflow=''">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div style="flex:1;min-width:0"><div class="dr-title">🪪 KTP Bot</div><div class="dr-sub">Identitas resmi pengguna bot</div></div>
      </div>
      <div style="padding:20px;max-width:640px;margin:0 auto;display:flex;flex-direction:column;gap:16px">
        <div style="background:rgba(168,85,247,.08);border:1px solid rgba(168,85,247,.2);border-radius:12px;padding:14px 16px;font-size:13px;color:#c4b5fd">
          🪪 Buat KTP virtual kamu! Data disimpan aman di server. KTP dibutuhkan untuk akses fitur premium bot.
        </div>
        <button class="btn" onclick="window.__ktpCreate()" style="width:100%;justify-content:center;background:rgba(168,85,247,.15);color:#a855f7;border:1px solid rgba(168,85,247,.3)">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
          <span>Buat KTP Baru</span>
        </button>
        <button class="btn" onclick="window.__ktpLookup()" style="width:100%;justify-content:center">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <span>Lihat KTP Saya</span>
        </button>
        <div id="ktp-result" style="display:none"></div>
      </div>
    `);
  }

  window.__ktpCreate = function(){
    ktpOpen(`
      <div class="dr-top">
        <button class="dr-back" onclick="window.renderKtpHome()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div style="flex:1;min-width:0"><div class="dr-title">🪪 Buat KTP</div><div class="dr-sub">Isi data dengan benar</div></div>
      </div>
      <div style="padding:20px;max-width:640px;margin:0 auto;display:flex;flex-direction:column;gap:14px">
        ${[
          ['ktp-nama','Nama Lengkap','text','Contoh: Budi Santoso'],
          ['ktp-ttl','Tempat Lahir','text','Contoh: Jakarta'],
          ['ktp-tgl','Tanggal Lahir','date',''],
          ['ktp-jk','Jenis Kelamin','select','Laki-laki|Perempuan'],
          ['ktp-alamat','Alamat','text','Contoh: Jl. Merdeka No. 1'],
          ['ktp-pekerjaan','Pekerjaan','text','Contoh: Programmer'],
          ['ktp-agama','Agama','select','Islam|Kristen|Katolik|Hindu|Buddha|Konghucu'],
          ['ktp-status','Status Perkawinan','select','Belum Kawin|Kawin|Cerai Hidup|Cerai Mati'],
        ].map(([id,label,type,ph])=>{
          if(type==='select'){
            const opts = ph.split('|').map(o=>`<option value="${o}">${o}</option>`).join('');
            return `<div style="display:flex;flex-direction:column;gap:6px">
              <label style="font-size:12px;font-weight:600;color:#94a3b8">${label}</label>
              <select id="${id}" class="input" style="background:#0f172a;color:#e2e8f0">${opts}</select>
            </div>`;
          }
          return `<div style="display:flex;flex-direction:column;gap:6px">
            <label style="font-size:12px;font-weight:600;color:#94a3b8">${label}</label>
            <input id="${id}" type="${type}" class="input" placeholder="${ph}">
          </div>`;
        }).join('')}
        <button class="btn" onclick="window.__ktpSubmit()" style="width:100%;justify-content:center;margin-top:6px">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2L11 13"/><path d="M22 2L15 22l-4-9-9-4 20-7z"/></svg>
          <span>Generate KTP</span>
        </button>
        <div id="ktp-form-status" style="display:none"></div>
      </div>
    `);
  };

  window.__ktpSubmit = async function(){
    const get = id => (document.getElementById(id)?.value||'').trim();
    const nama = get('ktp-nama'), ttl = get('ktp-ttl'), tgl = get('ktp-tgl'),
          jk = get('ktp-jk'), alamat = get('ktp-alamat'), pekerjaan = get('ktp-pekerjaan'),
          agama = get('ktp-agama'), status = get('ktp-status');

    if(!nama||!ttl||!tgl||!alamat||!pekerjaan){
      showNotif('error','Error','Semua field wajib diisi.'); return;
    }

    const st = document.getElementById('ktp-form-status');
    st.style.display='block';
    st.innerHTML=`<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:rgba(168,85,247,.08);border:1px solid rgba(168,85,247,.2);border-radius:10px;font-size:13px;color:#c4b5fd"><div class="spinner" style="width:14px;height:14px;border:2px solid rgba(168,85,247,.3);border-top-color:#a855f7;border-radius:50%;animation:spin 0.8s linear infinite;flex-shrink:0"></div>Membuat KTP...</div>`;

    try {
      const resp = await fetch(API+'ktp/create', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ nama, tempat_lahir:ttl, tanggal_lahir:tgl, jenis_kelamin:jk, alamat, pekerjaan, agama, status_kawin:status })
      });
      const data = await resp.json();
      if(!data.status){ st.innerHTML=`<div style="padding:12px;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:10px;font-size:13px;color:#f87171">❌ ${esc(data.error)}</div>`; return; }

      st.innerHTML='';
      // Tampilkan KTP image
      ktpOpen(`
        <div class="dr-top">
          <button class="dr-back" onclick="window.renderKtpHome()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
          </button>
          <div style="flex:1;min-width:0"><div class="dr-title">🪪 KTP Berhasil!</div><div class="dr-sub">KTP kamu sudah jadi</div></div>
        </div>
        <div style="padding:20px;max-width:640px;margin:0 auto;display:flex;flex-direction:column;gap:16px;align-items:center">
          <img src="${data.ktp_url}" style="width:100%;max-width:480px;border-radius:14px;border:1px solid rgba(255,255,255,.1);box-shadow:0 8px 32px rgba(0,0,0,.4)" alt="KTP">
          <div style="display:flex;gap:10px;width:100%;max-width:480px">
            <a href="${data.ktp_url}" download="KTP_${esc(nama)}.png" class="btn" style="flex:1;justify-content:center">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              <span>Download</span>
            </a>
            <button class="btn" onclick="window.renderKtpHome()" style="flex:1;justify-content:center;background:rgba(255,255,255,.06);color:#94a3b8">
              <span>Kembali</span>
            </button>
          </div>
        </div>
      `);
    } catch(e) {
      st.innerHTML=`<div style="padding:12px;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:10px;font-size:13px;color:#f87171">❌ ${esc(e.message)}</div>`;
    }
  };

  window.__ktpLookup = async function(){
    const st = document.getElementById('ktp-result');
    if(!st) return;
    st.style.display='block';
    st.innerHTML=`<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:rgba(168,85,247,.08);border:1px solid rgba(168,85,247,.2);border-radius:10px;font-size:13px;color:#c4b5fd"><div class="spinner" style="width:14px;height:14px;border:2px solid rgba(168,85,247,.3);border-top-color:#a855f7;border-radius:50%;animation:spin 0.8s linear infinite;flex-shrink:0"></div>Mencari KTP...</div>`;
    try {
      const data = await fetch(API+'ktp/my').then(r=>r.json());
      if(!data.status||!data.ktp_url){
        st.innerHTML=`<div style="padding:12px;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:10px;font-size:13px;color:#f87171">❌ KTP tidak ditemukan. Buat KTP terlebih dahulu.</div>`; return;
      }
      st.innerHTML=`<div style="display:flex;flex-direction:column;gap:10px">
        <img src="${data.ktp_url}" style="width:100%;border-radius:12px;border:1px solid rgba(255,255,255,.1)" alt="KTP">
        <a href="${data.ktp_url}" download class="btn" style="width:100%;justify-content:center">⬇️ Download KTP</a>
      </div>`;
    } catch(e) {
      st.innerHTML=`<div style="padding:12px;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.3);border-radius:10px;font-size:13px;color:#f87171">❌ ${esc(e.message)}</div>`;
    }
  };

  window.renderKtpHome = renderKtpHome;

  T({
    id:'ktp',
    name:'🪪 KTP Bot',
    cat:['utility'],
    catLabel:'Utilitas',
    icon:'user',
    desc:'Buat KTP virtual kamu! Data disimpan aman. KTP dibutuhkan untuk akses fitur premium bot.',
    tags:'ktp identitas kartu tanda penduduk bot virtual',
    body:`<button class="btn" data-act="go"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg><span>Buka KTP</span></button>`,
    run: () => { renderKtpHome(); }
  });

  /* ====================== NEWLY TOOL — TAMBAHAN BARU ====================== */

  // IQC v3
  T({id:'iqcv3',name:'👤 IQC v3',cat:['ai','generator'],catLabel:'AI',icon:'avatar',desc:'Buat chat IQC versi 3 dengan style lebih baru.',
    tags:'iqc v3 avatar karakter chat generator',
    body:`<div class="field"><input class="input" data-k="text" placeholder="Pesan chat..."></div>
          <div class="field"><input class="input" data-k="time" placeholder="Waktu (22.54)"></div>
          <button class="btn" data-act="go">${I.avatar||I.star}<span>Buat IQC v3</span></button>`,
    run:async(c,btn)=>{
      const text=$('[data-k=text]',c).value.trim();if(!text) return showErr(c,'Pesan wajib diisi.');
      const time=$('[data-k=time]',c).value.trim()||'22.54';
      setLoading(btn,true);
      const d=await fetchAPI(API+'internal/iqcv3',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,time})});
      setLoading(btn,false);
      if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
      const url=d.result||d.url||d.image||d.data;
      showResult(c,`<img src="${esc(url)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(url)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
    }
  });

  // TikTok Quote Chat
  T({id:'ttquote',name:'💬 TikTok Quote', cat:['fun','generator'],catLabel:'Fun',icon:'tt',desc:'Buat quote chat ala TikTok dengan foto profil kamu.',
    tags:'tiktok quote chat generator foto',
    body:`<div class="field"><input class="input" data-k="username" placeholder="Username..."></div>
          <div class="field"><textarea class="textarea" data-k="text" placeholder="Pesan chat..."></textarea></div>
          <div class="field"><button class="btn btn-ghost" data-act="upload">${I.upload}<span>Upload Foto Profil</span></button></div>
          <button class="btn" data-act="go">${I.send}<span>Buat Quote</span></button>`,
    init:(c)=>{
      let avatarB64='';
      $('[data-act=upload]',c).onclick=()=>{
        const inp=document.createElement('input');
        inp.type='file';inp.accept='image/*';
        inp.onchange=()=>{
          const f=inp.files[0];if(!f)return;
          const reader=new FileReader();
          reader.onload=()=>{avatarB64=reader.result;showNotif('success','Foto siap','Foto profil berhasil dimuat');};
          reader.readAsDataURL(f);
        };
        inp.click();
      };
      c._getAvatar=()=>avatarB64;
    },
    run:async(c,btn)=>{
      const username=$('[data-k=username]',c).value.trim();if(!username) return showErr(c,'Username wajib diisi.');
      const text=$('[data-k=text]',c).value.trim();if(!text) return showErr(c,'Pesan wajib diisi.');
      const avatar=c._getAvatar?c._getAvatar():'';
      setLoading(btn,true);
      const d=await fetchAPI(API+'internal/tiktok-quote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,text,avatar})});
      setLoading(btn,false);
      if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
      const url=d.result||d.url||d.image||d.data;
      showResult(c,`<img src="${esc(url)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(url)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
    }
  });

  // FF Lobby Generator - menggunakan API Nexray
  T({id:'fflobby',name:'🎮 FF Lobby',cat:['fun','generator'],catLabel:'Fun',icon:'meme',desc:'Buat lobby Free Fire dengan username kamu.',
    tags:'free fire ff lobby generator username nexray',
    body:`<div class="field"><input class="input" data-k="username" placeholder="Username Free Fire..."></div>
          <button class="btn" data-act="go">${I.game||I.star}<span>Buat Lobby</span></button>`,
    run:async(c,btn)=>{
      const username=$('[data-k=username]',c).value.trim()||'Player';
      setLoading(btn,true);
      try{
        await waitAPIReady();
        const apiUrl=API+'internal/fflobby?nickname='+encodeURIComponent(username);
        const r=await fetch(apiUrl);
        if(!r.ok){
          setLoading(btn,false);
          let msg='Gagal buat lobby.';
          try{const d=await r.json();msg=d.error||msg;}catch(_){}
          return showErr(c,msg);
        }
        const blob=await r.blob();
        const url=URL.createObjectURL(blob);
        setLoading(btn,false);
        showResult(c,`<img src="${esc(url)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(url)}" download="fflobby.jpg" class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
      }catch(e){
        setLoading(btn,false);
        return showErr(c,e.message);
      }
    }
  });

  // ML Lobby Generator dengan upload foto
  T({id:'mllobby',name:'🎮 ML Lobby',cat:['fun','generator'],catLabel:'Fun',icon:'meme',desc:'Buat lobby Mobile Legends dengan avatar custom.',
    tags:'mobile legends ml lobby generator username avatar foto',
    body:`<div class="field"><input class="input" data-k="username" placeholder="Username Mobile Legends..."></div>
          <div class="field"><button class="btn btn-ghost" data-act="upload">${I.upload}<span>Upload Foto Avatar</span></button></div>
          <button class="btn" data-act="go">${I.game||I.star}<span>Buat Lobby</span></button>`,
    init:(c)=>{
      let avatarUrl='https://i.pinimg.com/736x/55/33/45/553345cc94a8f8368ec446ef272dd099.jpg';
      $('[data-act=upload]',c).onclick=()=>{
        const inp=document.createElement('input');
        inp.type='file';inp.accept='image/*';
        inp.onchange=()=>{
          const f=inp.files[0];if(!f)return;
          showNotif('info','Uploading...','Mengunggah foto ke server...');
          const reader=new FileReader();
          reader.onload=async()=>{
            const base64=reader.result;
            try{
              await waitAPIReady();
              const r=await fetch(API+'media/upload',{
                method:'POST',
                headers:{'Content-Type':'application/json'},
                body:JSON.stringify({type:'foto', filename:f.name, base64, mimetype:f.type})
              });
              const d=await r.json();
              if(d.status&&d.raw_url){
                avatarUrl=d.raw_url;
                showNotif('success','Sukses!','Foto berhasil diupload');
              }else{
                showNotif('error','Gagal!',d.error||'Upload gagal');
              }
            }catch(e){
              showNotif('error','Error!',e.message);
            }
          };
          reader.readAsDataURL(f);
        };
        inp.click();
      };
      c._getAvatarUrl=()=>avatarUrl;
    },
    run:async(c,btn)=>{
      const username=$('[data-k=username]',c).value.trim()||'Player';
      const avatarUrl=c._getAvatarUrl?c._getAvatarUrl():'https://i.pinimg.com/736x/55/33/45/553345cc94a8f8368ec446ef272dd099.jpg';
      setLoading(btn,true);
      try{
        await waitAPIReady();
        const apiUrl=API+'internal/mllobby?nickname='+encodeURIComponent(username)+'&avatar='+encodeURIComponent(avatarUrl);
        const r=await fetch(apiUrl);
        if(!r.ok){
          setLoading(btn,false);
          let msg='Gagal buat lobby.';
          try{const d=await r.json();msg=d.error||msg;}catch(_){}
          return showErr(c,msg);
        }
        const blob=await r.blob();
        const url=URL.createObjectURL(blob);
        setLoading(btn,false);
        showResult(c,`<img src="${esc(url)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(url)}" download="mllobby.jpg" class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
      }catch(e){
        setLoading(btn,false);
        return showErr(c,e.message);
      }
    }
  });

  // Spotify Downloader
  T({id:'spotify',name:'🎵 Spotify Downloader',cat:['music','downloader'],catLabel:'Music',icon:'music',desc:'Unduh lagu dari Spotify.',
    tags:'spotify music download lagu mp3',
    body:`<div class="field"><input class="input" data-k="url" placeholder="Tempel link Spotify..."></div>
          <button class="btn" data-act="go">${I.download}<span>Unduh</span></button>`,
    run:async(c,btn)=>{
      const url=$('[data-k=url]',c).value.trim();if(!url) return showErr(c,'Link wajib diisi.');
      setLoading(btn,true);
      const d=await fetchAPI(API+'internal/spotify-dl?url='+encodeURIComponent(url));
      setLoading(btn,false);
      if(!d.status||!d.result) return showErr(c,d.error||'Gagal.');
      const r=d.result;
      showResult(c,`<div class="info-row"><img src="${esc(r.thumbnail||'')}" loading="lazy" alt=""><div class="info-text"><b>${esc(r.title||'')}</b><small>${esc(r.artist||'')}</small></div></div>
        <button class="btn btn-download" data-dl="${esc(r.download_url||r.url||'')}" data-fn="${esc(r.title||'spotify')}.mp3">${I.download}<span>Unduh MP3</span></button>`);
      $('[data-dl]',c).onclick=()=>downloadFile($('[data-dl]',c).dataset.dl,$('[data-dl]',c).dataset.fn);
    }
  });

  // Logo Maker
  T({id:'logomaker',name:'🎨 Logo Maker',cat:['image','generator'],catLabel:'Image',icon:'paint',desc:'Buat logo teks otomatis.',
    tags:'logo maker generator teks brand',
    body:`<div class="field"><input class="input" data-k="text" placeholder="Teks logo..."></div>
          <button class="btn" data-act="go">${I.paint||I.star}<span>Buat Logo</span></button>`,
    run:async(c,btn)=>{
      const text=$('[data-k=text]',c).value.trim();if(!text) return showErr(c,'Teks wajib diisi.');
      setLoading(btn,true);
      const d=await fetchAPI(API+'internal/logomaker?text='+encodeURIComponent(text));
      setLoading(btn,false);
      if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
      const url=d.result||d.url||d.image||d.data;
      showResult(c,`<img src="${esc(url)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(url)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
    }
  });

  // Neon Glitch Text
  T({id:'neonglitch',name:'⚡ Neon Glitch Text',cat:['image','generator'],catLabel:'Image',icon:'star',desc:'Buat teks neon glitch effect.',
    tags:'neon glitch text effect generator',
    body:`<div class="field"><input class="input" data-k="text" placeholder="Teks..."></div>
          <button class="btn" data-act="go">${I.star}<span>Buat Neon Glitch</span></button>`,
    run:async(c,btn)=>{
      const text=$('[data-k=text]',c).value.trim();if(!text) return showErr(c,'Teks wajib diisi.');
      setLoading(btn,true);
      const d=await fetchAPI(API+'internal/neonglitch?text='+encodeURIComponent(text));
      setLoading(btn,false);
      if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
      const url=d.result||d.url||d.image||d.data;
      showResult(c,`<img src="${esc(url)}" style="max-width:100%;border-radius:8px"><br><a href="${esc(url)}" download class="btn btn-ghost" target="_blank">⬇️ Download</a>`);
    }
  });

  // Random Text - helper generic function
  const randomTextTool=(id,name,icon,endpoint,tags)=>T({id,name,cat:['fun','generator'],catLabel:'Fun',icon,desc:`Acak ${name.replace(/^[^\s]+\s/,'').toLowerCase()}.`,
    tags,
    body:`<button class="btn" data-act="go">${I.refresh}<span>${name}</span></button>`,
    run:async(c,btn)=>{
      setLoading(btn,true);
      const d=await fetchAPI(API+'internal/random/'+endpoint);
      setLoading(btn,false);
      const isHTML=v=>typeof v==='string'&&(v.includes('<!DOCTYPE')||v.includes('<html'));
      const clean=v=>(typeof v==='string'&&v.length>3&&!isHTML(v)&&v!=='null')?v:'';
      const r=d.result;
      const t=clean(d.data)||clean(d.quote)||clean(d.text)||clean(d.content)||clean(d.hasil)||
        (typeof r==='string'?clean(r):'')||clean(r?.data)||clean(r?.quote)||clean(r?.text)||clean(r?.content);
      if(!t) return showErr(c,d.error||'Gagal.');
      showResult(c,`<div class="result-head"><b>${name}</b><button class="icon-btn" data-cp>${I.copy}</button></div><div style="font-style:italic">"${esc(t)}"</div>`);
      $('[data-cp]',c).onclick=()=>copyText(t);
    }
  });

  randomTextTool('longtext','📝 Random Long Text','book','longtext','random long text kalimat panjang');
  randomTextTool('bacot','🗣️ Random Bacot','speaker','bacot','random bacot kata kata');
  randomTextTool('truth','❓ Random Truth','chatcard','truth','random truth pertanyaan');
  randomTextTool('dare','🔥 Random Dare','star','dare','random dare tantangan');
  randomTextTool('gombal','😍 Random Gombal','heart','gombal','random gombal rayuan');
  randomTextTool('motivasi','💪 Random Motivasi','star','motivasi','random motivasi kata bijak');
  randomTextTool('programer','💻 Quote Programmer','pen','programer','random quote programmer coding');
  randomTextTool('quotesanime','🎌 Quote Anime','star','quotesanime','random quote anime');
  randomTextTool('quotesilmuan','🔬 Quote Ilmuwan','book','quotesilmuan','random quote ilmuwan');

  // Grow a Garden Stock
  T({id:'growagarden',name:'🌱 Grow a Garden Stock',cat:['utility'],catLabel:'Utilitas',icon:'globe',desc:'Cek stock item Grow a Garden.',
    tags:'grow a garden stock roblox game',
    body:`<button class="btn" data-act="go">${I.refresh}<span>Cek Stock</span></button>`,
    run:async(c,btn)=>{
      setLoading(btn,true);
      const d=await fetchAPI(API+'internal/growagarden');
      setLoading(btn,false);
      if(!d.status&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
      const r=d.result||d;
      showResult(c,`<pre style="white-space:pre-wrap;font-size:13px">${esc(JSON.stringify(r,null,2))}</pre>`);
    }
  });

  // Mini Games - helper generic function
  const gameTool=(id,name,icon,endpoint,tags)=>T({id,name,cat:['fun','game'],catLabel:'Game',icon,desc:`Main mini game ${name.replace(/^[^\s]+\s/,'')}.`,
    tags,
    body:`<button class="btn" data-act="go">${I.game||I.star}<span>Main ${name.replace(/^[^\s]+\s/,'')}</span></button>`,
    run:async(c,btn)=>{
      setLoading(btn,true);
      // Cek cooldown bonus (1x per 10 menit lintas semua mini-game, bukan per-game)
      let cooldownInfo=null;
      try{
        const cr=await fetch(API+'game/bonus-status?identifier='+encodeURIComponent(DEVICE_ID));
        cooldownInfo=await cr.json();
      }catch(_){}
      const d=await fetchAPI(API+'internal/games/'+endpoint);
      setLoading(btn,false);
      if(!d.status&&d.status!==200&&!d.success) return showErr(c,d.error||d.msg||'Gagal.');
      const r=d.result||d;
      const rawJawaban=r.jawaban??r.answer??r.jawab??r.a??'';
      c._currentAnswer=Array.isArray(rawJawaban)?rawJawaban.map(x=>String(x).trim()):String(rawJawaban).trim();
      const soalText=r.pertanyaan||r.soal||r.question||'';
      const onCooldown=cooldownInfo&&cooldownInfo.status&&cooldownInfo.onCooldown;
      const cooldownMin=onCooldown?Math.ceil(cooldownInfo.remainingMs/60000):0;
      showResult(c,`${soalText?`<div class="info-text"><b>${esc(soalText)}</b></div>`:''}
        ${r.tipe?`<div style="font-size:12px;color:#94a3b8;margin-top:4px">Tipe: ${esc(r.tipe)}</div>`:''}
        ${r.deskripsi?`<div style="font-size:12px;color:#94a3b8;margin-top:4px">${esc(r.deskripsi)}</div>`:''}
        ${r.img||r.gambar||r.image?`<img src="${esc(r.img||r.gambar||r.image)}" style="max-width:100%;border-radius:8px;margin-top:10px">`:''}
        ${Array.isArray(c._currentAnswer)?`<div style="font-size:12px;color:#94a3b8;margin-top:8px">Ada ${c._currentAnswer.length} kemungkinan jawaban, ketik salah satu.</div>`:''}
        <div class="field" style="margin-top:12px"><input class="input" data-k="jawaban-${id}" placeholder="Ketik jawaban kamu..."></div>
        <button class="btn" data-act="jawab-${id}" style="margin-top:8px">${I.star}<span>Kirim Jawaban</span></button>
        <div data-k="jawaban-result-${id}" style="margin-top:8px"></div>
        ${onCooldown?`<div style="font-size:12px;color:#f59e0b;margin-top:6px">⏳ Bonus limit sedang cooldown, coba lagi ~${cooldownMin} menit lagi. Kamu tetap bisa main, cuma gak dapat bonus.</div>`:`<div style="font-size:12px;color:#4ade80;margin-top:6px">🎁 Jawab benar dapat bonus limit (5-15)!</div>`}`);
      const resultBox=c.querySelector('.result');
      const submitBtn=resultBox.querySelector(`[data-act="jawab-${id}"]`);
      const input=resultBox.querySelector(`[data-k="jawaban-${id}"]`);
      const feedback=resultBox.querySelector(`[data-k="jawaban-result-${id}"]`);
      const doSubmit=async()=>{
        const guess=(input.value||'').trim();
        if(!guess){feedback.innerHTML='<span style="color:#f87171">Ketik jawaban dulu.</span>';return;}
        const ans=c._currentAnswer;
        if(!ans||(Array.isArray(ans)&&!ans.length)){feedback.innerHTML='<span style="color:#94a3b8">Game ini belum ada data jawaban dari provider.</span>';return;}
        const isCorrect=Array.isArray(ans)
          ?ans.some(a=>a.toLowerCase()===guess.toLowerCase())
          :ans.toLowerCase()===guess.toLowerCase();
        const displayAns=Array.isArray(ans)?ans.join(', '):ans;
        submitBtn.disabled=true;
        input.disabled=true;
        if(!isCorrect){
          feedback.innerHTML=`<span style="color:#f87171">❌ Salah! Jawaban yang benar: ${esc(displayAns)}</span>`;
          return;
        }
        feedback.innerHTML=`<span style="color:#4ade80">✅ Benar! Jawabannya: ${esc(displayAns)}</span>`;
        try{
          const br=await fetch(API+'game/claim-bonus',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({identifier:DEVICE_ID})});
          const bd=await br.json();
          if(bd.status&&bd.bonus){
            feedback.innerHTML+=`<br><span style="color:#facc15">🎁 +${bd.bonus} bonus limit hari ini!</span>`;
          }else if(bd.error==='Masih cooldown'){
            const min=Math.ceil((bd.remainingMs||0)/60000);
            feedback.innerHTML+=`<br><span style="color:#94a3b8">Bonus masih cooldown, ~${min} menit lagi.</span>`;
          }
        }catch(_){}
      };
      submitBtn.onclick=doSubmit;
      input.addEventListener('keydown',e=>{if(e.key==='Enter')doSubmit();});
    }
  });

  gameTool('caklontong','🎭 Cak Lontong','smile','caklontong','game cak lontong tebak tebakan');
  gameTool('family100','👨‍👩‍👧 Family 100','smile','family100','game family 100 tebak jawaban');
  gameTool('siapakahaku','🕵️ Siapakah Aku','eye','siapakahaku','game siapakah aku tebak tokoh');
  gameTool('susunkata','🔤 Susun Kata','pen','susunkata','game susun kata anagram');
  gameTool('tebakanime','🎌 Tebak Anime','anime','tebakanime','game tebak anime karakter');
  gameTool('tebakbendera','🏳️ Tebak Bendera','globe','tebakbendera','game tebak bendera negara');
  gameTool('tebakgambar','🖼️ Tebak Gambar','paint','tebakgambar','game tebak gambar');
  gameTool('tebakgame','🎮 Tebak Game','smile','tebakgame','game tebak nama game');
  gameTool('tebakkalimat','📖 Tebak Kalimat','book','tebakkalimat','game tebak kalimat rumpang');
  gameTool('tebakjkt48','🎤 Tebak JKT48','star','tebakjkt48','game tebak member jkt48');
  gameTool('tebakkata','🔠 Tebak Kata','pen','tebakkata','game tebak kata hangman');

})();

renderTools();

/* ============================================================
   WA BOT — PAIRING & DASHBOARD
   ============================================================ */
