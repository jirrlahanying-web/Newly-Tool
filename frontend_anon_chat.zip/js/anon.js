/* ==========================================================================
   ANON//LINE — standalone logic
   Same backend contract as the Newly Tool anon-chat card (same endpoints,
   same UID scheme: web_xxx in localStorage), but its own page, own state,
   no dependency on the Newly Tool grid/app.js runtime.
   ========================================================================== */

const $ = (sel) => document.querySelector(sel);

/* ---------- backend URL (same source of truth as the rest of Newly Tool) --------- */
let API_BASE = '';
(async () => {
  try {
    const res = await fetch('https://raw.githubusercontent.com/jirrlahanying-web/endpoint-beckend/main/backend-url.json?t=' + Date.now());
    const data = await res.json();
    API_BASE = data.url.replace(/\/$/, '');
    setNet('live');
    console.log('[anon] Backend:', API_BASE);
  } catch (e) {
    setNet('lost');
    console.error('[anon] Gagal fetch backend URL:', e.message);
  }
})();

function api(path) { return API_BASE + path; }

function waitApiReady(tries = 0) {
  return new Promise((resolve) => {
    (function check(t) {
      if (API_BASE) return resolve();
      if (t > 40) return resolve(); // give up waiting, calls will just fail loud
      setTimeout(() => check(t + 1), 250);
    })(tries);
  });
}

function setNet(state) {
  const dot = $('#net-pulse .net-dot');
  const label = $('#net-label');
  if (!dot || !label) return;
  dot.classList.remove('live', 'lost');
  if (state === 'live') { dot.classList.add('live'); label.textContent = 'online'; }
  else if (state === 'lost') { dot.classList.add('lost'); label.textContent = 'offline'; }
  else { label.textContent = 'connecting'; }
}

/* ---------- toast ---------- */
function toast(kind, text) {
  const stack = $('#toast-stack');
  if (!stack) return;
  const el = document.createElement('div');
  el.className = 'toast' + (kind === 'err' ? ' err' : kind === 'ok' ? ' ok' : '');
  el.textContent = text;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ==========================================================================
   IDENTITY (uid) — same key as the grid version so switching between the
   dedicated page and the Newly Tool card keeps the same identity.
   ========================================================================== */
const UID_KEY = 'anonUserId';
let uid = localStorage.getItem(UID_KEY) || null;
let profile = null; // { uid, platform, gender, is_premium, gender_preference, ... }

async function ensureUID() {
  if (uid) return uid;
  await waitApiReady();
  try {
    const r = await fetch(api('/api/anon/register'), { method: 'POST' });
    const d = await r.json();
    if (d.status && d.uid) {
      uid = d.uid;
      localStorage.setItem(UID_KEY, uid);
    }
  } catch (e) {
    toast('err', 'Gagal membuat identitas: ' + e.message);
  }
  return uid;
}

async function loginWithUID(inputUid) {
  await waitApiReady();
  try {
    const r = await fetch(api('/api/anon/login'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid: inputUid }),
    });
    const d = await r.json();
    if (d.status && d.user) {
      uid = inputUid;
      profile = d.user;
      localStorage.setItem(UID_KEY, uid);
      return true;
    }
  } catch (e) {}
  return false;
}

async function refreshProfile() {
  if (!uid) return;
  try {
    const r = await fetch(api('/api/anon/login'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid }),
    });
    const d = await r.json();
    if (d.status && d.user) {
      profile = d.user;
      applyProfileToUI();
    }
  } catch (e) {}
}

function applyProfileToUI() {
  const gate = $('#gender-gate');
  const prefBox = $('#premium-pref');
  const prefCurrent = $('#pref-current');

  gate.hidden = !!profile?.gender;

  if (profile?.is_premium) {
    prefBox.hidden = false;
    prefCurrent.textContent = profile.gender_preference
      ? `currently matching: ${profile.gender_preference}`
      : 'no preference set yet — defaults to random';
    $$('.pref-btn').forEach(b => b.classList.toggle('active', b.dataset.pref === profile.gender_preference));
  } else {
    prefBox.hidden = true;
  }
}

function $$(sel) { return [...document.querySelectorAll(sel)]; }

/* ==========================================================================
   STATS
   ========================================================================== */
async function refreshStats() {
  try {
    const r = await fetch(api('/api/anon/status?userId=' + encodeURIComponent(uid || '')));
    const d = await r.json();
    if (d.status) {
      $('#stat-search').textContent = d.searching ?? 0;
      $('#stat-chat').textContent = d.chatting ?? 0;
      $('#stat-total').textContent = d.total ?? 0;
    }
  } catch (e) {}
}

/* ==========================================================================
   STATE MACHINE
   ========================================================================== */
const state = {
  searching: false,
  chatting: false,
  partnerId: null,
  partnerPremium: false,
  pollInterval: null,
};

function showLobbyIdle() {
  state.searching = false;
  $('#lobby').hidden = false;
  $('#chat-shell').hidden = true;
  $('#radar-core').classList.remove('searching');
  $('#radar-core').textContent = '?';
  $('#lobby-text').textContent = 'press search. get matched with a total stranger.';
  $('#btn-search').disabled = false;
  $('#btn-search').textContent = 'search for someone';
}

function showLobbySearching() {
  state.searching = true;
  $('#radar-core').classList.add('searching');
  $('#radar-core').textContent = '…';
  $('#lobby-text').textContent = 'scanning the line for someone else who\u2019s searching\u2026';
  $('#btn-search').disabled = true;
  $('#btn-search').textContent = 'searching…';
}

function showChat() {
  state.chatting = true;
  state.searching = false;
  $('#lobby').hidden = true;
  $('#chat-shell').hidden = false;
  $('#chat-log').innerHTML = '';
  $('#chat-banner').textContent = state.partnerPremium
    ? '\u2713 paired \u2014 \u2605 the other side is premium'
    : '\u2713 paired \u2014 say hi';
}

/* ==========================================================================
   ACTIONS
   ========================================================================== */
async function doSearch() {
  if (state.chatting || state.searching) return;
  await ensureUID();
  if (!profile?.gender) {
    $('#gender-gate').hidden = false;
    toast('err', 'Pilih gender dulu sebelum search.');
    return;
  }

  showLobbySearching();

  try {
    const r = await fetch(api('/api/anon/search'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: uid }),
    });
    const d = await r.json();

    if (d.needGender) {
      $('#gender-gate').hidden = false;
      showLobbyIdle();
      return;
    }

    if (d.matched) {
      state.partnerId = d.partnerId;
      state.partnerPremium = !!d.partnerIsPremium;
      showChat();
      startPolling();
    } else {
      $('#lobby-text').textContent = 'waiting for someone else to search\u2026';
      let attempt = 0;
      state.pollInterval = setInterval(async () => {
        attempt++;
        if (attempt > 120) { clearInterval(state.pollInterval); showLobbyIdle(); return; }
        try {
          const st = await fetch(api('/api/anon/status?userId=' + encodeURIComponent(uid))).then(r => r.json());
          if (st.userPartner && st.isChatting) {
            clearInterval(state.pollInterval);
            state.partnerId = st.userPartner;
            state.partnerPremium = !!st.partnerIsPremium;
            showChat();
            startPolling();
          }
        } catch (e) {}
      }, 1000);
    }
  } catch (e) {
    toast('err', 'Error searching: ' + e.message);
    showLobbyIdle();
  }
}

function startPolling() {
  if (state.pollInterval) clearInterval(state.pollInterval);
  state.pollInterval = setInterval(pollMessages, 500);
}

async function pollMessages() {
  try {
    const r = await fetch(api('/api/anon/messages?userId=' + encodeURIComponent(uid)));
    const d = await r.json();
    if (d.messages && d.messages.length > 0) {
      d.messages.forEach(renderIncoming);
    }
  } catch (e) {}
}

function renderIncoming(msg) {
  const log = $('#chat-log');
  if (msg.from === 'system') {
    const el = document.createElement('div');
    el.className = 'msg-system';
    el.textContent = msg.text;
    log.appendChild(el);
  } else {
    const row = document.createElement('div');
    row.className = 'msg-row them';
    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble';
    if (msg.type === 'photo') {
      bubble.innerHTML = `<img src="${msg.text}" alt="photo from stranger">`;
    } else if (msg.type === 'voice') {
      bubble.innerHTML = `<audio controls src="${msg.text}"></audio>`;
    } else {
      bubble.innerHTML = esc(msg.text);
    }
    row.appendChild(bubble);
    log.appendChild(row);
  }
  log.scrollTop = log.scrollHeight;
}

function renderOutgoing(content, type) {
  const log = $('#chat-log');
  const row = document.createElement('div');
  row.className = 'msg-row me';
  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble';
  if (type === 'photo') bubble.innerHTML = `<img src="${content}" alt="photo you sent">`;
  else if (type === 'voice') bubble.innerHTML = `<audio controls src="${content}"></audio>`;
  else bubble.innerHTML = esc(content);
  row.appendChild(bubble);
  log.appendChild(row);
  log.scrollTop = log.scrollHeight;
}

async function sendText() {
  const input = $('#msg-input');
  const msg = input.value.trim();
  if (!msg) return;
  try {
    const r = await fetch(api('/api/anon/send'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: uid, message: msg, type: 'text' }),
    });
    const d = await r.json();
    if (d.delivered) {
      input.value = '';
      renderOutgoing(msg, 'text');
    } else {
      toast('err', d.error || 'Pesan gagal terkirim.');
    }
  } catch (e) {
    toast('err', 'Error sending: ' + e.message);
  }
}

async function sendMedia(dataUrl, type) {
  try {
    const r = await fetch(api('/api/anon/send'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: uid, message: dataUrl, type }),
    });
    const d = await r.json();
    if (d.delivered) renderOutgoing(dataUrl, type);
    else toast('err', d.error || 'Media gagal terkirim.');
  } catch (e) {
    toast('err', 'Gagal kirim media: ' + e.message);
  }
}

async function doNext() {
  try {
    const r = await fetch(api('/api/anon/next'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: uid }),
    });
    const d = await r.json();
    if (d.matched) {
      state.partnerId = d.partnerId;
      state.partnerPremium = !!d.partnerIsPremium;
      showChat();
      startPolling();
    } else {
      doSearch();
    }
  } catch (e) {
    toast('err', 'Error: ' + e.message);
  }
}

async function doStop() {
  if (state.pollInterval) clearInterval(state.pollInterval);
  try {
    await fetch(api('/api/anon/stop'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: uid }),
    });
  } catch (e) {}
  state.chatting = false;
  state.searching = false;
  showLobbyIdle();
}

async function setGender(gender) {
  try {
    const r = await fetch(api('/api/anon/gender'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid, gender }),
    });
    const d = await r.json();
    if (d.status) {
      profile = d.user;
      $('#gender-gate').hidden = true;
      applyProfileToUI();
      toast('ok', 'Gender disimpan.');
    }
  } catch (e) {
    toast('err', 'Gagal menyimpan gender: ' + e.message);
  }
}

async function setPref(pref) {
  try {
    const r = await fetch(api('/api/anon/preferensi'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ uid, prefersGender: pref }),
    });
    const d = await r.json();
    if (d.status) {
      profile = d.user;
      applyProfileToUI();
      toast('ok', 'Preferensi disimpan.');
    } else {
      toast('err', d.error || 'Gagal menyimpan preferensi');
    }
  } catch (e) {
    toast('err', 'Gagal menyimpan preferensi: ' + e.message);
  }
}

/* ==========================================================================
   VOICE RECORDING
   ========================================================================== */
let mediaRecorder = null;
let recChunks = [];

async function toggleVoice() {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    recChunks = [];
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.ondataavailable = (e) => { if (e.data.size > 0) recChunks.push(e.data); };
    mediaRecorder.onstop = () => {
      stream.getTracks().forEach(t => t.stop());
      $('#rec-banner').hidden = true;
      const blob = new Blob(recChunks, { type: 'audio/webm' });
      const reader = new FileReader();
      reader.onload = () => sendMedia(reader.result, 'voice');
      reader.readAsDataURL(blob);
    };
    mediaRecorder.start();
    $('#rec-banner').hidden = false;
  } catch (e) {
    toast('err', 'Gagal akses mikrofon: ' + e.message);
  }
}

/* ==========================================================================
   CEK UID — look up any uid's public profile
   ========================================================================== */
async function lookupUid() {
  const input = $('#lookup-input');
  const resultBox = $('#lookup-result');
  const target = input.value.trim();
  if (!target) return;

  resultBox.hidden = false;
  resultBox.innerHTML = '<span class="lr-key">checking…</span>';

  try {
    await waitApiReady();
    const r = await fetch(api('/api/anon/cekuid/' + encodeURIComponent(target)));
    const d = await r.json();

    if (!d.status) {
      resultBox.innerHTML = `<span class="lr-err">✕ ${esc(d.error || 'UID tidak ditemukan')}</span>`;
      return;
    }

    const u = d.user;
    const genderLabel = u.gender === 'male' ? '♂ male' : u.gender === 'female' ? '♀ female' : 'not set';
    const statusLabel = d.currentStatus === 'chatting' ? '💬 chatting' : d.currentStatus === 'searching' ? '🔍 searching' : '⚪ idle';
    const premiumLabel = u.is_premium
      ? `<span class="lr-premium">★ premium</span>${u.premium_until ? ' until ' + new Date(u.premium_until).toLocaleDateString() : ''}`
      : 'basic';
    const lastActive = u.last_active ? new Date(u.last_active).toLocaleString() : '-';

    resultBox.innerHTML = `
      <div class="lr-row"><span class="lr-key">uid</span><code class="lr-uid">${esc(u.uid)}</code></div>
      <div class="lr-row"><span class="lr-key">platform</span><span>${esc(u.platform)}</span></div>
      <div class="lr-row"><span class="lr-key">gender</span><span>${genderLabel}</span></div>
      <div class="lr-row"><span class="lr-key">account</span><span>${premiumLabel}</span></div>
      <div class="lr-row"><span class="lr-key">right now</span><span>${statusLabel}</span></div>
      <div class="lr-row"><span class="lr-key">last active</span><span>${esc(lastActive)}</span></div>
    `;
  } catch (e) {
    resultBox.innerHTML = `<span class="lr-err">✕ error: ${esc(e.message)}</span>`;
  }
}

/* ==========================================================================
   WIRING
   ========================================================================== */
function init() {
  (async () => {
    await ensureUID();
    $('#my-uid').textContent = uid || '\u2014';
    await refreshProfile();
    refreshStats();
  })();

  setInterval(refreshStats, 8000);

  $('#btn-search').addEventListener('click', doSearch);
  $('#btn-check').addEventListener('click', refreshStats);
  $('#btn-next').addEventListener('click', doNext);
  $('#btn-stop').addEventListener('click', doStop);

  $('#btn-lookup').addEventListener('click', lookupUid);
  $('#lookup-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') lookupUid(); });

  $('#btn-switch-uid').addEventListener('click', async () => {
    const input = prompt('Masukkan UID kamu (contoh: web_xxxxx). Kosongkan untuk batal:');
    if (!input) return;
    const ok = await loginWithUID(input.trim());
    if (ok) {
      $('#my-uid').textContent = uid;
      applyProfileToUI();
      toast('ok', 'Berhasil login dengan UID: ' + uid);
    } else {
      toast('err', 'UID tidak ditemukan.');
    }
  });

  $$('.gate-btn').forEach(btn => {
    btn.addEventListener('click', () => setGender(btn.dataset.gender));
  });

  $$('.pref-btn').forEach(btn => {
    btn.addEventListener('click', () => setPref(btn.dataset.pref));
  });

  $('#composer').addEventListener('submit', (e) => {
    e.preventDefault();
    sendText();
  });

  $('#btn-photo').addEventListener('click', () => $('#photo-input').click());
  $('#photo-input').addEventListener('change', () => {
    const file = $('#photo-input').files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast('err', 'Foto maksimal 5MB.'); $('#photo-input').value = ''; return; }
    const reader = new FileReader();
    reader.onload = () => { sendMedia(reader.result, 'photo'); $('#photo-input').value = ''; };
    reader.readAsDataURL(file);
  });

  $('#btn-voice').addEventListener('click', toggleVoice);
  $('#btn-rec-stop').addEventListener('click', toggleVoice);
}

window.addEventListener('DOMContentLoaded', init);
