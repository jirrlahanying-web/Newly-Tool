// /api/media.js — Vercel Serverless Function
// Proxy https://url.vercel.app/F/UID.ext, /V/UID.ext, /A/UID.ext, /D/UID.ext ke backend Pterodactyl
// Backend URL diambil dinamis dari GitHub (karena Cloudflare Tunnel URL berubah-ubah)

export default async function handler(req, res) {
  try {
    const { type, uid } = req.query; // type = 'F' | 'V' | 'A' | 'D'

    if (!uid || !['F', 'V', 'A', 'D'].includes(type)) {
      return res.status(400).send('Invalid request');
    }

    // Ambil backend URL terbaru dari GitHub
    const ghRes = await fetch(
      'https://raw.githubusercontent.com/jirrlahanying-web/endpoint-beckend/main/backend-url.json?t=' + Date.now()
    );
    if (!ghRes.ok) return res.status(502).send('Gagal ambil backend URL');
    const { url: backendUrl } = await ghRes.json();

    // uid bisa datang dengan ekstensi nempel (mis. "abc123.jpg") — backend yang urus strip-nya,
    // tapi kita kirim apa adanya supaya endpoint /api/media/:uid backend bisa toleransi keduanya
    const mediaRes = await fetch(`${backendUrl}/api/media/${uid}`);
    if (!mediaRes.ok) return res.status(404).send('Media tidak ditemukan');
    const media = await mediaRes.json();

    if (!media.status || !media.raw_url) {
      return res.status(404).send('Media tidak ditemukan');
    }

    // Redirect ke raw GitHub URL (permanen, tidak tergantung tunnel)
    res.writeHead(302, { Location: media.raw_url });
    res.end();
  } catch (e) {
    res.status(500).send('Server error: ' + e.message);
  }
}
